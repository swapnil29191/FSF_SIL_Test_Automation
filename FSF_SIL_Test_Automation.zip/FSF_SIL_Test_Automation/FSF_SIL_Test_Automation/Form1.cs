﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Xml;

namespace FSF_Eval_Generator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Thread thread1, thread2, thread3;

        struct Xml_Failure_details
        {
            public string Failure_Name;
            public string DTC;
            public string Failram;
            public string Failram_Value;
            public string Failram_Mem;
        };

        //-------------------------JSON Creation -------------------------
        // For Generate JSON file
        private void Json_Creator(object sender, EventArgs e)
        {
            string[] XML_File = null;
            string path2 = Directory.GetCurrentDirectory() + "\\XML_File\\";  // 4
            try
            {
                XML_File = Directory.GetFiles(path2);
            }
            catch (DirectoryNotFoundException)
            {
                MessageBox.Show("Please keep XML_File folder with Xml file..!!!!");
                return;
            }

            string TestRun = Directory.GetCurrentDirectory() + "\\TestRun\\";

            string[] DegradationTable = null;
            string path1 = Directory.GetCurrentDirectory() + "\\DegradationTable\\";  
            try
            {
                DegradationTable = Directory.GetFiles(path1);
            }
            catch (DirectoryNotFoundException)
            {
                MessageBox.Show("Please keep DegradationTable folder with Database file..!!!!");
                return;
            }

            string[] Bat_File = null;
            if (checkBox7.Checked)
            {
                try
                {
                    string path = Directory.GetCurrentDirectory() + "\\Bat_File\\";
                    Bat_File = Directory.GetFiles(path);
                }
                catch (DirectoryNotFoundException)
                {
                    MessageBox.Show("Bat_File Folder is not present!");
                    return;
                }
                try
                {
                    if (Bat_File[0] == null)
                    {
                    }
                }
                catch(IndexOutOfRangeException)
                {
                    MessageBox.Show("Please keep templete for .bat file in Bat_File folder");
                    return;
                }
            }

            try
            {
                if (DegradationTable[0] != string.Empty && XML_File[0] != string.Empty && TestRun != string.Empty)
                {
                }
            }
            catch (IndexOutOfRangeException)
            {
                MessageBox.Show("Degradation table ,XML file and TestRun are mandatory..!!!!");
                return;
            }

            if (DegradationTable[0] != string.Empty && XML_File[0] != string.Empty && TestRun != string.Empty)
            {
                List<Xml_Failure_details> datalist = new List<Xml_Failure_details>();
                List<Xml_Failure_details> datalist1 = new List<Xml_Failure_details>();
                List<Xml_Failure_details> datalist2 = new List<Xml_Failure_details>();

                button9.Enabled = false;
                XmlDocument xmldoc = new XmlDocument();
                xmldoc.Load(XML_File[0]);

                List<string> AllFSF_failure = new List<string>();
                XmlNodeList nodeList = xmldoc.DocumentElement.SelectNodes("/root/Failure_Bit");
                foreach (XmlNode nxmNode in nodeList)
                {
                    Xml_Failure_details sample = new Xml_Failure_details();
                    XmlElement element = (XmlElement)nxmNode;

                    sample.Failure_Name = element.ChildNodes.Item(0).InnerText.Trim();
                    sample.DTC = element.ChildNodes.Item(1).InnerText.Trim();
                    sample.Failram = element.ChildNodes.Item(4).InnerText.Trim();
                    sample.Failram_Value = element.ChildNodes.Item(6).InnerText.Trim();

                    AllFSF_failure.Add(sample.Failure_Name);
                    datalist.Add(sample);
                }

                List<string> AllFSF4_failure = new List<string>();
                XmlNodeList nodeList1 = xmldoc.DocumentElement.SelectNodes("/root/FSF4_Bit");

                foreach (XmlNode nxmNode in nodeList1)
                {
                    Xml_Failure_details sample1 = new Xml_Failure_details();
                    XmlElement element = (XmlElement)nxmNode;

                    sample1.Failure_Name = element.ChildNodes.Item(0).InnerText.Trim();
                    sample1.DTC = element.ChildNodes.Item(1).InnerText.Trim();
                    sample1.Failram = element.ChildNodes.Item(4).InnerText.Trim();
                    sample1.Failram_Value = element.ChildNodes.Item(6).InnerText.Trim();

                    AllFSF4_failure.Add(sample1.Failure_Name);
                    datalist1.Add(sample1);
                }

                List<string> AllBUS_failure = new List<string>();
                XmlNodeList nodeList2 = xmldoc.DocumentElement.SelectNodes("/root/BUS_Bit");
                foreach (XmlNode nxmNode in nodeList2)
                {
                    Xml_Failure_details sample2 = new Xml_Failure_details();
                    XmlElement element = (XmlElement)nxmNode;

                    sample2.Failure_Name = element.ChildNodes.Item(0).InnerText.Trim();
                    sample2.DTC = element.ChildNodes.Item(1).InnerText.Trim();
                    sample2.Failram = element.ChildNodes.Item(4).InnerText.Trim();
                    sample2.Failram_Value = element.ChildNodes.Item(6).InnerText.Trim();

                    AllBUS_failure.Add(sample2.Failure_Name);
                    datalist2.Add(sample2);
                }

                Excel.Application xlapp = new Excel.Application();
                Excel.Workbook xlWorkBook;
                Excel.Worksheet xlWorkSheet;

                xlWorkBook = xlapp.Workbooks.Open(DegradationTable[0]);
                xlWorkSheet = xlWorkBook.ActiveSheet;
                int iTotalRows = xlWorkSheet.UsedRange.Rows.Count;
                int itotalcols = xlWorkSheet.UsedRange.Columns.Count;

                // Create failure list from excle sheet
                List<string> AllFailure = new List<string>();
                for (int s = 3; s <= iTotalRows; s++)
                {
                    string failureName = (string)(xlWorkSheet.Cells[s, 1] as Excel.Range).Value2;
                    AllFailure.Add(failureName);
                }

                // Create TestRun list from TestRun folder
                List<string> AllTestRun = new List<string>();
                string[] files = Directory.GetFiles(TestRun);
                foreach (string file in files)
                {
                    string name = file.Substring(file.LastIndexOf("\\") + 1);
                    AllTestRun.Add(name);
                }

                List<string> MainFile = new List<string>();
                List<string> BatFile = new List<string>();

                MainFile.Add("{");
                MainFile.Add("   \"CONSTANTS\" : {");
                if (string.IsNullOrEmpty(textBox1.Text))
                {
                    MainFile.Add("      \"TDB_PATH\" : \"#ENVVAR(TEST_DATA_PATH)#\\\\TestDataBases\\\\FSF\\\\SIL_FSF_AUTOMATION_TDB_CustomerID_ProjectID.xlsx\",");
                }
                else
                {
                    MainFile.Add("      \"TDB_PATH\" : \"#ENVVAR(TEST_DATA_PATH)#\\\\TestDataBases\\\\FSF\\\\SIL_FSF_AUTOMATION_TDB_" + textBox1.Text + ".xlsx\",");
                }
                MainFile.Add("      \"EVALUATION_PATH\" : \"#ENVVAR(WORKSPACE_ROOT)#\\\\CV\\\\SIL\\\\FSF_Eval_Scripts\",");
                MainFile.Add("      \"FSF_SPEC\" : \"#ENVVAR(WORKSPACE_ROOT)#\\\\CV\\\\SIL\\\\FSF_Eval_Scripts\\\\AD2_development_monitoring_description.xlsx\"");
                MainFile.Add("   },");
                MainFile.Add("   \"DATABASE\" : {");
                MainFile.Add("      \"SWFactoryEvaluator\" : {");
                MainFile.Add("         \"full\" : {");

                List<string> Read_File = new List<string>();
                foreach (string file in files)
                {
                    string name = file.Substring(file.LastIndexOf("\\") + 1);

                    if ((name.ToUpper()).Contains("_MEM") || (name.ToUpper()).Contains("_REC"))
                    {
                        Read_File.Add(name);
                    }
                    else
                    {
                        MainFile.Add("            \"FSF_Testruns/STD/" + name + "\" : {");
                        int temp = 0;

                        if (checkBox1.Checked)
                        {
                            if (AllFailure.Any(s => s.Contains(name)))
                            {
                                if (!(AllBUS_failure.Any(s => s.Contains(name))))
                                {
                                    MainFile.Add("               \"" + name + "_DEG\" : {");
                                    MainFile.Add("                  \"Group\" : \"DEG\",");
                                    MainFile.Add("                  \"TestDatabasePath\" : \"#CONST_INSERT(TDB_PATH)#\",");
                                    MainFile.Add("                  \"TestCaseId\" : [ \"SW_DEG_TestCase_" + name + "\" ],");
                                    MainFile.Add("                  \"Parameters\" : {");
                                    MainFile.Add("                     \"--script_folder_path\" : \"#CONST_INSERT(EVALUATION_PATH)#\\\\DEG\"");

                                    if (checkBox7.Checked)
                                    {
                                        string[] lines1 = System.IO.File.ReadAllLines(Bat_File[0]);
                                        foreach (string line in lines1)
                                        {
                                            if (line.Contains("SW_Failure_Name"))
                                                BatFile.Add(line.Replace("SW_Failure_Name", "SW_DEG_TestCase_" + name));
                                            else if (line.Contains(".dl3"))
                                                BatFile.Add(line.Replace("Failure_Name", name));
                                            else if (line.Contains(".txt"))
                                                BatFile.Add(line.Replace("Failure_Name", name));
                                            else
                                                BatFile.Add(line);
                                        }
                                    }
                                    temp = 2;
                                }
                            }
                            else { }
                        }

                        
                        if (checkBox2.Checked)
                        {
                            if (!(AllFSF4_failure.Any(s => s.Contains(name))))
                            {
                                if (AllFailure.Any(s => s.Contains(name)))
                                {
                                    if (!(AllBUS_failure.Any(s => s.Contains(name))))
                                    {
                                        MainFile.Add("                  }");
                                        MainFile.Add("               },");
                                    }
                                }
                                MainFile.Add("               \"" + name + "_DTC\" : {");
                                MainFile.Add("                  \"Group\" : \"DTC\",");
                                MainFile.Add("                  \"TestDatabasePath\" : \"#CONST_INSERT(TDB_PATH)#\",");
                                MainFile.Add("                  \"TestCaseId\" : [ \"SW_DTC_TestCase_" + name + "\" ],");
                                MainFile.Add("                  \"Parameters\" : {");
                                MainFile.Add("                     \"--script_folder_path\" : \"#CONST_INSERT(EVALUATION_PATH)#\\\\DTC\",");
                                MainFile.Add("                     \"--dtc_log\" : \"#PATH(temp_path)#\\\\" + name + "_SetDTCs.txt\",");
                                MainFile.Add("                     \"--dtc_file\" : \"#CONST_INSERT(FSF_SPEC)#\"");

                                if (checkBox7.Checked)
                                {
                                    string[] lines1 = System.IO.File.ReadAllLines(Bat_File[0]);
                                    foreach (string line in lines1)
                                    {
                                        if (line.Contains("SW_Failure_Name"))
                                            BatFile.Add(line.Replace("SW_Failure_Name", "SW_DTC_TestCase_" + name));
                                        else if (line.Contains(".dl3"))
                                            BatFile.Add(line.Replace("Failure_Name", name));
                                        else if (line.Contains(".txt"))
                                            BatFile.Add(line.Replace("Failure_Name", name));
                                        else
                                            BatFile.Add(line);
                                    }
                                }
                                temp = 1;
                            }
                        }

                        if (temp == 1 && temp != 2)
                        {
                            MainFile.Add("                  }");
                            MainFile.Add("               }");
                        }
                        if (temp == 2)
                        {
                            MainFile.Add("                  }");
                            MainFile.Add("               }");
                        }
                        MainFile.Add("            },");
                        temp = 0;

                        if (checkBox5.Checked)
                        {
                            MainFile.Add("            \"FSF_Testruns/REC/" + name + "_Rec\" : {");
                            MainFile.Add("               \"" + name + "_REC\" : {");
                            MainFile.Add("                  \"Group\" : \"REC\",");
                            MainFile.Add("                  \"TestDatabasePath\" : \"#CONST_INSERT(TDB_PATH)#\",");
                            MainFile.Add("                  \"TestCaseId\" : [ \"SW_REC_TestCase_" + name + "\" ],");
                            MainFile.Add("                  \"Parameters\" : {");
                            MainFile.Add("                     \"--script_folder_path\" : \"#CONST_INSERT(EVALUATION_PATH)#\\\\REC\",");
                            MainFile.Add("                     \"--dtc_log\" : \"#PATH(temp_path)#\\\\" + name + "_Rec_SetDTCs.txt\",");
                            MainFile.Add("                     \"--dtc_file\" : \"#CONST_INSERT(FSF_SPEC)#\"");
                            MainFile.Add("                  }");
                            MainFile.Add("               }");
                            MainFile.Add("            },");

                            if (checkBox7.Checked)
                            {
                                string[] lines1 = System.IO.File.ReadAllLines(Bat_File[0]);
                                foreach (string line in lines1)
                                {
                                    if (line.Contains("SW_Failure_Name"))
                                        BatFile.Add(line.Replace("SW_Failure_Name", "SW_REC_TestCase_" + name));
                                    else if (line.Contains(".dl3"))
                                        BatFile.Add(line.Replace("Failure_Name", name + "_Rec"));
                                    else if (line.Contains(".txt"))
                                        BatFile.Add(line.Replace("Failure_Name", name + "_Rec"));
                                    else
                                        BatFile.Add(line);
                                }
                            }

                        }

                        if (checkBox6.Checked)
                        {
                            if (!(AllBUS_failure.Any(s => s.Contains(name))))
                            {
                                MainFile.Add("            \"FSF_Testruns/MEM/" + name + "_Mem\" : {");
                                MainFile.Add("               \"" + name + "_MEM\" : {");
                                MainFile.Add("                  \"Group\" : \"MEM\",");
                                MainFile.Add("                  \"TestDatabasePath\" : \"#CONST_INSERT(TDB_PATH)#\",");
                                MainFile.Add("                  \"TestCaseId\" : [ \"SW_MEM_TestCase_" + name + "\" ],");
                                MainFile.Add("                  \"Parameters\" : {");
                                MainFile.Add("                     \"--script_folder_path\" : \"#CONST_INSERT(EVALUATION_PATH)#\\\\MEM\",");
                                MainFile.Add("                     \"--dtc_log\" : \"#PATH(temp_path)#\\\\" + name + "_Mem_SetDTCs.txt\",");
                                MainFile.Add("                     \"--dtc_file\" : \"#CONST_INSERT(FSF_SPEC)#\"");
                                MainFile.Add("                  }");
                                MainFile.Add("               }");
                                MainFile.Add("            },");
                            }

                            if (checkBox7.Checked)
                            {
                                string[] lines1 = System.IO.File.ReadAllLines(Bat_File[0]);
                                foreach (string line in lines1)
                                {
                                    if (line.Contains("SW_Failure_Name"))
                                        BatFile.Add(line.Replace("SW_Failure_Name", "SW_MEM_TestCase_" + name));
                                    else if (line.Contains(".dl3"))
                                        BatFile.Add(line.Replace("Failure_Name", name + "_Mem"));
                                    else if (line.Contains(".txt"))
                                        BatFile.Add(line.Replace("Failure_Name", name + "_Mem"));
                                    else
                                        BatFile.Add(line);
                                }
                            }

                        }
                    }
                }

                MainFile.RemoveAt(MainFile.Count - 1);            // to Remove Last comma
                MainFile.Add("            }");
                MainFile.Add("         }");
                MainFile.Add("      }");
                MainFile.Add("   }");
                MainFile.Add("}");

                if (string.IsNullOrEmpty(textBox1.Text))
                {
                    File.WriteAllLines(Directory.GetCurrentDirectory() + "\\ProjectID_TestConfig_FSF.json", MainFile);
                }
                else
                {
                    String ProjectID = textBox1.Text.Substring(textBox1.Text.LastIndexOf("_") + 1);

                    File.WriteAllLines(Directory.GetCurrentDirectory() + "\\" + ProjectID + "_TestConfig_FSF.json", MainFile);
                }
                if (checkBox7.Checked)
                {
                    File.WriteAllLines(Directory.GetCurrentDirectory() + "\\CommonBatFIle.bat", BatFile);
                }

                Read_File.Add("--------------------");
                Read_File.Add("Please add all these TestRun file name in Test Database manually and also to Bat file or Json file.");
                if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\Debug\\"))
                    Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\Debug\\");
                File.WriteAllLines(Directory.GetCurrentDirectory()  + "\\Debug\\" +"File_contain_MEMorREC.txt", Read_File);  

                button9.Enabled = true;
                MessageBox.Show(" Json or Bat file Generated");
            }
            else { }
        }


        //-------------------------PY FILE Creation ----------------------
        // STANDARD___PY file generation button
        private void Generate_PY_Click(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false;

            if (checkBox2.Checked ||  checkBox1.Checked)
            {
                thread1 = new Thread(() => PY_Thread1_Click(sender, e));
                thread1.Start();
            }

            if (checkBox5.Checked || checkBox6.Checked)
            {
                thread2 = new Thread(() => PY_Thread2_Click(sender, e));
                thread2.Start();
            }
        }

        //-------------------------Standard (DTC & DEG)PY FILE -----------
        // DTC + DEG ___PY file generation
        // Thread create for standard PY file generation
        private void PY_Thread1_Click(object sender, EventArgs e)
        {
            List<Xml_Failure_details> datalist = new List<Xml_Failure_details>();
            List<Xml_Failure_details> datalist1 = new List<Xml_Failure_details>();
            List<Xml_Failure_details> datalist2 = new List<Xml_Failure_details>();
            List<string> Xcomponents = new List<string>();
            List<string> Ycomponents = new List<string>();

            string TestRun = Directory.GetCurrentDirectory() + "\\TestRun\\";  // 8

            string[] DegradationTable = null;
            string path1 = Directory.GetCurrentDirectory() + "\\DegradationTable\\";  //1
            try
            {
                DegradationTable = Directory.GetFiles(path1);
            }
            catch (DirectoryNotFoundException)
            {
                MessageBox.Show("Please keep DegradationTable folder with Database file..!!!!");
                return;
            }

            string[] XML_File = null;
            string path2 = Directory.GetCurrentDirectory() + "\\XML_File\\";  // 4
            try
            {
                XML_File = Directory.GetFiles(path2);
            }
            catch (DirectoryNotFoundException)
            {
                MessageBox.Show("Please keep XML_File folder with Xml file..!!!!");
                return;
            }

            try
            {
                if (DegradationTable[0] != string.Empty && XML_File[0] != string.Empty && TestRun != string.Empty)
                { 
                }
            }
            catch (IndexOutOfRangeException)
            {
                MessageBox.Show("All Fileds are mandatory..!!!!\n 1.DEG Table\n 2.XML File\n 3.TestRun Folder\n 4.DTC Status value");
                return;
            }

            if (DegradationTable[0] != string.Empty && XML_File[0] != string.Empty && TestRun != string.Empty)
            {
                foreach (string currentname in textBox5.Lines)
                {
                    Xcomponents.Add(currentname);
                }
                foreach (string currentname in textBox6.Lines)
                {
                    Ycomponents.Add(currentname);
                }

                button3.Enabled = false;
                XmlDocument xmldoc = new XmlDocument();
                xmldoc.Load(XML_File[0]);

                List<string> AllFSF_failure = new List<string>();
                XmlNodeList nodeList = xmldoc.DocumentElement.SelectNodes("/root/Failure_Bit");
                foreach (XmlNode nxmNode in nodeList)
                {
                    Xml_Failure_details sample = new Xml_Failure_details();
                    XmlElement element = (XmlElement)nxmNode;

                    sample.Failure_Name = element.ChildNodes.Item(0).InnerText.Trim();
                    sample.DTC = element.ChildNodes.Item(1).InnerText.Trim();
                    sample.Failram = element.ChildNodes.Item(4).InnerText.Trim();
                    sample.Failram_Value = element.ChildNodes.Item(6).InnerText.Trim();

                    AllFSF_failure.Add(sample.Failure_Name);
                    datalist.Add(sample);
                }

                List<string> AllFSF4_failure = new List<string>();
                XmlNodeList nodeList1 = xmldoc.DocumentElement.SelectNodes("/root/FSF4_Bit");

                foreach (XmlNode nxmNode in nodeList1)
                {
                    Xml_Failure_details sample1 = new Xml_Failure_details();
                    XmlElement element = (XmlElement)nxmNode;

                    sample1.Failure_Name = element.ChildNodes.Item(0).InnerText.Trim();
                    sample1.DTC = element.ChildNodes.Item(1).InnerText.Trim();
                    sample1.Failram = element.ChildNodes.Item(4).InnerText.Trim();
                    sample1.Failram_Value = element.ChildNodes.Item(6).InnerText.Trim();

                    AllFSF4_failure.Add(sample1.Failure_Name);
                    datalist1.Add(sample1);
                }

                List<string> AllBUS_failure = new List<string>();
                XmlNodeList nodeList2 = xmldoc.DocumentElement.SelectNodes("/root/BUS_Bit");
                foreach (XmlNode nxmNode in nodeList2)
                {
                    Xml_Failure_details sample2 = new Xml_Failure_details();
                    XmlElement element = (XmlElement)nxmNode;

                    sample2.Failure_Name = element.ChildNodes.Item(0).InnerText.Trim();
                    sample2.DTC = element.ChildNodes.Item(1).InnerText.Trim();
                    sample2.Failram = element.ChildNodes.Item(4).InnerText.Trim();
                    sample2.Failram_Value = element.ChildNodes.Item(6).InnerText.Trim();

                    AllBUS_failure.Add(sample2.Failure_Name);
                    datalist2.Add(sample2);
                }

                Excel.Application xlapp = new Excel.Application();
                Excel.Workbook xlWorkBook;
                Excel.Worksheet xlWorkSheet;

                xlWorkBook = xlapp.Workbooks.Open(DegradationTable[0]);
                xlWorkSheet = xlWorkBook.ActiveSheet;
                int iTotalRows = xlWorkSheet.UsedRange.Rows.Count;
                int itotalcols = xlWorkSheet.UsedRange.Columns.Count;

                // Create failure list from excle sheet
                List<string> AllFailure = new List<string>();
                for (int s = 3; s <= iTotalRows; s++)
                {
                    string failureName = (string)(xlWorkSheet.Cells[s, 1] as Excel.Range).Value2;
                    AllFailure.Add(failureName);
                }

                // Create TestRun list from TestRun folder
                List<string> AllTestRun = new List<string>();
                string[] files = null;
                try
                {
                    files = Directory.GetFiles(TestRun);
                }
                catch (DirectoryNotFoundException)
                {
                    MessageBox.Show("Please keep TestRun folder with TestRun file..!!!!");
                    return;
                }

                foreach (string file in files)
                {
                    string name = file.Substring(file.LastIndexOf("\\") + 1);
                    AllTestRun.Add(name);
                }

                string newfolder = DateTime.Now.ToString();
                newfolder = newfolder.Replace("/", "-").Replace(":", "-");
                if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder))
                    Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder);

                progressBar1.Value = 0;
                progressBar1.Maximum = iTotalRows;
                progressBar1.Visible = progressBar1.Enabled = true;

                for (int a = 3; a <= iTotalRows; a++)
                {
                    progressBar1.Value = a;
                    textBox5.ReadOnly = textBox6.ReadOnly = true;
                    List<string> DEGFile = new List<string>();
                    List<string> DTCFile = new List<string>();

                    string filename = (string)(xlWorkSheet.Cells[a, 1] as Excel.Range).Value2;
                    if (string.IsNullOrEmpty(filename))
                        continue;

                    if (AllTestRun.Any(s => s.Contains(filename)))
                    {
                        Xml_Failure_details currentlist = datalist.Find(x => x.Failure_Name.Contains(filename));

                        if (checkBox2.Checked)
                        {
                            if (!(AllFSF4_failure.Any(s => s.Contains(filename))))
                            {
                                if (AllBUS_failure.Any(s => s.Contains(filename)))
                                {
                                    currentlist = datalist2.Find(x => x.Failure_Name.Contains(filename));
                                }

                                DTCFile.Add("from utils.utils import get_dtc_log_signals");
                                DTCFile.Add("from pprint import pprint");
                                DTCFile.Add("   ");

                                DTCFile.Add("def run(meas, tdbparam):");
                                DTCFile.Add("    import pandas as pd");
                                DTCFile.Add("    from pandas import ExcelWriter");
                                DTCFile.Add("    from pandas import ExcelFile");
                                DTCFile.Add("    import evaluation_core.script_evaluation as se");
                                DTCFile.Add("    import time as ti");
                                DTCFile.Add("    import numpy as np");
                                DTCFile.Add("    ");
                                DTCFile.Add("    pd.set_option(\"max_columns\", 0)");
                                DTCFile.Add("    pd.set_option(\"max_rows\", 0)");
                                DTCFile.Add("    test_case = se.TestCase(meas.Data.index)");
                                DTCFile.Add("    ");
                                DTCFile.Add("    DTC_Status = { 0xAF ,0x2F ,0xA3 ,0xA7 ,0x23 ,0x27 };");
                                DTCFile.Add("    #-----------------------Pre-condition ----------------");
                                DTCFile.Add("    ");

                                DTCFile.Add("    #---> Check of DTC Value and DTC Status");
                                DTCFile.Add("    signals, errors = get_dtc_log_signals(meas.args, meas.signals)");
                                DTCFile.Add("    ");
                                DTCFile.Add("    #---> Checking Failure Ram");
                                if (currentlist.Failram_Value != null)
                                    DTCFile.Add("    test_case.add_precondition('Checking failure EEPROM',meas.Data.Meas_" + currentlist.Failram.ToUpper() + " == " + currentlist.Failram_Value + ")");
                                else
                                    DTCFile.Add("    #test_case.add_precondition('Checking failure EEPROM',meas.Data.Meas_" + currentlist.Failram.ToUpper() + " == " + currentlist.Failram_Value + ")");
                                DTCFile.Add("    ");

                                DTCFile.Add("    #-------------------- Acception Creteria --------------");
                                DTCFile.Add("    ");
                                if (currentlist.Failram_Value != null)
                                {
                                    DTCFile.Add("    if 'DTC_" + currentlist.Failure_Name + "' in signals:");
                                    DTCFile.Add("        test_case.add_accept_crit('DTC value = " + currentlist.DTC + "' , str(signals['DTC_" + currentlist.Failure_Name + "'].signal[0]).upper() == '" + currentlist.DTC + "'.upper())");
                                    DTCFile.Add("        test_case.add_accept_crit('DTCStatus value = 0xAF ,0x2F ,0xA3 ,0xA7 ,0x23 ,0x27 ' , any(x == (signals['DTCStatus_" + currentlist.Failure_Name + "'].signal[0]) for x in DTC_Status))");
                                    DTCFile.Add("    else:");
                                    DTCFile.Add("        test_case.add_accept_crit('DTC not getting set', 0 == 1)");
                                    DTCFile.Add("    ");
                                    DTCFile.Add("    return [test_case]");
                                }
                                else
                                {
                                    DTCFile.Add("    if 'DTC_" + currentlist.Failure_Name + "' in signals:");
                                    DTCFile.Add("        #test_case.add_accept_crit('DTC value = " + currentlist.DTC + "' , str(signals['DTC_" + currentlist.Failure_Name + "'].signal[0]).upper() == '" + currentlist.DTC + "'.upper())");
                                    DTCFile.Add("        # test_case.add_accept_crit('DTCStatus value = 0xAF ,0x2F ,0xA3 ,0xA7 ,0x23 ,0x27 ' , any(x == (signals['DTCStatus_" + currentlist.Failure_Name + "'].signal[0]) for x in DTC_Status))");
                                    DTCFile.Add("    ");
                                    DTCFile.Add("    else:");
                                    DTCFile.Add("        #test_case.add_accept_crit('DTC not getting set', 0 == 1)");
                                    DTCFile.Add("    return [test_case]");
                                }
                                if (checkBox2.Checked)
                                {
                                    if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\DTC"))
                                        Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\DTC");
                                    File.WriteAllLines(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\DTC\\SW_DTC_TestCase_" + filename + ".py", DTCFile);
                                }
                            }
                        }
                        if (checkBox1.Checked)
                        {
                            if (!(AllBUS_failure.Any(s => s.Contains(filename))))
                            {
                                if (AllFSF4_failure.Any(s => s.Contains(filename)))
                                {
                                    currentlist = datalist1.Find(x => x.Failure_Name.Contains(filename));
                                }
                                DEGFile.Add("from utils.utils import get_dtc_log_signals");
                                DEGFile.Add("from pprint import pprint");
                                DEGFile.Add("    ");
                                DEGFile.Add("def run(meas, tdbparam):");
                                DEGFile.Add("    import pandas as pd");
                                DEGFile.Add("    from pandas import ExcelWriter");
                                DEGFile.Add("    from pandas import ExcelFile");
                                DEGFile.Add("    import evaluation_core.script_evaluation as se");
                                DEGFile.Add("    import time as ti");
                                DEGFile.Add("    import numpy as np");
                                DEGFile.Add("    ");
                                DEGFile.Add("    pd.set_option(\"max_columns\", 0)");
                                DEGFile.Add("    pd.set_option(\"max_rows\", 0)");
                                DEGFile.Add("    test_case = se.TestCase(meas.Data.index)");
                                DEGFile.Add("    ");
                                DEGFile.Add("    #-----------------------Pre-condition ----------------");
                                DEGFile.Add("    ");

                                DEGFile.Add("    #---> Checking Failure Ram");
                                if (currentlist.Failram_Value != null)
                                    DEGFile.Add("    test_case.add_precondition('Checking failure EEPROM',meas.Data.Meas_" + currentlist.Failram.ToUpper() + " == " + currentlist.Failram_Value + ")");
                                else
                                    DEGFile.Add("    #test_case.add_precondition('Checking failure EEPROM',meas.Data.Meas_" + currentlist.Failram.ToUpper() + " == " + currentlist.Failram_Value + ")");
                                DEGFile.Add("    ");

                                DEGFile.Add("    #-------------------- Acception Creteria --------------");
                                DEGFile.Add("    ");
                                DEGFile.Add("    #---> Checking Function Degradation");
                                DEGFile.Add("    ");

                                for (int s = 2; s <= itotalcols; s++)
                                {
                                    string value = (string)(xlWorkSheet.Cells[1, s] as Excel.Range).Value2;
                                    string check = (string)(xlWorkSheet.Cells[a, s].Text.ToString());

                                    if (Xcomponents.Contains(value))
                                    {
                                        if (check.Contains(','))
                                        {
                                            string[] temp = check.Split(',');
                                            string val = "    test_case.add_accept_crit('" + value + " disable',(meas.Data.MEAS_" + value.ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE == " + temp[0];
                                            for (int i = 1; i < temp.Length; i++)
                                            {
                                                val = val + ")" + " | " + "(meas.Data.MEAS_" + value.ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE == " + temp[i];
                                            }

                                            val = val + ")" + ",0.03)";
                                            DEGFile.Add(val);
                                            continue;
                                        }
                                        else
                                        {
                                            DEGFile.Add("    test_case.add_accept_crit('" + value + " disable',(np.bitwise_and(meas.Data.MEAS_" + value.ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE.values.astype(int), 0x0004))==" + (string)(xlWorkSheet.Cells[a, s].Text.ToString()) + ",0.03)");
                                            continue;
                                        }
                                    }

                                    if (Ycomponents.Contains(value))
                                    {
                                        if (check.Contains(','))
                                        {
                                            string[] temp = check.Split(',');
                                            string val = "    test_case.add_accept_crit('" + value + " disable',(meas.Data.MEAS_" + value.ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE == " + temp[0];
                                            for (int i = 1; i < temp.Length; i++)
                                            {
                                                val = val + ")" + " | " + "(meas.Data.MEAS_" + value.ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE == " + temp[i];
                                            }

                                            val = val + ")" + ",0.03)";
                                            DEGFile.Add(val); 
                                            continue;
                                        }
                                        else
                                        {
                                            DEGFile.Add("    test_case.add_accept_crit('" + value + " disable',np.bitwise_and(meas.Data.MEAS_" + value.ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE.astype(int), 0x0007)==" + (string)(xlWorkSheet.Cells[a, s].Text.ToString()) + ",0.03)");
                                            continue;
                                        }
                                    }

                                    if (check.Contains(','))
                                    {
                                        string[] temp = check.Split(',');
                                        string val = "    test_case.add_accept_crit('" + value + " disable',(meas.Data.MEAS_" + value.ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE == " + temp[0];
                                        for (int i = 1; i < temp.Length; i++)
                                        {
                                            val = val + ")" + " | " + "(meas.Data.MEAS_" + value.ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE == " + temp[i];
                                        }

                                        val = val + ")" + ",0.03)";
                                        DEGFile.Add(val);
                                    }
                                    else
                                    {
                                        DEGFile.Add("    test_case.add_accept_crit('" + value + " disable',meas.Data.MEAS_" + value.ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE == " + (string)(xlWorkSheet.Cells[a, s].Text.ToString()) + ",0.03)");
                                    }

                                }
                                DEGFile.Add("    return [test_case]");

                                if (checkBox1.Checked)
                                {
                                    if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\DEG"))
                                        Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\DEG");
                                    File.WriteAllLines(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\DEG\\SW_DEG_TestCase_" + filename + ".py", DEGFile);
                                }
                            }
                        }
                    }
                    else { }

                    if (Stop_clicked)
                    {
                        break;
                    }
                }

                List<string> Read_File = new List<string>();
                string[] BUSTestArray = AllTestRun.Except(AllFailure).ToArray();
                for (var i = 0; i < BUSTestArray.Length; i++)
                {
                    List<string> DTCFile = new List<string>();
                    Xml_Failure_details currentlist = datalist.Find(x => x.Failure_Name.Contains(BUSTestArray[i]));
                    Read_File.Add(BUSTestArray[i]);

                    if ((BUSTestArray[i].ToUpper()).Contains("_REC") || (BUSTestArray[i].ToUpper()).Contains("_MEM"))
                    {
                    }
                    else
                    {
                        if (BUSTestArray[i].EndsWith(".xml") || BUSTestArray[i].EndsWith(".ts"))
                        {
                        }
                        else
                        {
                            if (checkBox2.Checked)
                            {
                                DTCFile.Add("from utils.utils import get_dtc_log_signals");
                                DTCFile.Add("from pprint import pprint");
                                DTCFile.Add("   ");

                                DTCFile.Add("def run(meas, tdbparam):");
                                DTCFile.Add("    import pandas as pd");
                                DTCFile.Add("    from pandas import ExcelWriter");
                                DTCFile.Add("    from pandas import ExcelFile");
                                DTCFile.Add("    import evaluation_core.script_evaluation as se");
                                DTCFile.Add("    import time as ti");
                                DTCFile.Add("    import numpy as np");
                                DTCFile.Add("    ");
                                DTCFile.Add("    pd.set_option(\"max_columns\", 0)");
                                DTCFile.Add("    pd.set_option(\"max_rows\", 0)");
                                DTCFile.Add("    test_case = se.TestCase(meas.Data.index)");
                                DTCFile.Add("    ");
                                DTCFile.Add("    DTC_Status = {0xAF ,0x2F ,0xA3 ,0xA7 ,0x23 ,0x27};");
                                DTCFile.Add("    #-----------------------Pre-condition ----------------");
                                DTCFile.Add("    ");

                                DTCFile.Add("    #---> Check of DTC Value and DTC Status");
                                DTCFile.Add("    signals, errors = get_dtc_log_signals(meas.args, meas.signals)");
                                DTCFile.Add("    ");
                                DTCFile.Add("    #---> Checking Failure Ram");
                                if (currentlist.Failram_Value != null)
                                    DTCFile.Add("    test_case.add_precondition('Checking failure EEPROM',meas.Data.Meas_" + currentlist.Failram.ToUpper() + " == " + currentlist.Failram_Value + ")");
                                else
                                    DTCFile.Add("    #test_case.add_precondition('Checking failure EEPROM',meas.Data.Meas_" + currentlist.Failram.ToUpper() + " == " + currentlist.Failram_Value + ")");
                                DTCFile.Add("    ");

                                DTCFile.Add("    #-------------------- Acception Creteria --------------");
                                DTCFile.Add("    ");
                                if (currentlist.Failram_Value != null)
                                {
                                    DTCFile.Add("    if 'DTC_" + currentlist.Failure_Name + "' in signals:");
                                    DTCFile.Add("        test_case.add_accept_crit('DTC value = " + currentlist.DTC + "' , str(signals['DTC_" + currentlist.Failure_Name + "'].signal[0]).upper() == '" + currentlist.DTC + "'.upper())");
                                    DTCFile.Add("        test_case.add_accept_crit('DTCStatus value = 0xAF ,0x2F ,0xA3 ,0xA7 ,0x23 ,0x27 ' , any(x == (signals['DTCStatus_" + currentlist.Failure_Name + "'].signal[0]) for x in DTC_Status))");
                                    DTCFile.Add("    else:");
                                    DTCFile.Add("        test_case.add_accept_crit('DTC not getting set', 0 == 1)");
                                    DTCFile.Add("    ");
                                    DTCFile.Add("    return [test_case]");
                                }
                                else
                                {
                                    DTCFile.Add("    if 'DTC_" + currentlist.Failure_Name + "' in signals:");
                                    DTCFile.Add("        #test_case.add_accept_crit('DTC value = " + currentlist.DTC + "' , str(signals['DTC_" + currentlist.Failure_Name + "'].signal[0]).upper() == '" + currentlist.DTC + "'.upper())");
                                    DTCFile.Add("        # test_case.add_accept_crit('DTCStatus value = 0xAF ,0x2F ,0xA3 ,0xA7 ,0x23 ,0x27 ' , any(x == (signals['DTCStatus_" + currentlist.Failure_Name + "'].signal[0]) for x in DTC_Status))");
                                    DTCFile.Add("    else:");
                                    DTCFile.Add("        #test_case.add_accept_crit('DTC not getting set', 0 == 1)");
                                    DTCFile.Add("    ");
                                    DTCFile.Add("    return [test_case]");
                                }
                                if (checkBox2.Checked)
                                {
                                    if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\DTC\\Remaining"))
                                        Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\DTC\\Remaining");
                                    File.WriteAllLines(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\DTC\\Remaining\\SW_DTC_TestCase_" + BUSTestArray[i] + ".py", DTCFile);
                                }
                            }
                        }
                    }
                    if (Stop_clicked)
                    {
                        break;
                    }
                }

                Read_File.Add("--------------------");
                Read_File.Add("Mention failure bit doesn't have degradation state.We are checking only DTC for these type of failure bit");
                if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\Debug\\"))
                    Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\Debug\\");
                File.WriteAllLines(Directory.GetCurrentDirectory() + "\\Debug\\" + "Failure_Nothave_DegradationState.txt", Read_File);                               

                progressBar1.Value = 0;
                progressBar1.Visible = progressBar1.Enabled = false;
                button3.Enabled = true;
                Stop_clicked = textBox5.ReadOnly = textBox6.ReadOnly = false;
                // xlWorkBook.Close(false, null, null);
                MessageBox.Show("Test evaluation files are created");
                xlapp.Quit();

                Marshal.ReleaseComObject(xlWorkSheet);
                Marshal.ReleaseComObject(xlWorkBook);
                Marshal.ReleaseComObject(xlapp);
            }
            else { }
        }

        //-------------------------REC & MEM PY FILE ---------------------
        // REC & MEM___PY file generation
        // Thread create for REC & MEM PY file generation
        private void PY_Thread2_Click(object sender, EventArgs e)
        {
            List<Xml_Failure_details> datalist = new List<Xml_Failure_details>();
            List<Xml_Failure_details> datalist1 = new List<Xml_Failure_details>();
            List<Xml_Failure_details> datalist2 = new List<Xml_Failure_details>();
            List<string> Xcomponents = new List<string>();
            List<string> Ycomponents = new List<string>();

            string TestRun = Directory.GetCurrentDirectory() + "\\TestRun\\";  // 8

            string[] DegradationTable = null;
            string path1 = Directory.GetCurrentDirectory() + "\\DegradationTable\\";  //1
            try
            {
                DegradationTable = Directory.GetFiles(path1);
            }
            catch (DirectoryNotFoundException)
            {
                MessageBox.Show("Please keep DegradationTable folder with Database file..!!!!");
                return;
            }

            string[] XML_File = null;
            string path2 = Directory.GetCurrentDirectory() + "\\XML_File\\";  // 4
            try
            {
                XML_File = Directory.GetFiles(path2);
            }
            catch (DirectoryNotFoundException)
            {
                MessageBox.Show("Please keep XML_File folder with Xml file..!!!!");
                return;
            }

            try
            {
                if (DegradationTable[0] != string.Empty && XML_File[0] != string.Empty && TestRun != string.Empty)
                {
                }
            }
            catch (IndexOutOfRangeException)
            {
                MessageBox.Show("All Fileds are mandatory..!!!!\n 1.DEG Table\n 2.XML File\n 3.TestRun Folder\n 4.DTC Status value");
                return;
            }

            if (DegradationTable[0] != string.Empty && XML_File[0] != string.Empty && TestRun != string.Empty)
            {
                foreach (string currentname in textBox5.Lines)
                {
                    Xcomponents.Add(currentname);
                }
                foreach (string currentname in textBox6.Lines)
                {
                    Ycomponents.Add(currentname);
                }

                button3.Enabled = false;
                XmlDocument xmldoc = new XmlDocument();
                xmldoc.Load(XML_File[0]);

                List<string> AllFSF_failure = new List<string>();
                XmlNodeList nodeList = xmldoc.DocumentElement.SelectNodes("/root/Failure_Bit");
                foreach (XmlNode nxmNode in nodeList)
                {
                    Xml_Failure_details sample = new Xml_Failure_details();
                    XmlElement element = (XmlElement)nxmNode;

                    sample.Failure_Name = element.ChildNodes.Item(0).InnerText.Trim();
                    sample.DTC = element.ChildNodes.Item(1).InnerText.Trim();
                    sample.Failram = element.ChildNodes.Item(4).InnerText.Trim();
                    sample.Failram_Value = element.ChildNodes.Item(6).InnerText.Trim();
                    sample.Failram_Mem = element.ChildNodes.Item(5).InnerText.Trim();

                    AllFSF_failure.Add(sample.Failure_Name);
                    datalist.Add(sample);
                }

                List<string> AllFSF4_failure = new List<string>();
                XmlNodeList nodeList1 = xmldoc.DocumentElement.SelectNodes("/root/FSF4_Bit");

                foreach (XmlNode nxmNode in nodeList1)
                {
                    Xml_Failure_details sample1 = new Xml_Failure_details();
                    XmlElement element = (XmlElement)nxmNode;

                    sample1.Failure_Name = element.ChildNodes.Item(0).InnerText.Trim();
                    sample1.DTC = element.ChildNodes.Item(1).InnerText.Trim();
                    sample1.Failram = element.ChildNodes.Item(4).InnerText.Trim();
                    sample1.Failram_Value = element.ChildNodes.Item(6).InnerText.Trim();
                    sample1.Failram_Mem = element.ChildNodes.Item(5).InnerText.Trim();

                    AllFSF4_failure.Add(sample1.Failure_Name);
                    datalist1.Add(sample1);
                }

                List<string> AllBUS_failure = new List<string>();
                XmlNodeList nodeList2 = xmldoc.DocumentElement.SelectNodes("/root/BUS_Bit");
                foreach (XmlNode nxmNode in nodeList2)
                {
                    Xml_Failure_details sample2 = new Xml_Failure_details();
                    XmlElement element = (XmlElement)nxmNode;

                    sample2.Failure_Name = element.ChildNodes.Item(0).InnerText.Trim();
                    sample2.DTC = element.ChildNodes.Item(1).InnerText.Trim();
                    sample2.Failram = element.ChildNodes.Item(4).InnerText.Trim();
                    sample2.Failram_Value = element.ChildNodes.Item(6).InnerText.Trim();

                    AllBUS_failure.Add(sample2.Failure_Name);
                    datalist2.Add(sample2);
                }

                Excel.Application xlapp = new Excel.Application();
                Excel.Workbook xlWorkBook;
                Excel.Worksheet xlWorkSheet;

                xlWorkBook = xlapp.Workbooks.Open(DegradationTable[0]);
                xlWorkSheet = xlWorkBook.ActiveSheet;
                int iTotalRows = xlWorkSheet.UsedRange.Rows.Count;
                int itotalcols = xlWorkSheet.UsedRange.Columns.Count;
                List<string> AllFailure = new List<string>();

                for (int s = 3; s <= iTotalRows; s++)
                {
                    string failureName = (string)(xlWorkSheet.Cells[s, 1] as Excel.Range).Value2;
                    AllFailure.Add(failureName);
                }

                List<string> AllTestRun = new List<string>();
                string[] files = null;
                try
                {
                    files = Directory.GetFiles(TestRun);
                }
                catch (DirectoryNotFoundException)
                {
                    MessageBox.Show("Please keep TestRun folder with TestRun file..!!!!");
                    return;
                }
                foreach (string file in files)
                {
                    string name = file.Substring(file.LastIndexOf("\\") + 1);
                    AllTestRun.Add(name);
                }

                string newfolder = DateTime.Now.ToString();
                newfolder = newfolder.Replace("/", "-").Replace(":", "-");
                newfolder = "Rec_Mem_" + newfolder;
                if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder))
                    Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder);

                progressBar3.Value = 0;
                progressBar3.Maximum = iTotalRows;
                progressBar3.Visible = true;

                for (int a = 3; a <= iTotalRows; a++)
                {
                    progressBar3.Value = a;
                    textBox5.ReadOnly = textBox6.ReadOnly = true;
                    List<string> REC_MEMFile = new List<string>();
                    string filename = (string)(xlWorkSheet.Cells[a, 1] as Excel.Range).Value2;
                    if (string.IsNullOrEmpty(filename))
                        continue;

                    if (AllTestRun.Any(s => s.Contains(filename)))
                    {
                        if (!(AllBUS_failure.Any(s => s.Contains(filename))))
                        {
                            Xml_Failure_details currentlist = datalist.Find(x => x.Failure_Name.Contains(filename));

                            if (AllFSF4_failure.Any(s => s.Contains(filename)))
                            {
                                currentlist = datalist1.Find(x => x.Failure_Name.Contains(filename));
                            }

                            REC_MEMFile.Add("from utils.utils import get_dtc_log_signals");
                            REC_MEMFile.Add("from pprint import pprint");
                            REC_MEMFile.Add("   ");

                            REC_MEMFile.Add("def run(meas, tdbparam):");
                            REC_MEMFile.Add("    import pandas as pd");
                            REC_MEMFile.Add("    from pandas import ExcelWriter");
                            REC_MEMFile.Add("    from pandas import ExcelFile");
                            REC_MEMFile.Add("    import evaluation_core.script_evaluation as se");
                            REC_MEMFile.Add("    import time as ti");
                            REC_MEMFile.Add("    import numpy as np");
                            REC_MEMFile.Add("    ");
                            REC_MEMFile.Add("    pd.set_option(\"max_columns\", 0)");
                            REC_MEMFile.Add("    pd.set_option(\"max_rows\", 0)");
                            REC_MEMFile.Add("    test_case = se.TestCase(meas.Data.index)");
                            REC_MEMFile.Add("    ");
                            REC_MEMFile.Add("    DTC_Status = {0xAF ,0x2F ,0xA3 ,0xA7 ,0x23 ,0x27};");
                            REC_MEMFile.Add("    #-----------------------Pre-condition ----------------");
                            REC_MEMFile.Add("    ");

                            REC_MEMFile.Add("    #---> Check of DTC Value and DTC Status");
                            REC_MEMFile.Add("    signals, errors = get_dtc_log_signals(meas.args, meas.signals)");
                            REC_MEMFile.Add("    ");
                            REC_MEMFile.Add("    #---> Checking Failure Ram");
                            if (currentlist.Failram_Value != null)
                            {
                                REC_MEMFile.Add("    test_case.add_precondition('Checking failure EEPROM',meas.Data.Meas_" + currentlist.Failram.ToUpper() + ".diff()" + " == " + "-" + currentlist.Failram_Value + ")");
                                REC_MEMFile.Add("    test_case.add_precondition('Checking failure EEPROM',meas.Data.Meas_" + currentlist.Failram_Mem.ToUpper() + ".diff()" + " == " + "-" + currentlist.Failram_Value + ")");
                            }
                            else
                            {
                                REC_MEMFile.Add("    #test_case.add_precondition('Checking failure EEPROM',meas.Data.Meas_" + currentlist.Failram.ToUpper() + ".diff()" + " == " + "-" + currentlist.Failram_Value + ")");
                                REC_MEMFile.Add("    #test_case.add_precondition('Checking failure EEPROM',meas.Data.Meas_" + currentlist.Failram_Mem.ToUpper() + ".diff()" + " == " + "-" + currentlist.Failram_Value + ")");
                            }
                            REC_MEMFile.Add("    ");

                            if (!(AllFSF4_failure.Any(s => s.Contains(filename))))
                            {
                                REC_MEMFile.Add("    #-------------------- Acception Creteria Checking DTC --------------");
                                REC_MEMFile.Add("    ");
                                if (currentlist.Failram_Value != null)
                                {
                                    REC_MEMFile.Add("    if 'DTC_" + currentlist.Failure_Name + "' in signals:");
                                    REC_MEMFile.Add("        test_case.add_accept_crit('DTC value = " + currentlist.DTC + "' , str(signals['DTC_" + currentlist.Failure_Name + "'].signal[0]).upper() == '" + currentlist.DTC + "'.upper())");
                                    REC_MEMFile.Add("        test_case.add_accept_crit('DTCStatus value should not = 0xAF ,0x2F ,0xA3 ,0xA7 ,0x23 ,0x27 ' , ~(any(x == (signals['DTCStatus_" + currentlist.Failure_Name + "'].signal[0]) for x in DTC_Status)))");
                                    REC_MEMFile.Add("    else:");
                                    REC_MEMFile.Add("        test_case.add_accept_crit('DTC not getting set', 0 == 1)");
                                    REC_MEMFile.Add("    ");
                                }
                                else
                                {
                                    REC_MEMFile.Add("    if 'DTC_" + currentlist.Failure_Name + "' in signals:");
                                    REC_MEMFile.Add("        #test_case.add_accept_crit('DTC value = " + currentlist.DTC + "' , str(signals['DTC_" + currentlist.Failure_Name + "'].signal[0]).upper() == '" + currentlist.DTC + "'.upper())");
                                    REC_MEMFile.Add("        # test_case.add_accept_crit('DTCStatus value should not = 0xAF ,0x2F ,0xA3 ,0xA7 ,0x23 ,0x27 ' , ~(any(x == (signals['DTCStatus_" + currentlist.Failure_Name + "'].signal[0]) for x in DTC_Status)))");
                                    REC_MEMFile.Add("    else:");
                                    REC_MEMFile.Add("        #test_case.add_accept_crit('DTC not getting set', 0 == 1)");
                                    REC_MEMFile.Add("    ");
                                }
                            }
                            REC_MEMFile.Add("    #-------------------- Acception Creteria Checking DEG--------------");
                            REC_MEMFile.Add("    ");
                            REC_MEMFile.Add("    #---> Checking Function Degradation");
                            REC_MEMFile.Add("    ");
                            for (int s = 2; s <= itotalcols; s++)
                            {
                                string value = (string)(xlWorkSheet.Cells[1, s] as Excel.Range).Value2;
                                string check = (string)(xlWorkSheet.Cells[2, s].Text.ToString());

                                if (Xcomponents.Contains(value))
                                {
                                    if (check.Contains(','))
                                    {
                                        string[] temp = check.Split(',');
                                        string val = "    test_case.add_accept_crit('" + value + " disable',(meas.Data.MEAS_" + value.ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE == " + temp[0];
                                        for (int i = 1; i < temp.Length; i++)
                                        {
                                            val = val + ")" + " | " + "(meas.Data.MEAS_" + value.ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE == " + temp[i];
                                        }

                                        val = val + ")" + ",0.03)";
                                        REC_MEMFile.Add(val); 
                                        continue;
                                    }
                                    else
                                    {
                                        REC_MEMFile.Add("    test_case.add_accept_crit('" + value + " disable',(np.bitwise_and(meas.Data.MEAS_" + value.ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE.values.astype(int), 0x0030)>>4)==" + (string)(xlWorkSheet.Cells[2, s].Text.ToString()) + ",0.02)");
                                        continue;
                                    }
                                }

                                if (Ycomponents.Contains(value))
                                {
                                    if (check.Contains(','))
                                    {
                                        string[] temp = check.Split(',');
                                        string val = "    test_case.add_accept_crit('" + value + " disable',(meas.Data.MEAS_" + value.ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE == " + temp[0];
                                        for (int i = 1; i < temp.Length; i++)
                                        {
                                            val = val + ")" + " | " + "(meas.Data.MEAS_" + value.ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE == " + temp[i];
                                        }

                                        val = val + ")" + ",0.03)";
                                        REC_MEMFile.Add(val); 
                                        continue;
                                    }
                                    else
                                    {
                                        REC_MEMFile.Add("    test_case.add_accept_crit('" + value + " disable',np.bitwise_and(meas.Data.MEAS_" + value.ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE.astype(int), 0x0007)==" + (string)(xlWorkSheet.Cells[2, s].Text.ToString()) + ",0.02)");
                                        continue;
                                    }
                                }

                                if (check.Contains(','))
                                {
                                    string[] temp = check.Split(',');
                                    string val = "    test_case.add_accept_crit('" + value + " disable',(meas.Data.MEAS_" + value.ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE == " + temp[0];
                                    for (int i = 1; i < temp.Length; i++)
                                    {
                                        val = val + ")" + " | " + "(meas.Data.MEAS_" + value.ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE == " + temp[i];
                                    }

                                    val = val + ")" + ",0.03)";
                                    REC_MEMFile.Add(val);
                                }
                                else
                                {
                                    REC_MEMFile.Add("    test_case.add_accept_crit('" + value + " disable',meas.Data.MEAS_" + value.ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE == " + (string)(xlWorkSheet.Cells[2, s].Text.ToString()) + ",0.02)");
                                }

                            }
                            REC_MEMFile.Add("    return [test_case]");


                            if (checkBox6.Checked)
                            {
                                if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\MEM"))
                                    Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\MEM");
                                File.WriteAllLines(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\MEM" + "\\SW_MEM_TestCase_" + filename + ".py", REC_MEMFile);
                            }

                            if (checkBox5.Checked)
                            {
                                if (REC_MEMFile.Any(s => s.Contains("FAIL_RAM_MEM")))
                                {
                                    REC_MEMFile.Remove("    test_case.add_precondition('Checking failure EEPROM',meas.Data.Meas_" + currentlist.Failram_Mem + ".diff()" + " == " + "-" + currentlist.Failram_Value + ")");
                                }

                                if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\REC"))
                                    Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\REC");
                                File.WriteAllLines(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\REC" + "\\SW_REC_TestCase_" + filename + ".py", REC_MEMFile);
                            }
                        }
                        else { }
                    }
                    if (Stop_clicked)
                    {
                        break;
                    }
                }


                string[] RemainTestArray = AllTestRun.Except(AllFailure).ToArray();
                for (var i = 0; i < RemainTestArray.Length; i++)
                {
                    List<string> REC_DTCFile = new List<string>();

                    if (!(AllBUS_failure.Any(s => s.Contains(RemainTestArray[i]))))
                    {
                        Xml_Failure_details currentlist = datalist.Find(x => x.Failure_Name.Contains(RemainTestArray[i]));

                        if (AllFSF4_failure.Any(s => s.Contains(RemainTestArray[i])))
                        {
                            currentlist = datalist1.Find(x => x.Failure_Name.Contains(RemainTestArray[i]));
                        }

                        if (checkBox5.Checked)
                        {
                            REC_DTCFile.Add("from utils.utils import get_dtc_log_signals");
                            REC_DTCFile.Add("from pprint import pprint");
                            REC_DTCFile.Add("   ");

                            REC_DTCFile.Add("def run(meas, tdbparam):");
                            REC_DTCFile.Add("    import pandas as pd");
                            REC_DTCFile.Add("    from pandas import ExcelWriter");
                            REC_DTCFile.Add("    from pandas import ExcelFile");
                            REC_DTCFile.Add("    import evaluation_core.script_evaluation as se");
                            REC_DTCFile.Add("    import time as ti");
                            REC_DTCFile.Add("    import numpy as np");
                            REC_DTCFile.Add("    ");
                            REC_DTCFile.Add("    pd.set_option(\"max_columns\", 0)");
                            REC_DTCFile.Add("    pd.set_option(\"max_rows\", 0)");
                            REC_DTCFile.Add("    test_case = se.TestCase(meas.Data.index)");
                            REC_DTCFile.Add("    ");
                            REC_DTCFile.Add("    DTC_Status = {0xAF ,0x2F ,0xA3 ,0xA7 ,0x23 ,0x27};");
                            REC_DTCFile.Add("    #-----------------------Pre-condition ----------------");
                            REC_DTCFile.Add("    ");

                            REC_DTCFile.Add("    #---> Check of DTC Value and DTC Status");
                            REC_DTCFile.Add("    signals, errors = get_dtc_log_signals(meas.args, meas.signals)");
                            REC_DTCFile.Add("    ");
                            REC_DTCFile.Add("    #---> Checking Failure Ram");
                            if (currentlist.Failram_Value != null)
                            {
                                REC_DTCFile.Add("    test_case.add_precondition('Checking failure EEPROM',meas.Data.Meas_" + currentlist.Failram.ToUpper() + ".diff()" + " == " + "-" + currentlist.Failram_Value + ")");
                                REC_DTCFile.Add("    test_case.add_precondition('Checking failure EEPROM',meas.Data.Meas_" + currentlist.Failram_Mem.ToUpper() + ".diff()" + " == " + "-" + currentlist.Failram_Value + ")");
                            }
                            else
                            {
                                REC_DTCFile.Add("    #test_case.add_precondition('Checking failure EEPROM',meas.Data.Meas_" + currentlist.Failram.ToUpper() + ".diff()" + " == " + "-" + currentlist.Failram_Value + ")");
                                REC_DTCFile.Add("    #test_case.add_precondition('Checking failure EEPROM',meas.Data.Meas_" + currentlist.Failram_Mem.ToUpper() + ".diff()" + " == " + "-" + currentlist.Failram_Value + ")");

                            }
                            REC_DTCFile.Add("    ");

                            REC_DTCFile.Add("    #-------------------- Acception Creteria --------------");
                            REC_DTCFile.Add("    ");
                            if (currentlist.Failram_Value != null)
                            {
                                REC_DTCFile.Add("    if 'DTC_" + currentlist.Failure_Name + "' in signals:");
                                REC_DTCFile.Add("        test_case.add_accept_crit('DTC value = " + currentlist.DTC + "' , str(signals['DTC_" + currentlist.Failure_Name + "'].signal[0]).upper() == '" + currentlist.DTC + "'.upper())");
                                REC_DTCFile.Add("        test_case.add_accept_crit('DTCStatus value should not = 0xAF ,0x2F ,0xA3 ,0xA7 ,0x23 ,0x27 ' , ~(any(x == (signals['DTCStatus_" + currentlist.Failure_Name + "'].signal[0]) for x in DTC_Status)))");
                                REC_DTCFile.Add("    else:");
                                REC_DTCFile.Add("        test_case.add_accept_crit('DTC not getting set', 0 == 1)");
                                REC_DTCFile.Add("    ");
                                REC_DTCFile.Add("    return [test_case]");
                            }
                            else
                            {
                                REC_DTCFile.Add("    if 'DTC_" + currentlist.Failure_Name + "' in signals:");
                                REC_DTCFile.Add("        #test_case.add_accept_crit('DTC value = " + currentlist.DTC + "' , str(signals['DTC_" + currentlist.Failure_Name + "'].signal[0]).upper() == '" + currentlist.DTC + "'.upper())");
                                REC_DTCFile.Add("        #test_case.add_accept_crit('DTCStatus value should not = 0xAF ,0x2F ,0xA3 ,0xA7 ,0x23 ,0x27 ' , ~(any(x == (signals['DTCStatus_" + currentlist.Failure_Name + "'].signal[0]) for x in DTC_Status)))");
                                REC_DTCFile.Add("    else:");
                                REC_DTCFile.Add("        #test_case.add_accept_crit('DTC not getting set', 0 == 1)");
                                REC_DTCFile.Add("    ");
                                REC_DTCFile.Add("    return [test_case]");
                            }

                            if (checkBox6.Checked)
                            {
                                if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\MEM" + "\\Remaning"))
                                    Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\MEM" + "\\Remaning");
                                File.WriteAllLines(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\MEM" + "\\Remaning\\SW_MEM_TestCase_" + RemainTestArray[i] + ".py", REC_DTCFile);
                            }

                            if (checkBox5.Checked)
                            {
                                if (REC_DTCFile.Any(s => s.Contains("FAIL_RAM_MEM")))
                                {
                                    REC_DTCFile.Remove("    test_case.add_precondition('Checking failure EEPROM',meas.Data.Meas_" + currentlist.Failram_Mem + ".diff()" + " == " + "-" + currentlist.Failram_Value + ")");
                                }

                                if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\REC" + "\\Remaning"))
                                    Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\REC" + "\\Remaning");
                                File.WriteAllLines(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\REC" + "\\Remaning\\SW_REC_TestCase_" + RemainTestArray[i] + ".py", REC_DTCFile);
                            }
                        }
                        if (Stop_clicked)
                        {
                            break;
                        }
                    }
                }

                progressBar3.Visible = false;
                button3.Enabled = true;
                Stop_clicked = textBox5.ReadOnly = textBox6.ReadOnly = false;
                MessageBox.Show("REC & MEM -> Test evaluation files are created");

                Marshal.ReleaseComObject(xlWorkSheet);
                Marshal.ReleaseComObject(xlWorkBook);
                Marshal.ReleaseComObject(xlapp);
            }
            else { }
        }


        //--------------------------DATABASE Upadte ----------------------
        // DATABASE update button
        private void Update_Database_Click(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false;

            thread3 = new Thread(() => Database_Thread_Click(sender, e));
            thread3.Start();
        }

        //--------------------------DATABASE Upadte Thread ---------------
        // Thread create for DATABASE update
        private void Database_Thread_Click(object sender, EventArgs e)
        {
            List<Xml_Failure_details> datalist = new List<Xml_Failure_details>();
            List<Xml_Failure_details> datalist1 = new List<Xml_Failure_details>();
            List<Xml_Failure_details> datalist2 = new List<Xml_Failure_details>();
            List<string> Xcomponents = new List<string>();
            List<string> Ycomponents = new List<string>();

            string TestRun = Directory.GetCurrentDirectory() + "\\TestRun\\";  // 8

            string[] DegradationTable = null;
            string path1 = Directory.GetCurrentDirectory() + "\\DegradationTable\\";  //1
            try
            {
                DegradationTable = Directory.GetFiles(path1);
            }
            catch (DirectoryNotFoundException)
            {
                MessageBox.Show("Please keep DegradationTable folder with Database file..!!!!");
                return;
            }

            string[] XML_File = null;
            string path2 = Directory.GetCurrentDirectory() + "\\XML_File\\";  // 4
            try
            {
                XML_File = Directory.GetFiles(path2);
            }
            catch (DirectoryNotFoundException)
            {
                MessageBox.Show("Please keep XML_File folder with Xml file..!!!!");
                return;
            }

            string[] DataBase = null;
            string path3 = Directory.GetCurrentDirectory() + "\\DataBase\\";  // 2                      
            try
            {
                DataBase = Directory.GetFiles(path3);
            }
            catch (DirectoryNotFoundException)
            {
                MessageBox.Show("Please keep DataBase folder with Templet database file..!!!!");
                return;
            }

            try
            {
                if (DegradationTable[0] != string.Empty && DataBase[0] != string.Empty && XML_File[0] != string.Empty && TestRun != string.Empty)
                {
                }
            }
            catch (IndexOutOfRangeException)
            {
                MessageBox.Show("All Fileds are mandatory..!!!!\n 1.DEG Table\n 2.XML File\n 3.TBD\n 4.TestRun Folder");
                return;
            }

            if (DegradationTable[0] != string.Empty && DataBase[0] != string.Empty && XML_File[0] != string.Empty && TestRun != string.Empty)
            {
                foreach (string currentname in textBox5.Lines)
                {
                    Xcomponents.Add(currentname);
                }
                foreach (string currentname in textBox6.Lines)
                {
                    Ycomponents.Add(currentname);
                }

                button8.Enabled = false;
                XmlDocument xmldoc = new XmlDocument();
                xmldoc.Load(XML_File[0]);

                List<string> AllFSF_failure = new List<string>();
                XmlNodeList nodeList = xmldoc.DocumentElement.SelectNodes("/root/Failure_Bit");
                foreach (XmlNode nxmNode in nodeList)
                {
                    Xml_Failure_details sample = new Xml_Failure_details();
                    XmlElement element = (XmlElement)nxmNode;

                    sample.Failure_Name = element.ChildNodes.Item(0).InnerText.Trim();
                    sample.DTC = element.ChildNodes.Item(1).InnerText.Trim();
                    sample.Failram = element.ChildNodes.Item(4).InnerText.Trim();
                    sample.Failram_Value = element.ChildNodes.Item(6).InnerText.Trim();
                    sample.Failram_Mem = element.ChildNodes.Item(5).InnerText.Trim();

                    AllFSF_failure.Add(sample.Failure_Name);
                    datalist.Add(sample);
                }

                List<string> AllFSF4_failure = new List<string>();
                XmlNodeList nodeList1 = xmldoc.DocumentElement.SelectNodes("/root/FSF4_Bit");
                foreach (XmlNode nxmNode in nodeList1)
                {
                    Xml_Failure_details sample1 = new Xml_Failure_details();
                    XmlElement element = (XmlElement)nxmNode;

                    sample1.Failure_Name = element.ChildNodes.Item(0).InnerText.Trim();
                    sample1.DTC = element.ChildNodes.Item(1).InnerText.Trim();
                    sample1.Failram = element.ChildNodes.Item(4).InnerText.Trim();
                    sample1.Failram_Value = element.ChildNodes.Item(6).InnerText.Trim();
                    sample1.Failram_Mem = element.ChildNodes.Item(5).InnerText.Trim();

                    AllFSF4_failure.Add(sample1.Failure_Name);
                    datalist1.Add(sample1);
                }

                List<string> AllBUS_failure = new List<string>();
                XmlNodeList nodeList2 = xmldoc.DocumentElement.SelectNodes("/root/BUS_Bit");
                foreach (XmlNode nxmNode in nodeList2)
                {
                    Xml_Failure_details sample2 = new Xml_Failure_details();
                    XmlElement element = (XmlElement)nxmNode;

                    sample2.Failure_Name = element.ChildNodes.Item(0).InnerText.Trim();
                    sample2.DTC = element.ChildNodes.Item(1).InnerText.Trim();
                    sample2.Failram = element.ChildNodes.Item(4).InnerText.Trim();
                    sample2.Failram_Value = element.ChildNodes.Item(6).InnerText.Trim();

                    AllBUS_failure.Add(sample2.Failure_Name);
                    datalist2.Add(sample2);
                }

                Excel.Application xlapp = new Excel.Application();
                Excel.Workbook xlWorkBook;
                Excel.Worksheet xlWorkSheet;

                xlWorkBook = xlapp.Workbooks.Open(DegradationTable[0]);
                xlWorkSheet = xlWorkBook.ActiveSheet;
                int iTotalRows = xlWorkSheet.UsedRange.Rows.Count;
                int itotalcols = xlWorkSheet.UsedRange.Columns.Count;

                // Create TestRun list from TestRun folder
                List<string> AllTestRun = new List<string>();
                string[] files = Directory.GetFiles(TestRun);
                foreach (string file in files)
                {
                    string name = file.Substring(file.LastIndexOf("\\") + 1);
                    AllTestRun.Add(name);
                }

                List<string> ControlFunc = new List<string>();
                for (int s = 2; s <= itotalcols; s++)
                {
                    string colname = (string)(xlWorkSheet.Cells[1, s] as Excel.Range).Value2;
                    ControlFunc.Add(colname);
                }

                xlWorkBook.Close();
                xlWorkBook = xlapp.Workbooks.Open(DataBase[0]);

                //////////////////////////////////////////////////////MappingList///////////////////////////////
                int count = 0;
                if (checkBox3.Checked)
                {
                    progressBar2.Value = 0;
                    progressBar2.Maximum = (30 * AllTestRun.Count());
                    progressBar2.Visible = true;

                    xlWorkSheet = xlWorkBook.Worksheets["04-MappingList"];

                    int iTotalRows_TDB = xlWorkSheet.UsedRange.Rows.Count;
                    int itotalcols_TDB = xlWorkSheet.UsedRange.Columns.Count;

                    if (string.IsNullOrEmpty(textBox1.Text))
                    {
                        int i = 8; int j = 8; int temp = 10;
                        string[] RemainingControlFun = null;
                        RemainingControlFun = ControlFunc.ToArray();

                        if ((string)(xlWorkSheet.Cells[8, 1].Text.ToString()) == "DEGRADATION STATEs:")
                        {
                            List<string> AllDegradationASAP = new List<string>();
                            for (int a = 10; a <= iTotalRows_TDB; a++)
                            {
                                string DegState = (string)(xlWorkSheet.Cells[a, 7].Text.ToString());
                                string Temp = (string)(xlWorkSheet.Cells[a, 1].Text.ToString());
                                if (Temp == "FAIL RAM Information:")
                                {
                                    temp = a;
                                    j = a;
                                    break;
                                }
                                AllDegradationASAP.Add(DegState);
                            }
                            RemainingControlFun = ControlFunc.Except(AllDegradationASAP).ToArray();
                        }

                        xlWorkSheet.Cells[i, 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Yellow);
                        xlWorkSheet.Cells[i, 1] = "DEGRADATION STATEs:";
                        i++; j++;
                        foreach (string controlfun in RemainingControlFun)
                        {
                            progressBar2.Value = count++;
                            string value = controlfun;
                            Excel.Range line = (Excel.Range)xlWorkSheet.Rows[++i];
                            line.Insert();
                            xlWorkSheet.Cells[i, 1] = "{{MEAS_" + value.ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE}}";
                            xlWorkSheet.Cells[i, 2] = "DEGRADATION INFO";
                            xlWorkSheet.Cells[i, 3] = "ASAP";
                            xlWorkSheet.Cells[i, 7] = controlfun;
                            ++j;
                            if (Stop_clicked)
                            {
                                break;
                            }
                        }

                        List<string> AllFailRamASAP = new List<string>();
                        for (int k = j + 1; k <= iTotalRows_TDB; k++)
                        {
                            string Fail_Ram = (string)(xlWorkSheet.Cells[k, 7].Text.ToString());
                            AllFailRamASAP.Add(Fail_Ram);
                        }

                        if (temp == 10)
                        {
                            i = j + 1;
                        }
                        else
                        {
                            i = temp;
                        }

                        xlWorkSheet.Cells[i, 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Yellow);
                        xlWorkSheet.Cells[i, 1] = "FAIL RAM Information:";
                        i++;
                        foreach (string sample in datalist.Select(x => x.Failram).Distinct())
                        {
                            progressBar2.Value = count++;

                            if (!(AllFailRamASAP.Contains(sample)))
                            {
                                Excel.Range line = (Excel.Range)xlWorkSheet.Rows[++i];
                                line.Insert();
                                xlWorkSheet.Cells[i, 1] = "{{Meas_" + sample.ToUpper() + "}}";
                                xlWorkSheet.Cells[i, 2] = "FAILURE BITS";
                                xlWorkSheet.Cells[i, 3] = "ASAP";
                                xlWorkSheet.Cells[i, 7] = sample;

                                if (!sample.Contains("Fbd_cur_"))
                                {
                                    line = (Excel.Range)xlWorkSheet.Rows[++i];
                                    line.Insert();
                                    xlWorkSheet.Cells[i, 1] = "{{Meas_" + sample.ToUpper() + "_final}}";
                                    xlWorkSheet.Cells[i, 2] = "FAILURE BITS";
                                    xlWorkSheet.Cells[i, 3] = "ASAP";
                                    xlWorkSheet.Cells[i, 7] = sample + "_final";
                                }
                            }

                            if (Stop_clicked)
                            {
                                break;
                            }
                        }

                        foreach (string sample in datalist2.Select(x => x.Failram).Distinct())
                        {
                            progressBar2.Value = count++;

                            if (!(AllFailRamASAP.Contains(sample)))
                            {
                                Excel.Range line = (Excel.Range)xlWorkSheet.Rows[++i];
                                line.Insert();
                                xlWorkSheet.Cells[i, 1] = "{{Meas_" + sample.ToUpper() + "}}";
                                xlWorkSheet.Cells[i, 2] = "FAILURE BITS";
                                xlWorkSheet.Cells[i, 3] = "ASAP";
                                xlWorkSheet.Cells[i, 7] = sample;
                            }
                            if (Stop_clicked)
                            {
                                break;
                            }
                        }

                        foreach (string sample in datalist1.Select(x => x.Failram).Distinct())
                        {
                            progressBar2.Value = count++;
                            if (!(AllFailRamASAP.Contains(sample)))
                            {
                                Excel.Range line = (Excel.Range)xlWorkSheet.Rows[++i];
                                line.Insert();
                                xlWorkSheet.Cells[i, 1] = "{{Meas_" + sample.ToUpper() + "}}";
                                xlWorkSheet.Cells[i, 2] = "FAILURE BITS";
                                xlWorkSheet.Cells[i, 3] = "ASAP";
                                xlWorkSheet.Cells[i, 7] = sample;

                                line = (Excel.Range)xlWorkSheet.Rows[++i];
                                line.Insert();
                                xlWorkSheet.Cells[i, 1] = "{{Meas_" + sample.ToUpper() + "_final}}";
                                xlWorkSheet.Cells[i, 2] = "FAILURE BITS";
                                xlWorkSheet.Cells[i, 3] = "ASAP";
                                xlWorkSheet.Cells[i, 7] = sample + "_final";
                            }
                            if (Stop_clicked)
                            {
                                break;
                            }
                        }

                        foreach (string sample in datalist.Select(x => x.Failram_Mem).Distinct())
                        {
                            progressBar2.Value = count++;

                            if (!(AllFailRamASAP.Contains(sample)))
                            {
                                Excel.Range line = (Excel.Range)xlWorkSheet.Rows[++i];
                                line.Insert();
                                xlWorkSheet.Cells[i, 1] = "{{Meas_" + sample.ToUpper() + "}}";
                                xlWorkSheet.Cells[i, 2] = "FAILURE BITS";
                                xlWorkSheet.Cells[i, 3] = "ASAP";
                                xlWorkSheet.Cells[i, 7] = sample;
                            }
                            if (Stop_clicked)
                            {
                                break;
                            }
                        }

                        foreach (string sample in datalist1.Select(x => x.Failram_Mem).Distinct())
                        {
                            progressBar2.Value = count++;

                            if (!(AllFailRamASAP.Contains(sample)))
                            {
                                Excel.Range line = (Excel.Range)xlWorkSheet.Rows[++i];
                                line.Insert();
                                xlWorkSheet.Cells[i, 1] = "{{Meas_" + sample.ToUpper() + "}}";
                                xlWorkSheet.Cells[i, 2] = "FAILURE BITS";
                                xlWorkSheet.Cells[i, 3] = "ASAP";
                                xlWorkSheet.Cells[i, 7] = sample;
                            }
                            if (Stop_clicked)
                            {
                                break;
                            }
                        }
                    }
                    else
                    {
                        int i = 8; int j = 8; int temp = 10;
                        string[] RemainingControlFun = null;
                        RemainingControlFun = ControlFunc.ToArray();
                        int ColumnNumber = 10; int check = 0;
                        
                        string project = textBox1.Text;
                        for (int temp1 = 1; temp1 <= itotalcols_TDB; temp1++)
                        {
                            string Project1 = (string)(xlWorkSheet.Cells[2, temp1] as Excel.Range).Value2;
                            
                            if (Project1 == project)
                            {
                                // Project name present 
                                ColumnNumber = temp1;
                                check = 10;
                                break;
                            }
                            else
                            {
                                // Project name not present
                            }
                        }

                        if (check != 10)                // Adding new column for which preoject now availabe
                        {
                            Excel.Range line = (Excel.Range)xlWorkSheet.Columns[ColumnNumber];
                            line.Insert();
                            xlWorkSheet.Cells[2, ColumnNumber] = textBox1.Text;
                            xlWorkSheet.Cells[3, ColumnNumber] = "Name";
                            line = (Excel.Range)xlWorkSheet.Columns[ColumnNumber + 1];
                            line.Insert();
                            xlWorkSheet.Cells[3, ColumnNumber + 1] = "Value(s)";
                            line = (Excel.Range)xlWorkSheet.Columns[ColumnNumber + 2];
                            line.Insert();
                            xlWorkSheet.Cells[2, ColumnNumber + 2] = "Requested values";
                        }

                        if ((string)(xlWorkSheet.Cells[8, 1].Text.ToString()) == "DEGRADATION STATEs:")
                        {
                            List<string> AllDegradationASAP = new List<string>();
                            for (int a = 10; a <= iTotalRows_TDB; a++)
                            {
                                string DegState = (string)(xlWorkSheet.Cells[a, 7].Text.ToString());
                                string Temp = (string)(xlWorkSheet.Cells[a, 1].Text.ToString());
                                if (Temp == "FAIL RAM Information:")
                                {
                                    temp = a;
                                    j = a;
                                    break;
                                }
                                AllDegradationASAP.Add(DegState);
                            }
                            RemainingControlFun = ControlFunc.Except(AllDegradationASAP).ToArray();
                        }

                        xlWorkSheet.Cells[i, 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Yellow);
                        xlWorkSheet.Cells[i, 1] = "DEGRADATION STATEs:";
                        i++; j++;
                        foreach (string controlfun in RemainingControlFun)
                        {
                            progressBar2.Value = count++;
                            string value = controlfun;
                            Excel.Range line = (Excel.Range)xlWorkSheet.Rows[++i];
                            line.Insert();
                            xlWorkSheet.Cells[i, 1] = "{{MEAS_" + value.ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE}}";
                            xlWorkSheet.Cells[i, 2] = "DEGRADATION INFO";
                            xlWorkSheet.Cells[i, 3] = "ASAP";
                            xlWorkSheet.Cells[i, 7] = controlfun;
                            xlWorkSheet.Cells[i, ColumnNumber] = controlfun;
                            ++j;
                            if (Stop_clicked)
                            {
                                break;
                            }
                        }

                        Dictionary<string, string> AllControlFunction = new Dictionary<string, string>();
                        if (check != 10)
                        {
                            int Raw_Value = 0;
                            for (int a = 10; a <= iTotalRows_TDB; a++)
                            {
                                string standard = (string)(xlWorkSheet.Cells[a, 7].Text.ToString());
                                if (string.IsNullOrEmpty(standard))
                                {
                                    continue;
                                }
                                else
                                AllControlFunction.Add(standard, a.ToString());
                            }

                            foreach (string file in ControlFunc)
                            {
                                foreach (var key in AllControlFunction.Keys)
                                {
                                    if (AllControlFunction.ContainsKey(file))
                                    {
                                        Raw_Value = Convert.ToInt32(AllControlFunction[file]);
                                        break;
                                    }
                                }

                                if (Raw_Value != 0)
                                {
                                    xlWorkSheet.Cells[Raw_Value, ColumnNumber] = file;
                                }
                                Raw_Value = 0;

                                if (Stop_clicked)
                                {
                                    break;
                                }
                            }
                        }

                        Dictionary<string, string> AllFailRam = new Dictionary<string, string>();
                        List<string> AllFailRamASAP = new List<string>();
                        for (int k = j + 1; k <= iTotalRows_TDB; k++)
                        {
                            string Fail_Ram = (string)(xlWorkSheet.Cells[k, 7].Text.ToString());
                            AllFailRamASAP.Add(Fail_Ram);
                            if (string.IsNullOrEmpty(Fail_Ram))
                            {
                                continue;
                            }
                            else
                            AllFailRam.Add(Fail_Ram , k.ToString());
                        }

                        if (temp == 10)
                        {
                            i = j + 1;
                        }
                        else
                        {
                            i = temp;
                        }

                        xlWorkSheet.Cells[i, 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Yellow);
                        xlWorkSheet.Cells[i, 1] = "FAIL RAM Information:";
                        i++;
                        foreach (string sample in datalist.Select(x => x.Failram).Distinct())
                        {
                            progressBar2.Value = count++;

                            if (!(AllFailRamASAP.Contains(sample)))
                            {
                                Excel.Range line = (Excel.Range)xlWorkSheet.Rows[++i];
                                line.Insert();
                                xlWorkSheet.Cells[i, 1] = "{{Meas_" + sample.ToUpper() + "}}";
                                xlWorkSheet.Cells[i, 2] = "FAILURE BITS";
                                xlWorkSheet.Cells[i, 3] = "ASAP";
                                xlWorkSheet.Cells[i, 7] = sample;
                                xlWorkSheet.Cells[i, ColumnNumber] = sample;

                                if (!sample.Contains("Fbd_cur_"))
                                {
                                    line = (Excel.Range)xlWorkSheet.Rows[++i];
                                    line.Insert();
                                    xlWorkSheet.Cells[i, 1] = "{{Meas_" + sample.ToUpper() + "_final}}";
                                    xlWorkSheet.Cells[i, 2] = "FAILURE BITS";
                                    xlWorkSheet.Cells[i, 3] = "ASAP";
                                    xlWorkSheet.Cells[i, 7] = sample + "_final";
                                    xlWorkSheet.Cells[i, ColumnNumber] = sample + "_final";
                                }
                            }

                            if (check != 10)
                            {
                                int Raw_Value = 0;
                                foreach (var key in AllFailRam.Keys)
                                {
                                    if (AllFailRam.ContainsKey(sample))
                                    {
                                        Raw_Value = Convert.ToInt32(AllFailRam[sample]);
                                        break;
                                    }
                                }

                                if (Raw_Value != 0)
                                {
                                    xlWorkSheet.Cells[Raw_Value, ColumnNumber] = sample;
                                    if (!sample.Contains("Fbd_cur_"))
                                    {
                                        xlWorkSheet.Cells[Raw_Value + 1, ColumnNumber] = sample + "_final";
                                    }
                                }
                                Raw_Value = 0;
                            }
                            if (Stop_clicked)
                            {
                                break;
                            }
                        }

                        foreach (string sample in datalist2.Select(x => x.Failram).Distinct())
                        {
                            progressBar2.Value = count++;

                            if (!(AllFailRamASAP.Contains(sample)))
                            {
                                Excel.Range line = (Excel.Range)xlWorkSheet.Rows[++i];
                                line.Insert();
                                xlWorkSheet.Cells[i, 1] = "{{Meas_" + sample.ToUpper() + "}}";
                                xlWorkSheet.Cells[i, 2] = "FAILURE BITS";
                                xlWorkSheet.Cells[i, 3] = "ASAP";
                                xlWorkSheet.Cells[i, 7] = sample;
                                xlWorkSheet.Cells[i, ColumnNumber] = sample;
                            }

                            if (check != 10)
                            {
                                int Raw_Value = 0;
                                foreach (var key in AllFailRam.Keys)
                                {
                                    if (AllFailRam.ContainsKey(sample))
                                    {
                                        Raw_Value = Convert.ToInt32(AllFailRam[sample]);
                                        break;
                                    }
                                }

                                if (Raw_Value != 0)
                                {
                                    xlWorkSheet.Cells[Raw_Value, ColumnNumber] = sample;
                                }
                                Raw_Value = 0;
                            }

                            if (Stop_clicked)
                            {
                                break;
                            }
                        }

                        foreach (string sample in datalist1.Select(x => x.Failram).Distinct())
                        {
                            progressBar2.Value = count++;
                            if (!(AllFailRamASAP.Contains(sample)))
                            {
                                Excel.Range line = (Excel.Range)xlWorkSheet.Rows[++i];
                                line.Insert();
                                xlWorkSheet.Cells[i, 1] = "{{Meas_" + sample.ToUpper() + "}}";
                                xlWorkSheet.Cells[i, 2] = "FAILURE BITS";
                                xlWorkSheet.Cells[i, 3] = "ASAP";
                                xlWorkSheet.Cells[i, 7] = sample;
                                xlWorkSheet.Cells[i, ColumnNumber] = sample;

                                line = (Excel.Range)xlWorkSheet.Rows[++i];
                                line.Insert();
                                xlWorkSheet.Cells[i, 1] = "{{Meas_" + sample.ToUpper() + "_final}}";
                                xlWorkSheet.Cells[i, 2] = "FAILURE BITS";
                                xlWorkSheet.Cells[i, 3] = "ASAP";
                                xlWorkSheet.Cells[i, 7] = sample + "_final";
                                xlWorkSheet.Cells[i, ColumnNumber] = sample + "_final";
                            }

                            if (check != 10)
                            {
                                int Raw_Value = 0;
                                foreach (var key in AllFailRam.Keys)
                                {
                                    if (AllFailRam.ContainsKey(sample))
                                    {
                                        Raw_Value = Convert.ToInt32(AllFailRam[sample]);
                                        break;
                                    }
                                }

                                if (Raw_Value != 0)
                                {
                                    xlWorkSheet.Cells[Raw_Value, ColumnNumber] = sample;
                                    if (!sample.Contains("Fbd_cur_"))
                                    {
                                        xlWorkSheet.Cells[Raw_Value + 1, ColumnNumber] = sample + "_final";
                                    }
                                }
                                Raw_Value = 0;
                            }

                            if (Stop_clicked)
                            {
                                break;
                            }
                        }

                        foreach (string sample in datalist.Select(x => x.Failram_Mem).Distinct())
                        {
                            progressBar2.Value = count++;

                            if (!(AllFailRamASAP.Contains(sample)))
                            {
                                Excel.Range line = (Excel.Range)xlWorkSheet.Rows[++i];
                                line.Insert();
                                xlWorkSheet.Cells[i, 1] = "{{Meas_" + sample.ToUpper() + "}}";
                                xlWorkSheet.Cells[i, 2] = "FAILURE BITS";
                                xlWorkSheet.Cells[i, 3] = "ASAP";
                                xlWorkSheet.Cells[i, 7] = sample;
                                xlWorkSheet.Cells[i, ColumnNumber] = sample; 
                            }

                            if (check != 10)
                            {
                                int Raw_Value = 0;
                                foreach (var key in AllFailRam.Keys)
                                {
                                    if (AllFailRam.ContainsKey(sample))
                                    {
                                        Raw_Value = Convert.ToInt32(AllFailRam[sample]);
                                        break;
                                    }
                                }

                                if (Raw_Value != 0)
                                {
                                    xlWorkSheet.Cells[Raw_Value, ColumnNumber] = sample;
                                }
                                Raw_Value = 0;
                            }

                            if (Stop_clicked)
                            {
                                break;
                            }
                        }

                        foreach (string sample in datalist1.Select(x => x.Failram_Mem).Distinct())
                        {
                            progressBar2.Value = count++;

                            if (!(AllFailRamASAP.Contains(sample)))
                            {
                                Excel.Range line = (Excel.Range)xlWorkSheet.Rows[++i];
                                line.Insert();
                                xlWorkSheet.Cells[i, 1] = "{{Meas_" + sample.ToUpper() + "}}";
                                xlWorkSheet.Cells[i, 2] = "FAILURE BITS";
                                xlWorkSheet.Cells[i, 3] = "ASAP";
                                xlWorkSheet.Cells[i, 7] = sample;
                                xlWorkSheet.Cells[i, ColumnNumber] = sample;
                            }

                            if (check != 10)
                            {
                                int Raw_Value = 0;
                                foreach (var key in AllFailRam.Keys)
                                {
                                    if (AllFailRam.ContainsKey(sample))
                                    {
                                        Raw_Value = Convert.ToInt32(AllFailRam[sample]);
                                        break;
                                    }
                                }

                                if (Raw_Value != 0)
                                {
                                    xlWorkSheet.Cells[Raw_Value, ColumnNumber] = sample;
                                }
                                Raw_Value = 0;
                            }
                            if (Stop_clicked)
                            {
                                break;
                            }
                        }

                    }
                }

                /////////////////////////////////////////////////////////TestCases/////////////////////////////////////////////

                if (checkBox4.Checked)
                {
                    progressBar2.Value = 0;
                    progressBar2.Maximum = (30 * AllTestRun.Count());
                    progressBar2.Visible = true;

                    xlWorkSheet = xlWorkBook.Worksheets["03-TestCases"];
                    int iTotalRows_TDB = xlWorkSheet.UsedRange.Rows.Count;
                    int itotalcols_TDB = xlWorkSheet.UsedRange.Columns.Count;
                    int i = iTotalRows_TDB + 1; int j = iTotalRows_TDB - 2;

                    if (string.IsNullOrEmpty(textBox1.Text))
                    {
                        Dictionary<string, string> AllTestID = new Dictionary<string, string>();
                        for (int a = 4; a <= iTotalRows_TDB; a++)
                        {
                            string LinkID = (string)(xlWorkSheet.Cells[a, 7].Text.ToString());
                            string Version = (string)(xlWorkSheet.Cells[a, 6].Text.ToString());
                            AllTestID.Add(LinkID, Version);
                        }

                        List<string> Read_File = new List<string>();
                        foreach (string file in files)
                        {
                            progressBar2.Value = count++;
                            string name = file.Substring(file.LastIndexOf("\\") + 1);

                            if ((name.ToUpper()).Contains("_MEM") || (name.ToUpper()).Contains("_REC"))
                            {
                                Read_File.Add(name);
                            }
                            else
                            {
                                if (checkBox5.Checked)
                                {
                                    int Raw_Value = 0;
                                    foreach (var key in AllTestID.Keys)
                                    {
                                        if (AllTestID.ContainsKey("SW_REC_TestCase_" + name))
                                        {
                                            Raw_Value = Convert.ToInt32(AllTestID["SW_REC_TestCase_" + name]);
                                            break;
                                        }
                                    }

                                    if (Raw_Value != 0)
                                    {
                                        xlWorkSheet.Cells[Raw_Value, 49] = "yes";
                                    }
                                    else
                                    {
                                        xlWorkSheet.Cells[i, 2] = "SW";
                                        xlWorkSheet.Cells[i, 3] = "REC";
                                        xlWorkSheet.Cells[i, 4] = "TestCase";
                                        xlWorkSheet.Cells[i, 5] = j++;
                                        xlWorkSheet.Cells[i, 6] = i;
                                        xlWorkSheet.Cells[i, 7] = "SW_REC_TestCase_" + name;
                                        xlWorkSheet.Cells[i, 13] = "REC check";
                                        xlWorkSheet.Cells[i, 14] = "Check Component States and WL information after failure recover";
                                        xlWorkSheet.Cells[i, 19] = "Degradation States are reset to correct value";
                                        {
                                            xlWorkSheet.Cells[i, 21] = name + "_Rec";
                                            xlWorkSheet.Cells[i, 24] = "SIL";
                                            xlWorkSheet.Cells[i, 36] = name + "_Rec";
                                        }
                                        xlWorkSheet.Cells[i, 49] = "yes";
                                        i++;
                                    }
                                }
                                if (checkBox6.Checked)
                                {
                                    int Raw_Value = 0;
                                    foreach (var key in AllTestID.Keys)
                                    {
                                        if (AllTestID.ContainsKey("SW_MEM_TestCase_" + name))
                                        {
                                            Raw_Value = Convert.ToInt32(AllTestID["SW_MEM_TestCase_" + name]);
                                            break;
                                        }
                                    }

                                    if (Raw_Value != 0)
                                    {
                                        xlWorkSheet.Cells[Raw_Value, 49] = "yes";
                                    }
                                    else
                                    {
                                        xlWorkSheet.Cells[i, 2] = "SW";
                                        xlWorkSheet.Cells[i, 3] = "MEM";
                                        xlWorkSheet.Cells[i, 4] = "TestCase";
                                        xlWorkSheet.Cells[i, 5] = j++;
                                        xlWorkSheet.Cells[i, 6] = i;
                                        xlWorkSheet.Cells[i, 7] = "SW_MEM_TestCase_" + name;
                                        xlWorkSheet.Cells[i, 13] = "MEM check";
                                        xlWorkSheet.Cells[i, 14] = "Check Component States and WL information in second IGN cycle";
                                        xlWorkSheet.Cells[i, 18] = "Corresponding FAIL_RAM and MEM_RAM should reset";
                                        xlWorkSheet.Cells[i, 19] = "Degradation States are reset to correct value";
                                        {
                                            xlWorkSheet.Cells[i, 21] = name + "_Mem";
                                            xlWorkSheet.Cells[i, 24] = "SIL";
                                            xlWorkSheet.Cells[i, 36] = name + "_Mem";
                                        }
                                        xlWorkSheet.Cells[i, 49] = "yes";
                                        i++;
                                    }
                                }
                                if (checkBox2.Checked)
                                {
                                    int Raw_Value = 0;
                                    foreach (var key in AllTestID.Keys)
                                    {
                                        if (AllTestID.ContainsKey("SW_DTC_TestCase_" + name))
                                        {
                                            Raw_Value = Convert.ToInt32(AllTestID["SW_DTC_TestCase_" + name]);
                                            break;
                                        }
                                    }

                                    if (Raw_Value != 0)
                                    {
                                        xlWorkSheet.Cells[Raw_Value, 49] = "yes";
                                    }
                                    else
                                    {
                                        xlWorkSheet.Cells[i, 2] = "SW";
                                        xlWorkSheet.Cells[i, 3] = "DTC";
                                        xlWorkSheet.Cells[i, 4] = "TestCase";
                                        xlWorkSheet.Cells[i, 5] = j++;
                                        xlWorkSheet.Cells[i, 6] = i;
                                        xlWorkSheet.Cells[i, 7] = "SW_DTC_TestCase_" + name;
                                        xlWorkSheet.Cells[i, 13] = "DTC check";
                                        xlWorkSheet.Cells[i, 14] = "Check DTC and DTCStatus after Failure set";
                                        xlWorkSheet.Cells[i, 19] = "Corresponding DTC and DTCStatus are set";
                                        {
                                            xlWorkSheet.Cells[i, 21] = name;
                                            xlWorkSheet.Cells[i, 24] = "SIL";
                                            xlWorkSheet.Cells[i, 36] = name;
                                        }
                                        xlWorkSheet.Cells[i, 49] = "yes";
                                        i++;
                                    }
                                }
                                /////////////////////////////////////////////////////
                                if (checkBox1.Checked)
                                {
                                    int Raw_Value = 0;
                                    foreach (var key in AllTestID.Keys)
                                    {
                                        if (AllTestID.ContainsKey("SW_DEG_TestCase_" + name))
                                        {
                                            Raw_Value = Convert.ToInt32(AllTestID["SW_DEG_TestCase_" + name]);
                                            break;
                                        }
                                    }

                                    if (Raw_Value != 0)
                                    {
                                        xlWorkSheet.Cells[Raw_Value, 49] = "yes";
                                    }
                                    else
                                    {
                                        xlWorkSheet.Cells[i, 2] = "SW";
                                        xlWorkSheet.Cells[i, 3] = "DEG";
                                        xlWorkSheet.Cells[i, 4] = "TestCase";
                                        xlWorkSheet.Cells[i, 5] = j++;
                                        xlWorkSheet.Cells[i, 6] = i;
                                        xlWorkSheet.Cells[i, 7] = "SW_DEG_TestCase_" + name;
                                        xlWorkSheet.Cells[i, 13] = "DEG check";
                                        xlWorkSheet.Cells[i, 14] = "Check Degradation after Failure set";
                                        xlWorkSheet.Cells[i, 19] = "Degradation States are set to correct value";
                                        {
                                            xlWorkSheet.Cells[i, 21] = name;
                                            xlWorkSheet.Cells[i, 24] = "SIL";
                                            xlWorkSheet.Cells[i, 36] = name;
                                        }
                                        xlWorkSheet.Cells[i, 49] = "yes";
                                        i++;
                                    }
                                }
                                if (Stop_clicked)
                                {
                                    break;
                                }
                            }
                        }

                        Read_File.Add("--------------------");
                        Read_File.Add("Please add all these TestRun file name in Test Database manually and also to Bat file or Json file.");
                        if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\Debug\\"))
                            Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\Debug\\");
                        File.WriteAllLines(Directory.GetCurrentDirectory() + "\\Debug\\" + "File_contain_MEMorREC.txt", Read_File);
                    }
                    else
                    {

                        int ColumnNumber = 49; int check = 0;

                        string project = textBox1.Text;
                        for (int temp1 = 1; temp1 <= itotalcols_TDB; temp1++)
                        {
                            string Project1 = (string)(xlWorkSheet.Cells[3, temp1] as Excel.Range).Value2;

                            if (Project1 == project)
                            {
                                // Project name present 
                                ColumnNumber = temp1;
                                check = 49;
                                break;
                            }
                            else
                            {
                                // Project name not present
                                
                            }
                        }

                        if (check != 49)                // Adding new column for which preoject now availabe
                        {
                            Excel.Range line = (Excel.Range)xlWorkSheet.Columns[ColumnNumber];
                            line.Insert();
                            xlWorkSheet.Cells[2, ColumnNumber] = "Project";
                            xlWorkSheet.Cells[3, ColumnNumber] = textBox1.Text;
                        }

                        Dictionary<string, string> AllTestID = new Dictionary<string, string>();
                        for (int a = 4; a <= iTotalRows_TDB; a++)
                        {
                            string LinkID = (string)(xlWorkSheet.Cells[a, 7].Text.ToString());
                            string Version = (string)(xlWorkSheet.Cells[a, 6].Text.ToString());
                            AllTestID.Add(LinkID, Version);
                        }

                        List<string> Read_File = new List<string>();
                        foreach (string file in files)
                        {
                            progressBar2.Value = count++;
                            string name = file.Substring(file.LastIndexOf("\\") + 1);

                            if ((name.ToUpper()).Contains("_MEM") || (name.ToUpper()).Contains("_REC"))
                            {
                                Read_File.Add(name);
                            }
                            else
                            {
                                if (checkBox5.Checked)
                                {
                                    int Raw_Value = 0;
                                    foreach (var key in AllTestID.Keys)
                                    {
                                        if (AllTestID.ContainsKey("SW_REC_TestCase_" + name))
                                        {
                                            Raw_Value = Convert.ToInt32(AllTestID["SW_REC_TestCase_" + name]);
                                            break;
                                        }
                                    }

                                    if (Raw_Value != 0)
                                    {
                                        xlWorkSheet.Cells[Raw_Value, ColumnNumber] = "yes";
                                    }
                                    else
                                    {
                                        xlWorkSheet.Cells[i, 2] = "SW";
                                        xlWorkSheet.Cells[i, 3] = "REC";
                                        xlWorkSheet.Cells[i, 4] = "TestCase";
                                        xlWorkSheet.Cells[i, 5] = j++;
                                        xlWorkSheet.Cells[i, 6] = i;
                                        xlWorkSheet.Cells[i, 7] = "SW_REC_TestCase_" + name;
                                        xlWorkSheet.Cells[i, 13] = "REC check";
                                        xlWorkSheet.Cells[i, 14] = "Check Component States and WL information after failure recover";
                                        xlWorkSheet.Cells[i, 19] = "Degradation States are reset to correct value";
                                        {
                                            xlWorkSheet.Cells[i, 21] = name + "_Rec";
                                            xlWorkSheet.Cells[i, 24] = "SIL";
                                            xlWorkSheet.Cells[i, 36] = name + "_Rec";
                                        }
                                        xlWorkSheet.Cells[i, ColumnNumber] = "yes";
                                        i++;
                                    }
                                }
                                if (checkBox6.Checked)
                                {
                                    int Raw_Value = 0;
                                    foreach (var key in AllTestID.Keys)
                                    {
                                        if (AllTestID.ContainsKey("SW_MEM_TestCase_" + name))
                                        {
                                            Raw_Value = Convert.ToInt32(AllTestID["SW_MEM_TestCase_" + name]);
                                            break;
                                        }
                                    }

                                    if (Raw_Value != 0)
                                    {
                                        xlWorkSheet.Cells[Raw_Value, ColumnNumber] = "yes";
                                    }
                                    else
                                    {
                                        xlWorkSheet.Cells[i, 2] = "SW";
                                        xlWorkSheet.Cells[i, 3] = "MEM";
                                        xlWorkSheet.Cells[i, 4] = "TestCase";
                                        xlWorkSheet.Cells[i, 5] = j++;
                                        xlWorkSheet.Cells[i, 6] = i;
                                        xlWorkSheet.Cells[i, 7] = "SW_MEM_TestCase_" + name;
                                        xlWorkSheet.Cells[i, 13] = "MEM check";
                                        xlWorkSheet.Cells[i, 14] = "Check Component States and WL information in second IGN cycle";
                                        xlWorkSheet.Cells[i, 18] = "Corresponding FAIL_RAM and MEM_RAM should reset";
                                        xlWorkSheet.Cells[i, 19] = "Degradation States are reset to correct value";
                                        {
                                            xlWorkSheet.Cells[i, 21] = name + "_Mem";
                                            xlWorkSheet.Cells[i, 24] = "SIL";
                                            xlWorkSheet.Cells[i, 36] = name + "_Mem";
                                        }
                                        xlWorkSheet.Cells[i, ColumnNumber] = "yes";
                                        i++;
                                    }
                                }
                                if (checkBox2.Checked)
                                {
                                    int Raw_Value = 0;
                                    foreach (var key in AllTestID.Keys)
                                    {
                                        if (AllTestID.ContainsKey("SW_DTC_TestCase_" + name))
                                        {
                                            Raw_Value = Convert.ToInt32(AllTestID["SW_DTC_TestCase_" + name]);
                                            break;
                                        }
                                    }

                                    if (Raw_Value != 0)
                                    {
                                        xlWorkSheet.Cells[Raw_Value, ColumnNumber] = "yes";
                                    }
                                    else
                                    {
                                        xlWorkSheet.Cells[i, 2] = "SW";
                                        xlWorkSheet.Cells[i, 3] = "DTC";
                                        xlWorkSheet.Cells[i, 4] = "TestCase";
                                        xlWorkSheet.Cells[i, 5] = j++;
                                        xlWorkSheet.Cells[i, 6] = i;
                                        xlWorkSheet.Cells[i, 7] = "SW_DTC_TestCase_" + name;
                                        xlWorkSheet.Cells[i, 13] = "DTC check";
                                        xlWorkSheet.Cells[i, 14] = "Check DTC and DTCStatus after Failure set";
                                        xlWorkSheet.Cells[i, 19] = "Corresponding DTC and DTCStatus are set";
                                        {
                                            xlWorkSheet.Cells[i, 21] = name;
                                            xlWorkSheet.Cells[i, 24] = "SIL";
                                            xlWorkSheet.Cells[i, 36] = name;
                                        }
                                        xlWorkSheet.Cells[i, ColumnNumber] = "yes";
                                        i++;
                                    }
                                }
                                /////////////////////////////////////////////////////
                                if (checkBox1.Checked)
                                {
                                    int Raw_Value = 0;
                                    foreach (var key in AllTestID.Keys)
                                    {
                                        if (AllTestID.ContainsKey("SW_DEG_TestCase_" + name))
                                        {
                                            Raw_Value = Convert.ToInt32(AllTestID["SW_DEG_TestCase_" + name]);
                                            break;
                                        }
                                    }

                                    if (Raw_Value != 0)
                                    {
                                        xlWorkSheet.Cells[Raw_Value, ColumnNumber] = "yes";
                                    }
                                    else
                                    {
                                        xlWorkSheet.Cells[i, 2] = "SW";
                                        xlWorkSheet.Cells[i, 3] = "DEG";
                                        xlWorkSheet.Cells[i, 4] = "TestCase";
                                        xlWorkSheet.Cells[i, 5] = j++;
                                        xlWorkSheet.Cells[i, 6] = i;
                                        xlWorkSheet.Cells[i, 7] = "SW_DEG_TestCase_" + name;
                                        xlWorkSheet.Cells[i, 13] = "DEG check";
                                        xlWorkSheet.Cells[i, 14] = "Check Degradation after Failure set";
                                        xlWorkSheet.Cells[i, 19] = "Degradation States are set to correct value";
                                        {
                                            xlWorkSheet.Cells[i, 21] = name;
                                            xlWorkSheet.Cells[i, 24] = "SIL";
                                            xlWorkSheet.Cells[i, 36] = name;
                                        }
                                        xlWorkSheet.Cells[i, ColumnNumber] = "yes";
                                        i++;
                                    }
                                }
                                if (Stop_clicked)
                                {
                                    break;
                                }
                            }
                        }

                        Read_File.Add("--------------------");
                        Read_File.Add("Please add all these TestRun file name in Test Database manually and also to Bat file or Json file.");
                        if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\Debug\\"))
                            Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\Debug\\");
                        File.WriteAllLines(Directory.GetCurrentDirectory() + "\\Debug\\" + "File_contain_MEMorREC.txt", Read_File);
                    }
                }

                progressBar2.Visible = false;
                Stop_clicked = false;
                button8.Enabled = true;
                xlWorkBook.Save();
                xlWorkBook.Close();
                MessageBox.Show("DataBase updated");
                xlapp.Quit();
            }
            else { }
        }

        //button use for stop proccess
        private bool Stop_clicked = false;
        private void Stop_process_Click(object sender, EventArgs e)
        {
            Stop_clicked = true;
        }

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
        /// <summary>
        ///  Below part contain tool of Test Generator.
        /// </summary>

        struct Xml_Failure_details_1
        {
            public string Failure_Name;
            public string HEX_value;
            public string DEC_value;
            public string FailureBitGenericDataID;
        };

        //--------------------TestRun & .ts file & XML file create ------------
        // For Generate TestRun & .ts file & XML file
        private void Create_Click(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false;

            if ((checkBox10.Checked || checkBox9.Checked) && (!checkBox8.Checked))
            {
                thread1 = new Thread(() => FSF_TestRun(sender, e));
                thread1.Start();
            }
            if (checkBox8.Checked)
            {
                thread2 = new Thread(() => FSF_TestRun_Dyn(sender, e));
                thread2.Start();
            }
        }

        //--------------------Test Generate for Normal Project ------------
        private void FSF_TestRun(object sender, EventArgs e)
        {
            Excel.Application xlapp = new Excel.Application();
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;

            string[] FSF_Spec = null;
            string path = Directory.GetCurrentDirectory() + "\\FSF_Spec\\";
            try
            {
                FSF_Spec = Directory.GetFiles(path);
            }
            catch (DirectoryNotFoundException)
            {
                MessageBox.Show("FSF_Spec folder should present with proper FSF spec.");
                return;
            }

            try
            {
                if (FSF_Spec[0] == null)
                {
                }
            }
            catch (IndexOutOfRangeException)
            {
                MessageBox.Show("FSF spec. excel sheet doccument is not present");
                return;
            }

            string TestRunFolder = Directory.GetCurrentDirectory() + "\\TestRun_Templet\\";

            xlWorkBook = xlapp.Workbooks.Open(FSF_Spec[0]);
            xlWorkSheet = xlWorkBook.ActiveSheet;
            int iTotalRows = xlWorkSheet.UsedRange.Rows.Count;

            button2.Enabled = false;

            // Create failure list from excle sheet
            List<string> AllFailure = new List<string>();
            for (int s = 2; s <= iTotalRows; s++)
            {
                string failureName = (string)(xlWorkSheet.Cells[s, 1] as Excel.Range).Value2;
                AllFailure.Add(failureName);
            }

            if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\TestRun\\"))
                Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\TestRun\\");

            if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\XML_File\\"))
                Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\XML_File\\");

            string Failure_Ram = null;
            string Failure_Ram_Mem = null;
            string Hex_Num = null;

            XmlTextWriter writer = new XmlTextWriter(Directory.GetCurrentDirectory() + "\\XML_File\\" + "FSF_SW_FACTORY_TESTs.xml", System.Text.Encoding.UTF8);
            writer.WriteStartDocument(true);
            writer.Formatting = Formatting.Indented;
            writer.Indentation = 2;
            writer.WriteStartElement("root");

            for (int a = 2; a <= iTotalRows; a++)
            {
                string FailureName = (string)(xlWorkSheet.Cells[a, 1] as Excel.Range).Value2;
                string FailurePosition = (string)(xlWorkSheet.Cells[a, 2] as Excel.Range).Value2;
                string DTCValue = (string)(xlWorkSheet.Cells[a, 3].Text.ToString());
                List<string> TestRunFile = new List<string>();
                List<string> TestRun_Rec = new List<string>();
                List<string> TestRun_Mem = new List<string>();
                string DEC_value = null, FailureBit = null, FailureBit1 = null;
                int DEC_Value;
                var CheckArea = '0';

                if (string.IsNullOrEmpty(FailureName) || string.IsNullOrEmpty(FailurePosition))
                    continue;

                var chars = FailurePosition.ToCharArray();

                if (chars[5] == '0')
                    FailureBit = "0001";
                if (chars[5] == '1')
                    FailureBit = "0002";
                if (chars[5] == '2')
                    FailureBit = "0004";
                if (chars[5] == '3')
                    FailureBit = "0008";
                if (chars[5] == '4')
                    FailureBit = "0010";
                if (chars[5] == '5')
                    FailureBit = "0020";
                if (chars[5] == '6')
                    FailureBit = "0040";
                if (chars[5] == '7')
                    FailureBit = "0080";
                if (chars[5] == '8')
                    FailureBit = "0100";
                if (chars[5] == '9')
                    FailureBit = "0200";
                if (chars[5] == 'A' || chars[5] == 'a')
                    FailureBit = "0400";
                if (chars[5] == 'B' || chars[5] == 'b')
                    FailureBit = "0800";
                if (chars[5] == 'C' || chars[5] == 'c')
                    FailureBit = "1000";
                if (chars[5] == 'D' || chars[5] == 'd')
                    FailureBit = "2000";
                if (chars[5] == 'E' || chars[5] == 'e')
                    FailureBit = "4000";
                if (chars[5] == 'F' || chars[5] == 'f')
                    FailureBit = "8000";

                FailureBit1 = string.Concat("0x", FailureBit);
                var result = chars.Take(chars.Length - 1);
                string result1 = string.Join("", result);
                Hex_Num = string.Concat(result1, FailureBit);

                DEC_Value = Int32.Parse(Hex_Num.Replace("0x", "").Replace("0X", ""), System.Globalization.NumberStyles.HexNumber);
                DEC_value = Convert.ToString(DEC_Value);

                string substr = result1.Substring(result1.Length - 2);
                int failram_number = Int32.Parse(substr, System.Globalization.NumberStyles.HexNumber);

                if (chars[2] == '0')
                {
                    Failure_Ram = "FAIL_RAM" + failram_number.ToString("00");
                    Failure_Ram_Mem = "FAIL_RAM_MEM_" + failram_number.ToString("00");
                }
                else
                {
                    if (chars[2] == '1')
                    {
                        Failure_Ram = "FAIL_RAM_" + "1" + failram_number.ToString("00");
                        Failure_Ram_Mem = "FAIL_RAM_MEM_" + "1" + failram_number.ToString("00");
                    }
                    if (chars[2] == '2')
                    {
                        Failure_Ram = "BUSFAILRAM_" + failram_number.ToString("00");
                        Failure_Ram_Mem = "BUSFAILRAM_" + failram_number.ToString("00");
                    }
                    if (chars[2] == '8')
                    {
                        Failure_Ram = "FAIL_RAM_" + "8" + failram_number.ToString("00");
                        Failure_Ram_Mem = "IPB_FAIL_RAM_MEM" + failram_number.ToString("00");
                    }
                    if (chars[2] == '9')
                    {
                        Failure_Ram = "FAIL_RAM_" + "4" + failram_number.ToString("00");
                        Failure_Ram_Mem = "FAIL_RAM_MEM_" + "4" + failram_number.ToString("00");
                    }
                    if (chars[2] == 'C' || chars[2] == 'c')
                    {
                        Failure_Ram = "FAIL_RAM_" + "3" + failram_number.ToString("00");
                        Failure_Ram_Mem = "FAIL_RAM_MEM_" + "3" + failram_number.ToString("00");
                    }
                }
                CheckArea = chars[2];

                // To Generate XML file
                if (checkBox9.Checked)
                {
                    if (CheckArea == '2')
                    {
                        writer.WriteStartElement("BUS_Bit");
                    }
                    else if (CheckArea == '9')
                    {
                        writer.WriteStartElement("FSF4_Bit");
                    }
                    else
                        writer.WriteStartElement("Failure_Bit");

                    writer.WriteStartElement("Failure_name");
                    writer.WriteString(FailureName);
                    writer.WriteEndElement();

                    writer.WriteStartElement("DTC_value");
                    writer.WriteString(DTCValue);
                    writer.WriteEndElement();

                    writer.WriteStartElement("HEX_value");
                    writer.WriteString(Hex_Num);
                    writer.WriteEndElement();

                    writer.WriteStartElement("DEC_value");
                    writer.WriteString(DEC_value);
                    writer.WriteEndElement();

                    writer.WriteStartElement("Failram_value");
                    writer.WriteString(Failure_Ram);
                    writer.WriteEndElement();

                    writer.WriteStartElement("Failram_Mem_value");
                    writer.WriteString(Failure_Ram_Mem);
                    writer.WriteEndElement();

                    writer.WriteStartElement("Failure_Bit_value");
                    writer.WriteString(FailureBit1);
                    writer.WriteEndElement();

                    writer.WriteStartElement("Mem_Rec_Relevant_value");
                    writer.WriteString("1");
                    writer.WriteEndElement();

                    writer.WriteEndElement();
                }

                // To generate TestRun file.
                if (checkBox10.Checked)
                {
                    string[] files = null;
                    try
                    {
                        files = Directory.GetFiles(TestRunFolder);
                    }
                    catch (DirectoryNotFoundException)
                    {
                        MessageBox.Show("TestRun_Templet folder should present with TestRun template file");
                        return;
                    }

                    foreach (string file in files)
                    {
                        string name = file.Substring(file.LastIndexOf("\\") + 1);

                        if (name.ToUpper().Contains("_REC") || name.ToUpper().Contains("_MEM"))
                        {
                            if (name.ToUpper().Contains("_REC"))
                            {
                                string[] lines1 = System.IO.File.ReadAllLines((TestRunFolder + "\\" + name));
                                foreach (string line in lines1)
                                {
                                    if (line.Contains("DVAwr CCP.SetFailureData Abs -1 0"))
                                        TestRun_Rec.Add("        DVAwr CCP.SetFailureData Abs 50 " + DEC_value);
                                    else if (line.Contains("Failure_name"))
                                        TestRun_Rec.Add(line.Replace("Failure_name", FailureName));
                                    else
                                        TestRun_Rec.Add(line);
                                }

                                if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\TestRun\\"))
                                    Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\TestRun\\");
                                File.WriteAllLines(Directory.GetCurrentDirectory() + "\\TestRun\\" + "\\" + FailureName + "_REC", TestRun_Rec);
                            }
                            if (name.ToUpper().Contains("_MEM"))
                            {
                                string[] lines2 = System.IO.File.ReadAllLines((TestRunFolder + "\\" + name));
                                foreach (string line in lines2)
                                {
                                    TestRun_Mem.Add(line);
                                }

                                if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\TestRun\\"))
                                    Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\TestRun\\");
                                File.WriteAllLines(Directory.GetCurrentDirectory() + "\\TestRun\\" + "\\" + FailureName + "_MEM", TestRun_Mem);
                            }
                        }
                        else
                        {
                            if (name.EndsWith(".ts"))
                            {
                            }
                            else
                            {
                                string[] lines = System.IO.File.ReadAllLines((TestRunFolder + "\\" + name));
                                int temp1 = 0;

                                foreach (string line in lines)
                                {
                                    if (line.Contains("Datalyser.Cmd"))
                                        temp1++;
                                }

                                if (temp1 != 2)
                                {
                                    MessageBox.Show("TestRun Templet not contain proper Datalyser command for start and stop");
                                    temp1 = 0;
                                    return;
                                }

                                foreach (string line in lines)
                                {
                                    if (line.Contains("DVAwr CCP.SetFailureData Abs -1 0"))
                                        TestRunFile.Add("        DVAwr CCP.SetFailureData Abs -1 " + DEC_value);
                                    else if (line.Contains("Failure_name"))
                                        TestRunFile.Add(line.Replace("Failure_name", FailureName));
                                    else
                                        TestRunFile.Add(line);
                                }

                                if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\TestRun\\"))
                                    Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\TestRun\\");
                                File.WriteAllLines(Directory.GetCurrentDirectory() + "\\TestRun\\" + "\\" + FailureName, TestRunFile);
                            }
                        }
                    }
                }

            }

            // To generate Test Manager .ts file 
            List<string> TestManagerFile = new List<string>();
            List<string> TestManagerFile_REC = new List<string>();
            List<string> TestManagerFile_MEM = new List<string>();
            string[] AllTestRun = null;
            try
            {
                AllTestRun = Directory.GetFiles(Directory.GetCurrentDirectory() + "\\TestRun\\");
            }
            catch (DirectoryNotFoundException)
            {
                MessageBox.Show("Keep TestRun folder....");
                return;
            }

            string[] files1 = Directory.GetFiles(TestRunFolder);
            int i = 1;

            foreach (string file1 in files1)
            {
                string name1 = file1.Substring(file1.LastIndexOf("\\") + 1);
                if (name1.EndsWith(".ts"))
                {
                    if (i == 1)
                    {
                        string[] lines = System.IO.File.ReadAllLines((TestRunFolder + "\\" + name1));
                        foreach (string line in lines)
                        {
                            TestManagerFile.Add(line);
                            TestManagerFile_REC.Add(line);
                            TestManagerFile_MEM.Add(line);
                        }
                    }
                    foreach (string file in AllTestRun)
                    {
                        string name = file.Substring(file.LastIndexOf("\\") + 1);

                        TestManagerFile.Add("Step." + i + " = TestRun");
                        TestManagerFile.Add("Step." + i + ".Name = FSF_Testruns/STD/" + name);
                        TestManagerFile_REC.Add("Step." + i + " = TestRun");
                        TestManagerFile_REC.Add("Step." + i + ".Name = FSF_Testruns/REC/" + name + "_REC");
                        TestManagerFile_MEM.Add("Step." + i + " = TestRun");
                        TestManagerFile_MEM.Add("Step." + i + ".Name = FSF_Testruns/MEM/" + name + "_MEM");
                        i++;
                    }
                }
            }

            File.WriteAllLines(Directory.GetCurrentDirectory() + "\\FSF_TESTS_SW_FACTORY_STD.ts", TestManagerFile);
            File.WriteAllLines(Directory.GetCurrentDirectory() + "\\FSF_TESTS_SW_FACTORY_REC.ts", TestManagerFile_REC);
            File.WriteAllLines(Directory.GetCurrentDirectory() + "\\FSF_TESTS_SW_FACTORY_MEM.ts", TestManagerFile_MEM);

            writer.WriteEndElement();
            writer.WriteEndDocument();
            writer.Close();
            button2.Enabled = true;
            MessageBox.Show("XML File,TestRuns and .ts file are created ! ");
            //       Form1.ActiveForm.Close();
            xlapp.Quit();
        }

        //--------------------Test Generate for Dynamic Failure bitmap Project ------------
        private void FSF_TestRun_Dyn(object sender, EventArgs e)
        {
            Excel.Application xlapp = new Excel.Application();
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;

            // Read Fsf Spec
            string[] FSF_Spec = null;
            string path = Directory.GetCurrentDirectory() + "\\FSF_Spec\\";
            try
            {
                FSF_Spec = Directory.GetFiles(path);
            }
            catch (DirectoryNotFoundException)
            {
                MessageBox.Show("FSF_Spec folder should present with proper FSF spec.");
                return;
            }

            try
            {
                if (FSF_Spec[0] == null)
                {
                }
            }
            catch (IndexOutOfRangeException)
            {
                MessageBox.Show("FSF spec. excel sheet doccument is not present in FSF_Spec folder");
                return;
            }

            // Open XML file
            string[] Dyn_xml = null;
            string path1 = Directory.GetCurrentDirectory() + "\\Dyn_xml\\";
            try
            {
                Dyn_xml = Directory.GetFiles(path1);
            }
            catch (DirectoryNotFoundException)
            {
                MessageBox.Show("Dyn_xml folder should present with proper XML file for Dynamic failure bitmap project.");
                return;
            }

            try
            {
                if (Dyn_xml[0] == null)
                {
                }
            }
            catch (IndexOutOfRangeException)
            {
                MessageBox.Show("Dynamic failure bitmap XML file is not present in Dyn_xml folder");
                return;
            }

            string TestRunFolder = Directory.GetCurrentDirectory() + "\\TestRun_Templet\\";

            xlWorkBook = xlapp.Workbooks.Open(FSF_Spec[0]);
            xlWorkSheet = xlWorkBook.ActiveSheet;
            int iTotalRows = xlWorkSheet.UsedRange.Rows.Count;

            button2.Enabled = false;

            if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\TestRun\\"))
                Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\TestRun\\");

            if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\XML_File\\"))
                Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\XML_File\\");

            ////////////Generate XML file///////////////////////////////////////////////////
            XmlTextWriter writer = new XmlTextWriter(Directory.GetCurrentDirectory() + "\\XML_File\\" + "FSF_SW_FACTORY_TESTs.xml", System.Text.Encoding.UTF8);
            writer.WriteStartDocument(true);
            writer.Formatting = Formatting.Indented;
            writer.Indentation = 2;
            writer.WriteStartElement("root");

            ////////////////READ Dynamic XML file////////////////////////////////////////////////
            XmlDocument xmldoc = new XmlDocument();
            xmldoc.Load(Dyn_xml[0]);

            List<Xml_Failure_details_1> datalist = new List<Xml_Failure_details_1>();
            List<string> AllFSF_failure = new List<string>();
            XmlNodeList nodeList = xmldoc.DocumentElement.SelectNodes("/FailureBits/FailureBit");
            foreach (XmlNode nxmNode in nodeList)
            {
                Xml_Failure_details_1 sample = new Xml_Failure_details_1();
                XmlElement element = (XmlElement)nxmNode;
                string temp1, temp2, Hex_Num;
                string DEC_value = null;
                int DEC_Value;

                sample.Failure_Name = element.ChildNodes.Item(0).InnerText.Trim();

                temp1 = element.ChildNodes.Item(1).ChildNodes.Item(0).InnerText.Trim();
                string temp = Convert.ToString(int.Parse(temp1), 16);       // Convert Decimal to Hex decimal

                temp2 = element.ChildNodes.Item(1).ChildNodes.Item(1).InnerText.Trim();

                if (temp2 == "0")
                    temp2 = "0001";
                if (temp2 == "1")
                    temp2 = "0002";
                if (temp2 == "2")
                    temp2 = "0004";
                if (temp2 == "3")
                    temp2 = "0008";
                if (temp2 == "4")
                    temp2 = "0010";
                if (temp2 == "5")
                    temp2 = "0020";
                if (temp2 == "6")
                    temp2 = "0040";
                if (temp2 == "7")
                    temp2 = "0080";
                if (temp2 == "8")
                    temp2 = "0100";
                if (temp2 == "9")
                    temp2 = "0200";
                if (temp2 == "A" || temp2 == "a" || temp2 == "10")
                    temp2 = "0400";
                if (temp2 == "B" || temp2 == "b" || temp2 == "11")
                    temp2 = "0800";
                if (temp2 == "C" || temp2 == "c" || temp2 == "12")
                    temp2 = "1000";
                if (temp2 == "D" || temp2 == "d" || temp2 == "13")
                    temp2 = "2000";
                if (temp2 == "E" || temp2 == "e" || temp2 == "14")
                    temp2 = "4000";
                if (temp2 == "F" || temp2 == "f" || temp2 == "15")
                    temp2 = "8000";

                Hex_Num = string.Concat(temp.ToUpper(), temp2);

                DEC_Value = Int32.Parse(Hex_Num.Replace("0x", "").Replace("0X", ""), System.Globalization.NumberStyles.HexNumber); // Hexa decimal to decimal
                DEC_value = Convert.ToString(DEC_Value);

                sample.HEX_value = Hex_Num;
                sample.DEC_value = DEC_value;
                sample.FailureBitGenericDataID = element.ChildNodes.Item(4).ChildNodes.Item(0).InnerText.Trim();

                AllFSF_failure.Add(sample.Failure_Name);
                datalist.Add(sample);
            }

            /////////////////////////////
            List<string> Read_File = new List<string>();
            for (int a = 2; a <= iTotalRows; a++)
            {
                string FailureName = (string)(xlWorkSheet.Cells[a, 1] as Excel.Range).Value2;
                string DTCValue = (string)(xlWorkSheet.Cells[a, 3].Text.ToString());
                List<string> TestRunFile = new List<string>();
                List<string> TestRun_Rec = new List<string>();
                List<string> TestRun_Mem = new List<string>();

                if (string.IsNullOrEmpty(FailureName))
                    continue;

                Xml_Failure_details_1 currentlist = datalist.Find(x => x.Failure_Name.Contains(FailureName));

                if (string.IsNullOrEmpty(currentlist.DEC_value) || string.IsNullOrEmpty(currentlist.HEX_value))
                {
                    Read_File.Add(FailureName);
                    continue;
                }
                // To generate XML file.
                if (checkBox9.Checked)
                {
                    writer.WriteStartElement("Failure_Bit");

                    writer.WriteStartElement("Failure_name");
                    writer.WriteString(FailureName);
                    writer.WriteEndElement();

                    writer.WriteStartElement("DTC_value");
                    writer.WriteString(DTCValue);
                    writer.WriteEndElement();

                    writer.WriteStartElement("HEX_value");
                    writer.WriteString(currentlist.HEX_value);
                    writer.WriteEndElement();

                    writer.WriteStartElement("DEC_value");
                    writer.WriteString(currentlist.DEC_value);
                    writer.WriteEndElement();

                    writer.WriteStartElement("Failram_value");
                    writer.WriteString("Fbd_cur_" + FailureName);
                    writer.WriteEndElement();

                    writer.WriteStartElement("Failram_Mem_value");
                    writer.WriteString("Fbd_mem_" + FailureName);
                    writer.WriteEndElement();

                    writer.WriteStartElement("Failure_Bit_value");
                    writer.WriteString("1");
                    writer.WriteEndElement();

                    writer.WriteStartElement("Mem_Rec_Relevant_value");
                    writer.WriteString("1");
                    writer.WriteEndElement();

                    writer.WriteStartElement("GenFailBitID_value");
                    writer.WriteString(currentlist.FailureBitGenericDataID);
                    writer.WriteEndElement();

                    writer.WriteStartElement("Failram_Fin_value");
                    writer.WriteString("Fbd_Fin_" + FailureName);
                    writer.WriteEndElement();

                    writer.WriteEndElement();
                }

                // To generate TestRun file.
                if (checkBox10.Checked)
                {
                    string[] files = null;
                    try
                    {
                        files = Directory.GetFiles(TestRunFolder);
                    }
                    catch (DirectoryNotFoundException)
                    {
                        MessageBox.Show("TestRun_Templet folder should present with TestRun template file");
                        return;
                    }

                    foreach (string file in files)
                    {
                        string name = file.Substring(file.LastIndexOf("\\") + 1);

                        if (name.ToUpper().Contains("_REC") || name.ToUpper().Contains("_MEM"))
                        {
                            if (name.ToUpper().Contains("_REC"))
                            {
                                string[] lines1 = System.IO.File.ReadAllLines((TestRunFolder + "\\" + name));
                                foreach (string line in lines1)
                                {
                                    if (line.Contains("DVAwr CCP.SetFailureData Abs -1 0"))
                                        TestRun_Rec.Add("        DVAwr CCP.SetFailureData Abs 50 " + currentlist.DEC_value);
                                    else if (line.Contains("Failure_name"))
                                        TestRun_Rec.Add(line.Replace("Failure_name", FailureName));
                                    else
                                        TestRun_Rec.Add(line);
                                }

                                if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\TestRun\\"))
                                    Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\TestRun\\");
                                File.WriteAllLines(Directory.GetCurrentDirectory() + "\\TestRun\\" + "\\" + FailureName + "_Rec", TestRun_Rec);
                            }
                            if (name.ToUpper().Contains("_MEM"))
                            {
                                string[] lines2 = System.IO.File.ReadAllLines((TestRunFolder + "\\" + name));
                                foreach (string line in lines2)
                                {
                                    TestRun_Mem.Add(line);
                                }

                                if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\TestRun\\"))
                                    Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\TestRun\\");
                                File.WriteAllLines(Directory.GetCurrentDirectory() + "\\TestRun\\" + "\\" + FailureName + "_Mem", TestRun_Mem);
                            }
                        }
                        else
                        {
                            if (name.EndsWith(".ts"))
                            {
                            }
                            else
                            {
                                string[] lines = System.IO.File.ReadAllLines((TestRunFolder + "\\" + name));
                                int temp1 = 0;

                                foreach (string line in lines)
                                {
                                    if (line.Contains("Datalyser.Cmd"))
                                        temp1++;
                                }

                                if (temp1 != 2)
                                {
                                    MessageBox.Show("TestRun Templet not contain proper Datalyser command for start and stop");
                                    temp1 = 0;
                                    return;
                                }

                                foreach (string line in lines)
                                {
                                    if (line.Contains("DVAwr CCP.SetFailureData Abs -1 0"))
                                        TestRunFile.Add("        DVAwr CCP.SetFailureData Abs -1 " + currentlist.DEC_value);
                                    else if (line.Contains("Failure_name"))
                                        TestRunFile.Add(line.Replace("Failure_name", FailureName));
                                    else
                                        TestRunFile.Add(line);
                                }

                                if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\TestRun\\"))
                                    Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\TestRun\\");
                                File.WriteAllLines(Directory.GetCurrentDirectory() + "\\TestRun\\" + "\\" + FailureName, TestRunFile);
                            }
                        }
                    }
                }
            }

            Read_File.Add("--------------------");
            Read_File.Add("Not able to genearte TestRun file as failure doesn't have FailureBitDynAddressBit value in XML file .");
            if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\Debug\\"))
                Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\Debug\\");
            File.WriteAllLines(Directory.GetCurrentDirectory() + "\\Debug\\" + "TestRun_NotGenerated.txt", Read_File);


            // To generate Test Manager .ts file 
            List<string> TestManagerFile = new List<string>();
            List<string> TestManagerFile_REC = new List<string>();
            List<string> TestManagerFile_MEM = new List<string>();
            string[] AllTestRun = null;
            try
            {
                AllTestRun = Directory.GetFiles(Directory.GetCurrentDirectory() + "\\TestRun\\");
            }
            catch (DirectoryNotFoundException)
            {
                MessageBox.Show("Keep TestRun folder....");
                return;
            }

            string[] files1 = Directory.GetFiles(TestRunFolder);
            int i = 1;

            foreach (string file1 in files1)
            {
                string name1 = file1.Substring(file1.LastIndexOf("\\") + 1);
                if (name1.EndsWith(".ts"))
                {
                    if (i == 1)
                    {
                        string[] lines = System.IO.File.ReadAllLines((TestRunFolder + "\\" + name1));
                        foreach (string line in lines)
                        {
                            TestManagerFile.Add(line);
                            TestManagerFile_REC.Add(line);
                            TestManagerFile_MEM.Add(line);
                        }
                    }
                    foreach (string file in AllTestRun)
                    {
                        string name = file.Substring(file.LastIndexOf("\\") + 1);

                        TestManagerFile.Add("Step." + i + " = TestRun");
                        TestManagerFile.Add("Step." + i + ".Name = FSF_Testruns/STD/" + name);
                        TestManagerFile_REC.Add("Step." + i + " = TestRun");
                        TestManagerFile_REC.Add("Step." + i + ".Name = FSF_Testruns/REC/" + name + "_REC");
                        TestManagerFile_MEM.Add("Step." + i + " = TestRun");
                        TestManagerFile_MEM.Add("Step." + i + ".Name = FSF_Testruns/MEM/" + name + "_MEM");
                        i++;
                    }
                }
            }

            File.WriteAllLines(Directory.GetCurrentDirectory() + "\\FSF_TESTS_SW_FACTORY_STD.ts", TestManagerFile);
            File.WriteAllLines(Directory.GetCurrentDirectory() + "\\FSF_TESTS_SW_FACTORY_REC.ts", TestManagerFile_REC);
            File.WriteAllLines(Directory.GetCurrentDirectory() + "\\FSF_TESTS_SW_FACTORY_MEM.ts", TestManagerFile_MEM);

            writer.WriteEndElement();
            writer.WriteEndDocument();
            writer.Close();
            button2.Enabled = true;
            MessageBox.Show("XML File,TestRuns and .ts file are created ! ");
            //       Form1.ActiveForm.Close();
            xlapp.Quit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        ////////////////////////// --> END <-- //////////////////////////////

    }
}
