﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Data;
using System.Linq;
using System.Threading;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Xml;
using Global.Functions;
using System.ComponentModel;
using System.Reflection;

namespace FSF_SIL_Test_Automation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        Thread thread1, thread2, thread3;

        // Create the ToolTip and associate with the Form container.
        ToolTip toolTip1 = new ToolTip();
   
        struct Xml_Failure_details
        {
            public string Failure_Name;
            public string DTC;
            public string Failram;
            public string Failram_Value;
            public string Failram_Mem;
        };

//////////////////////////// JSON Creation ///////////////////////////////////////////////
        //-------------------------JSON Creation -------------------------
        // For Generate JSON file
        private void Json_Creator(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false;

            thread2 = new Thread(() => JSON_Creation(sender, e));
            thread2.Start();
        }

        private void JSON_Creation(object sender, EventArgs e)
        {
            string[] check = new string[6];
            button9.Enabled = false;

            try
            {
                // Reading All TestRun files from TestRun folder
                if (global::FSF_SIL_Test_Automation.Properties.Settings.AllTestRun.Count == 0)
                    global::FSF_SIL_Test_Automation.Properties.Settings.AllTestRun = PYCreation.TestRunFolder();
                if (global::FSF_SIL_Test_Automation.Properties.Settings.AllTestRun.Count == 0)
                {
                    button9.Enabled = true;
                    return;
                }

                // Reading function degrdation database from excelsheet
                if (global::FSF_SIL_Test_Automation.Properties.Settings.AlldatabaseValue.Count == 0)
                    global::FSF_SIL_Test_Automation.Properties.Settings.AlldatabaseValue = PYCreation.DataBaseValue();
                if (global::FSF_SIL_Test_Automation.Properties.Settings.AlldatabaseValue.Count == 0)
                {
                    button9.Enabled = true;
                    return;
                }

                check[0] = checkBox1.Checked.ToString();  // DEG
                check[1] = checkBox2.Checked.ToString();  // DTC
                check[2] = checkBox5.Checked.ToString();  // REC
                check[3] = checkBox6.Checked.ToString();  // MEM
                check[4] = checkBox7.Checked.ToString();  // BAT File
                check[5] = textBox1.Text;                 // Project Name

                JSONCreation.JSON_Generation(check);
            }
            finally
            {
                button9.Enabled = true;
            }
            MessageBox.Show(" Json or Bat file Generated");
        }

//////////////////////////// PY FILE Creation /////////////////////////////////////////////
        //-------------------------PY FILE Creation ----------------------
        // STANDARD___PY file generation button
        private void Generate_PY_Click(object sender, EventArgs e)
        {
            progressBar1.Visible = true;
            CheckForIllegalCrossThreadCalls = false;
            string Assign_user = null;
            string Project = null;
            string ATO_TASK = null;
            string Summary = null;
            string TestCase_ID = null;

            if (!string.IsNullOrEmpty(textBox1.Text))
            {               
                string[] temp1 = textBox1.Text.Split(',');
                ATO_TASK = temp1[0];
                try
                {
                    TestCase_ID = temp1[1];
                }
                catch (IndexOutOfRangeException) {  }
                System.Diagnostics.Process process = new System.Diagnostics.Process();
                process.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
                process.StartInfo.FileName = @"C:\Windows\System32\cmd.exe";
                process.StartInfo.UseShellExecute = false;
                process.StartInfo.CreateNoWindow = true;
                process.StartInfo.RedirectStandardOutput = true;
                process.StartInfo.RedirectStandardInput = true;
                process.StartInfo.Arguments = "/c im issues --hostname=ffm-mks1 --port=7002 --fields=\"Assigned User\",\"Project\",\"Summary\" --fieldsDelim=* " + ATO_TASK;
                process.Start();

                string command = process.StandardOutput.ReadToEnd();
                process.WaitForExit();
                string[] temp = command.Split('*');

                try
                {
                    Assign_user = temp[0];
                    Summary = temp[2].Replace("\n", "");
                    Project = temp[1];
                }
                catch (IndexOutOfRangeException) { ATO_TASK = null; }
 
                textBox1.Clear();
            }
        
            global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific.Add(Assign_user);  // 0
            global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific.Add(Project);      // 1
            global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific.Add(ATO_TASK);     // 2
            global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific.Add(Summary);      // 3
            global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific.Add(TestCase_ID);  // 4

            string newfolder = DateTime.Now.ToString();
            newfolder = newfolder.Replace("/", "-").Replace(":", "-");
            global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific.Add(newfolder);    // 5

            string userName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
            userName = userName.Substring(userName.LastIndexOf("\\") + 1);
            global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific.Add(userName);     // 6

            thread1 = new Thread(() => PY_Thread1_Click(sender, e));
            thread1.Start();
        }

        /// <summary>
        /// Function use to create DEG, DTC, REC and MEM evalution files
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PY_Thread1_Click(object sender, EventArgs e)
        {
            button3.Enabled = false;

            try
            {
                // Reading All TestRun files from TestRun folder
                if (global::FSF_SIL_Test_Automation.Properties.Settings.AllTestRun.Count == 0)
                    global::FSF_SIL_Test_Automation.Properties.Settings.AllTestRun = PYCreation.TestRunFolder();
                if (global::FSF_SIL_Test_Automation.Properties.Settings.AllTestRun.Count == 0)
                {
                    button3.Enabled = true;
                    return;
                }

                // Reading function degrdation database from excelsheet
                if (global::FSF_SIL_Test_Automation.Properties.Settings.AlldatabaseValue.Count == 0)
                    global::FSF_SIL_Test_Automation.Properties.Settings.AlldatabaseValue = PYCreation.DataBaseValue();
                if (global::FSF_SIL_Test_Automation.Properties.Settings.AlldatabaseValue.Count == 0)
                {
                    button3.Enabled = true;
                    return;
                }

                // Reading information related to each failure from XML file  
                if (global::FSF_SIL_Test_Automation.Properties.Settings.Xml_List.Count == 0)
                    global::FSF_SIL_Test_Automation.Properties.Settings.Xml_List = PYCreation.ReadXmlFile();
                if (global::FSF_SIL_Test_Automation.Properties.Settings.Xml_List.Count == 0)
                {
                    button3.Enabled = true;
                    return;
                }

                textBox5.ReadOnly = textBox6.ReadOnly = true;
                // Reading componenet present in Textbox
                Dictionary<string, int> components = new Dictionary<string, int>();
                foreach (string currentname in textBox5.Lines)
                {
                    components.Add(currentname, 4);
                }
                foreach (string currentname in textBox6.Lines)
                {
                    components.Add(currentname, 7);
                }

                // Create DEG, DTC, REC and MEM files
                if (checkBox1.Checked)
                {
                    DEG.DEG_Generation(components);
                }
                if (checkBox2.Checked)
                {
                    if (checkBox11.Checked)
                    {
                        DTC.DTC_Generation(1, textBox2.Text);
                    }
                    else
                    {
                        DTC.DTC_Generation(0 , null);
                    }
                }

                if (checkBox5.Checked && checkBox6.Checked)
                {
                    REC_MEM.REC_MEM_Generation(2, components);
                }
                else if (checkBox5.Checked)
                {
                    REC_MEM.REC_MEM_Generation(1, components);
                }
                else if (checkBox6.Checked)
                {
                    REC_MEM.REC_MEM_Generation(0, components);
                }
            }
            finally
            {
                textBox5.ReadOnly = textBox6.ReadOnly = false;            
                button3.Enabled = true;
                progressBar1.Visible = false;
            }
            MessageBox.Show("Test evaluation files are created");
        }

//////////////////////////// DATABASE Upadte /////////////////////////////////////////////
        //--------------------------DATABASE Upadte ----------------------
        // DATABASE update button
        private void Update_Database_Click(object sender, EventArgs e)
        {
            progressBar2.Visible = true;
            CheckForIllegalCrossThreadCalls = false;

            thread3 = new Thread(() => Database_Thread_Click(sender, e));
            thread3.Start();           
        }

        //--------------------------DATABASE Upadte Thread ---------------
        // Thread create for DATABASE update
        private void Database_Thread_Click(object sender, EventArgs e)
        {
            button8.Enabled = false;
            
            string[] DataBase = null;
            string path3 = Directory.GetCurrentDirectory() + "\\DataBase\\";  // 2                      
            try
            {
                DataBase = Directory.GetFiles(path3);
            }
            catch (DirectoryNotFoundException)
            {
                MessageBox.Show("Please keep DataBase folder with Templet database file..!!!!");
                return;
            }

            try
            {
                if (DataBase[0] != string.Empty) { }
            }
            catch (IndexOutOfRangeException)
            {
                MessageBox.Show("Please keep DataBase folder with Templet database file..!!!!");
                return;
            }

            Excel.Application xlapp = new Excel.Application();
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            xlWorkBook = xlapp.Workbooks.Open(DataBase[0]);

            try
            {
                List<string> Xcomponents = new List<string>();
                List<string> Ycomponents = new List<string>();

                // Reading All TestRun files from TestRun folder
                if (global::FSF_SIL_Test_Automation.Properties.Settings.AllTestRun.Count == 0)
                    global::FSF_SIL_Test_Automation.Properties.Settings.AllTestRun = PYCreation.TestRunFolder();
                if (global::FSF_SIL_Test_Automation.Properties.Settings.AllTestRun.Count == 0)
                {
                    button8.Enabled = true;
                    return;
                }

                // Reading function degrdation database from excelsheet
                if (global::FSF_SIL_Test_Automation.Properties.Settings.AlldatabaseValue.Count == 0)
                    global::FSF_SIL_Test_Automation.Properties.Settings.AlldatabaseValue = PYCreation.DataBaseValue();
                if (global::FSF_SIL_Test_Automation.Properties.Settings.AlldatabaseValue.Count == 0)
                {
                    button8.Enabled = true;
                    return;
                }

                // Reading information related to each failure from XML file  
                if (global::FSF_SIL_Test_Automation.Properties.Settings.Xml_List.Count == 0)
                    global::FSF_SIL_Test_Automation.Properties.Settings.Xml_List = PYCreation.ReadXmlFile();
                if (global::FSF_SIL_Test_Automation.Properties.Settings.Xml_List.Count == 0)
                {
                    button8.Enabled = true;
                    return;
                }

                string Function = global::FSF_SIL_Test_Automation.Properties.Settings.AlldatabaseValue.First().Value;
                string[] ControlFunc = Function.Split('\\');                            // Split control function in each array element
                ControlFunc = ControlFunc.Take(ControlFunc.Count() - 1).ToArray();     // Remove last element from array
                //////////////////////////////////////////////////////MappingList///////////////////////////////
                if (checkBox3.Checked)
                {
                    xlWorkSheet = xlWorkBook.Worksheets["04-MappingList"];

                    int iTotalRows_TDB = xlWorkSheet.UsedRange.Rows.Count;
                    int itotalcols_TDB = xlWorkSheet.UsedRange.Columns.Count;

                    List<string> ControlFunc_RemoveHBE = new List<string>();
                    foreach (string temp in ControlFunc)
                    {
                        ControlFunc_RemoveHBE.Add(temp.Replace("HBE.", ""));
                    }

                    if (string.IsNullOrEmpty(textBox1.Text))
                    {
                        int i = 8; int j = 8; int temp = 10; int remain = 0;
                        string[] RemainingControlFun = null;
                        RemainingControlFun = ControlFunc_RemoveHBE.ToArray();

                        if ((string)(xlWorkSheet.Cells[8, 1].Text.ToString()) == "DEGRADATION STATEs:")
                        {
                            List<string> AllDegradationASAP = new List<string>();
                            for (int a = 10; a <= iTotalRows_TDB; a++)
                            {
                                string DegState = (string)(xlWorkSheet.Cells[a, 7].Text.ToString());
                                string Temp = (string)(xlWorkSheet.Cells[a, 1].Text.ToString());
                                if (Temp == "FAIL RAM Information:")
                                {
                                    temp = a;
                                    j = a;
                                    break;
                                }
                                AllDegradationASAP.Add(DegState);
                            }
                            RemainingControlFun = ControlFunc_RemoveHBE.Except(AllDegradationASAP).ToArray();
                        }

                        xlWorkSheet.Cells[i, 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Yellow);
                        xlWorkSheet.Cells[i, 1] = "DEGRADATION STATEs:";
                        i++; j++;
                        foreach (string controlfun in RemainingControlFun)
                        {
                            string value = controlfun;
                            Excel.Range line = (Excel.Range)xlWorkSheet.Rows[++i];
                            line.Insert();
                            xlWorkSheet.Cells[i, 1] = "{{MEAS_" + value.ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE}}";
                            xlWorkSheet.Cells[i, 2] = "DEGRADATION INFO";
                            xlWorkSheet.Cells[i, 3] = "ASAP";
                            xlWorkSheet.Cells[i, 7] = controlfun;
                            ++j; remain++;
                        }

                        List<string> AllFailRamASAP = new List<string>();
                        for (int k = j + 1; k <= iTotalRows_TDB + remain; k++)
                        {
                            string Fail_Ram = (string)(xlWorkSheet.Cells[k, 7].Text.ToString());
                            AllFailRamASAP.Add(Fail_Ram);
                        }

                        if (temp == 10)
                        {
                            i = j + 1;
                        }
                        else
                        {
                            i = j - 1;
                        }

                        xlWorkSheet.Cells[i, 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Yellow);
                        xlWorkSheet.Cells[i, 1] = "FAIL RAM Information:";
                        i++;
                        foreach (string sample in global::FSF_SIL_Test_Automation.Properties.Settings.Xml_List.Select(x => x.FailRam).Distinct())
                        {
                            if (!(AllFailRamASAP.Contains(sample)))
                            {
                                Excel.Range line = (Excel.Range)xlWorkSheet.Rows[++i];
                                line.Insert();
                                xlWorkSheet.Cells[i, 1] = "{{Meas_" + sample.ToUpper() + "}}";
                                xlWorkSheet.Cells[i, 2] = "FAILURE BITS";
                                xlWorkSheet.Cells[i, 3] = "ASAP";
                                xlWorkSheet.Cells[i, 7] = sample;

                                if (!sample.Contains("Fbd_cur_"))
                                {
                                    line = (Excel.Range)xlWorkSheet.Rows[++i];
                                    line.Insert();
                                    xlWorkSheet.Cells[i, 1] = "{{Meas_" + sample.ToUpper() + "_final}}";
                                    xlWorkSheet.Cells[i, 2] = "FAILURE BITS";
                                    xlWorkSheet.Cells[i, 3] = "ASAP";
                                    xlWorkSheet.Cells[i, 7] = sample + "_final";
                                }
                            }
                        }

                        foreach (string sample in global::FSF_SIL_Test_Automation.Properties.Settings.Xml_List.Select(x => x.FailMEM).Distinct())
                        {
                            if (!(AllFailRamASAP.Contains(sample)))
                            {
                                Excel.Range line = (Excel.Range)xlWorkSheet.Rows[++i];
                                line.Insert();
                                xlWorkSheet.Cells[i, 1] = "{{Meas_" + sample.ToUpper() + "}}";
                                xlWorkSheet.Cells[i, 2] = "FAILURE BITS";
                                xlWorkSheet.Cells[i, 3] = "ASAP";
                                xlWorkSheet.Cells[i, 7] = sample;
                            }
                        }
                    }
                    else
                    {
                        // When we enter projet name
                        int i = 8; int j = 8; int temp = 10; int remain = 0;
                        int ColumnNumber = 10; int check = 0;

                        string project = textBox1.Text;
                        for (int temp1 = 1; temp1 <= itotalcols_TDB; temp1++)
                        {
                            string Project1 = (string)(xlWorkSheet.Cells[2, temp1] as Excel.Range).Value2;

                            if (Project1 == project)
                            {
                                // Project name present 
                                ColumnNumber = temp1;
                                check = 10;
                                break;
                            }
                            else
                            {
                                // Project name not present
                            }
                        }

                        if (check != 10)                // Adding new column for which project now availabe
                        {
                            Excel.Range line = (Excel.Range)xlWorkSheet.Columns[ColumnNumber];
                            line.Insert();

                            xlWorkSheet.Cells[2, ColumnNumber] = textBox1.Text;
                            xlWorkSheet.Cells[3, ColumnNumber] = "Name";
                            line = (Excel.Range)xlWorkSheet.Columns[ColumnNumber + 1];
                            line.Insert();
                            xlWorkSheet.Cells[3, ColumnNumber + 1] = "Value(s)";
                            line = (Excel.Range)xlWorkSheet.Columns[ColumnNumber + 2];
                            line.Insert();
                            xlWorkSheet.Cells[2, ColumnNumber + 2] = "Requested values";
                        }

                        string[] RemainingControlFun = null;
                        RemainingControlFun = ControlFunc.ToArray();
                        if ((string)(xlWorkSheet.Cells[8, 1].Text.ToString()) == "DEGRADATION STATEs:")
                        {
                            List<string> AllDegradationASAP = new List<string>();
                            for (int a = 10; a <= iTotalRows_TDB; a++)
                            {
                                string DegState = (string)(xlWorkSheet.Cells[a, 7].Text.ToString());
                                string Temp = (string)(xlWorkSheet.Cells[a, 1].Text.ToString());
                                if (Temp == "FAIL RAM Information:")
                                {
                                    temp = a;
                                    j = a;
                                    break;
                                }
                                AllDegradationASAP.Add(DegState);
                            }
                            RemainingControlFun = ControlFunc_RemoveHBE.Except(AllDegradationASAP).ToArray();
                        }

                        xlWorkSheet.Cells[i, 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Yellow);
                        xlWorkSheet.Cells[i, 1] = "DEGRADATION STATEs:";
                        i++; j++;
                        foreach (string controlfun in RemainingControlFun)
                        {
                            string value = controlfun.Replace("HBE.", "");
                            Excel.Range line = (Excel.Range)xlWorkSheet.Rows[++i];
                            line.Insert();
                            xlWorkSheet.Cells[i, 1] = "{{MEAS_" + value.ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE}}";
                            xlWorkSheet.Cells[i, 2] = "DEGRADATION INFO";
                            xlWorkSheet.Cells[i, 3] = "ASAP";
                            xlWorkSheet.Cells[i, 7] = controlfun.Replace("HBE.", "");
                            xlWorkSheet.Cells[i, ColumnNumber] = controlfun;
                            ++j; remain++;
                        }

                        Dictionary<string, string> AllControlFunction = new Dictionary<string, string>();

                        int Raw_Value1 = 0;
                        for (int a = 10; a <= iTotalRows_TDB; a++)
                        {
                            string standard = (string)(xlWorkSheet.Cells[a, 7].Text.ToString());
                            if (string.IsNullOrEmpty(standard))
                                continue;

                            AllControlFunction.Add(standard, a.ToString());
                        }

                        foreach (string func1 in ControlFunc)
                        {
                            foreach (var key in AllControlFunction.Keys)
                            {
                                if (AllControlFunction.ContainsKey(func1.Replace("HBE.", "")))
                                {
                                    Raw_Value1 = Convert.ToInt32(AllControlFunction[func1.Replace("HBE.", "")]);
                                    break;
                                }
                            }

                            if (Raw_Value1 != 0)
                            {
                                xlWorkSheet.Cells[Raw_Value1, ColumnNumber] = func1;
                            }
                            Raw_Value1 = 0;
                        }

                        Dictionary<string, string> AllFailRam = new Dictionary<string, string>();
                        List<string> AllFailRamASAP = new List<string>();
                        for (int k = j + 1; k <= iTotalRows_TDB + remain; k++)
                        {
                            string Fail_Ram = (string)(xlWorkSheet.Cells[k, 7].Text.ToString());
                            AllFailRamASAP.Add(Fail_Ram);
                            if (string.IsNullOrEmpty(Fail_Ram))
                            {
                                continue;
                            }
                            else
                                AllFailRam.Add(Fail_Ram, k.ToString());
                        }

                        if (temp == 10)
                        {
                            i = j + 1;
                        }
                        else
                        {
                            i = j - 1;
                        }

                        remain = 0;
                        xlWorkSheet.Cells[i, 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Yellow);
                        xlWorkSheet.Cells[i, 1] = "FAIL RAM Information:";
                        i++;
                        foreach (string sample in global::FSF_SIL_Test_Automation.Properties.Settings.Xml_List.Select(x => x.FailRam).Distinct())
                        {
                            if (!(AllFailRamASAP.Contains(sample)))
                            {
                                Excel.Range line = (Excel.Range)xlWorkSheet.Rows[++i];
                                line.Insert();
                                xlWorkSheet.Cells[i, 1] = "{{Meas_" + sample.ToUpper() + "}}";
                                xlWorkSheet.Cells[i, 2] = "FAILURE BITS";
                                xlWorkSheet.Cells[i, 3] = "ASAP";
                                xlWorkSheet.Cells[i, 7] = sample;
                                xlWorkSheet.Cells[i, ColumnNumber] = sample;
                                remain++;

                                if (!sample.Contains("Fbd_cur_"))
                                {
                                    line = (Excel.Range)xlWorkSheet.Rows[++i];
                                    line.Insert();
                                    xlWorkSheet.Cells[i, 1] = "{{Meas_" + sample.ToUpper() + "_final}}";
                                    xlWorkSheet.Cells[i, 2] = "FAILURE BITS";
                                    xlWorkSheet.Cells[i, 3] = "ASAP";
                                    xlWorkSheet.Cells[i, 7] = sample + "_final";
                                    xlWorkSheet.Cells[i, ColumnNumber] = sample + "_final";
                                }
                            }

                            if (check != 10)
                            {
                                int Raw_Value = 0;
                                foreach (var key in AllFailRam.Keys)
                                {
                                    if (AllFailRam.ContainsKey(sample))
                                    {
                                        Raw_Value = Convert.ToInt32(AllFailRam[sample]);
                                        break;
                                    }
                                }

                                if (Raw_Value != 0)
                                {
                                    xlWorkSheet.Cells[Raw_Value + remain, ColumnNumber] = sample;
                                    if (!sample.Contains("Fbd_cur_"))
                                    {
                                        xlWorkSheet.Cells[Raw_Value + 1, ColumnNumber] = sample + "_final";
                                    }
                                }
                                Raw_Value = 0;
                            }
                        }

                        foreach (string sample in global::FSF_SIL_Test_Automation.Properties.Settings.Xml_List.Select(x => x.FailMEM).Distinct())
                        {
                            if (!(AllFailRamASAP.Contains(sample)))
                            {
                                Excel.Range line = (Excel.Range)xlWorkSheet.Rows[++i];
                                line.Insert();
                                xlWorkSheet.Cells[i, 1] = "{{Meas_" + sample.ToUpper() + "}}";
                                xlWorkSheet.Cells[i, 2] = "FAILURE BITS";
                                xlWorkSheet.Cells[i, 3] = "ASAP";
                                xlWorkSheet.Cells[i, 7] = sample;
                                xlWorkSheet.Cells[i, ColumnNumber] = sample;
                                remain++;
                            }

                            if (check != 10)
                            {
                                int Raw_Value = 0;
                                foreach (var key in AllFailRam.Keys)
                                {
                                    if (AllFailRam.ContainsKey(sample))
                                    {
                                        Raw_Value = Convert.ToInt32(AllFailRam[sample]);
                                        break;
                                    }
                                }

                                if (Raw_Value != 0)
                                {
                                    xlWorkSheet.Cells[Raw_Value + remain, ColumnNumber] = sample;
                                }
                                Raw_Value = 0;
                            }
                        }
                    }

                    int iTotalRows_TDB1 = xlWorkSheet.UsedRange.Rows.Count;
                    List<string> AllASAP = new List<string>();
                    for (int k = 4; k < iTotalRows_TDB1; k++)
                    {
                        string Fail_Ram = (string)(xlWorkSheet.Cells[k, 7].Text.ToString());
                        if (string.IsNullOrEmpty(Fail_Ram))
                            continue;

                        AllASAP.Add(Fail_Ram + " =");
                    }
                    AllASAP.Sort();
                    if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\Debug\\"))
                        Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\Debug\\");
                    File.WriteAllLines(Directory.GetCurrentDirectory() + "\\Debug\\" + "Project_Specific_ASAP.ini", AllASAP);
                }

                /////////////////////////////////////////////////////////TestCases/////////////////////////////////////////////

                if (checkBox4.Checked)
                {
                    xlWorkSheet = xlWorkBook.Worksheets["03-TestCases"];
                    int iTotalRows_TDB = xlWorkSheet.UsedRange.Rows.Count;
                    int itotalcols_TDB = xlWorkSheet.UsedRange.Columns.Count;
                    int i = iTotalRows_TDB + 1; int j = iTotalRows_TDB - 2;

                    int ColumnNumber = 49;
                    if (!(string.IsNullOrEmpty(textBox1.Text)))
                    {
                        int check = 0;
                        string project = textBox1.Text;
                        for (int temp1 = 1; temp1 <= itotalcols_TDB; temp1++)
                        {
                            string Project1 = (string)(xlWorkSheet.Cells[3, temp1] as Excel.Range).Value2;

                            if (Project1 == project)
                            {
                                // Project name present 
                                ColumnNumber = temp1;
                                check = 49;
                                break;
                            }
                            else
                            {
                                // Project name not present
                            }
                        }

                        if (check != 49)                // Adding new column for which preoject now availabe
                        {
                            Excel.Range line = (Excel.Range)xlWorkSheet.Columns[ColumnNumber];
                            line.Insert();
                            xlWorkSheet.Cells[2, ColumnNumber] = "Project";
                            xlWorkSheet.Cells[3, ColumnNumber] = textBox1.Text;
                        }
                    }

                    Dictionary<string, string> AllTestID = new Dictionary<string, string>();
                    for (int a = 4; a <= iTotalRows_TDB; a++)
                    {
                        string LinkID = (string)(xlWorkSheet.Cells[a, 7].Text.ToString());
                        xlWorkSheet.Cells[a, 5] = a - 3;
                        xlWorkSheet.Cells[a, 6] = a;
                        AllTestID.Add(LinkID, a.ToString());
                    }

                    foreach (string name in global::FSF_SIL_Test_Automation.Properties.Settings.AllTestRun)
                    {
                        if (checkBox5.Checked)
                        {
                            int Raw_Value = 0;
                            foreach (var key in AllTestID.Keys)
                            {
                                if (AllTestID.ContainsKey("SW_REC_TestCase_" + name))
                                {
                                    Raw_Value = Convert.ToInt32(AllTestID["SW_REC_TestCase_" + name]);
                                    break;
                                }
                            }

                            if (Raw_Value != 0)
                            {
                                xlWorkSheet.Cells[Raw_Value, ColumnNumber] = "yes";
                            }
                            else
                            {
                                xlWorkSheet.Cells[i, 2] = "SW";
                                xlWorkSheet.Cells[i, 3] = "REC";
                                xlWorkSheet.Cells[i, 4] = "TestCase";
                                xlWorkSheet.Cells[i, 5] = j++;
                                xlWorkSheet.Cells[i, 6] = i;
                                xlWorkSheet.Cells[i, 7] = "SW_REC_TestCase_" + name;
                                xlWorkSheet.Cells[i, 13] = "REC check";
                                xlWorkSheet.Cells[i, 14] = "Check Component States and WL information after failure recover";
                                xlWorkSheet.Cells[i, 19] = "Degradation States are reset to correct value";
                                {
                                    xlWorkSheet.Cells[i, 21] = name + "_Rec";
                                    xlWorkSheet.Cells[i, 24] = "SIL";
                                    xlWorkSheet.Cells[i, 36] = name + "_Rec";
                                }
                                xlWorkSheet.Cells[i, ColumnNumber] = "yes";
                                i++;
                            }
                        }
                        if (checkBox6.Checked)
                        {
                            int Raw_Value = 0;
                            foreach (var key in AllTestID.Keys)
                            {
                                if (AllTestID.ContainsKey("SW_MEM_TestCase_" + name))
                                {
                                    Raw_Value = Convert.ToInt32(AllTestID["SW_MEM_TestCase_" + name]);
                                    break;
                                }
                            }

                            if (Raw_Value != 0)
                            {
                                xlWorkSheet.Cells[Raw_Value, ColumnNumber] = "yes";
                            }
                            else
                            {
                                xlWorkSheet.Cells[i, 2] = "SW";
                                xlWorkSheet.Cells[i, 3] = "MEM";
                                xlWorkSheet.Cells[i, 4] = "TestCase";
                                xlWorkSheet.Cells[i, 5] = j++;
                                xlWorkSheet.Cells[i, 6] = i;
                                xlWorkSheet.Cells[i, 7] = "SW_MEM_TestCase_" + name;
                                xlWorkSheet.Cells[i, 13] = "MEM check";
                                xlWorkSheet.Cells[i, 14] = "Check Component States and WL information in second IGN cycle";
                                xlWorkSheet.Cells[i, 18] = "Corresponding FAIL_RAM and MEM_RAM should reset";
                                xlWorkSheet.Cells[i, 19] = "Degradation States are reset to correct value";
                                {
                                    xlWorkSheet.Cells[i, 21] = name + "_Mem";
                                    xlWorkSheet.Cells[i, 24] = "SIL";
                                    xlWorkSheet.Cells[i, 36] = name + "_Mem";
                                }
                                xlWorkSheet.Cells[i, ColumnNumber] = "yes";
                                i++;
                            }
                        }
                        if (checkBox2.Checked)
                        {
                            int Raw_Value = 0;
                            foreach (var key in AllTestID.Keys)
                            {
                                if (AllTestID.ContainsKey("SW_DTC_TestCase_" + name))
                                {
                                    Raw_Value = Convert.ToInt32(AllTestID["SW_DTC_TestCase_" + name]);
                                    break;
                                }
                            }

                            if (Raw_Value != 0)
                            {
                                xlWorkSheet.Cells[Raw_Value, ColumnNumber] = "yes";
                            }
                            else
                            {
                                xlWorkSheet.Cells[i, 2] = "SW";
                                xlWorkSheet.Cells[i, 3] = "DTC";
                                xlWorkSheet.Cells[i, 4] = "TestCase";
                                xlWorkSheet.Cells[i, 5] = j++;
                                xlWorkSheet.Cells[i, 6] = i;
                                xlWorkSheet.Cells[i, 7] = "SW_DTC_TestCase_" + name;
                                xlWorkSheet.Cells[i, 13] = "DTC check";
                                xlWorkSheet.Cells[i, 14] = "Check DTC and DTCStatus after Failure set";
                                xlWorkSheet.Cells[i, 19] = "Corresponding DTC and DTCStatus are set";
                                {
                                    xlWorkSheet.Cells[i, 21] = name;
                                    xlWorkSheet.Cells[i, 24] = "SIL";
                                    xlWorkSheet.Cells[i, 36] = name;
                                }
                                xlWorkSheet.Cells[i, ColumnNumber] = "yes";
                                i++;
                            }
                        }
                        /////////////////////////////////////////////////////
                        if (checkBox1.Checked)
                        {
                            int Raw_Value = 0;
                            foreach (var key in AllTestID.Keys)
                            {
                                if (AllTestID.ContainsKey("SW_DEG_TestCase_" + name))
                                {
                                    Raw_Value = Convert.ToInt32(AllTestID["SW_DEG_TestCase_" + name]);
                                    break;
                                }
                            }

                            if (Raw_Value != 0)
                            {
                                xlWorkSheet.Cells[Raw_Value, ColumnNumber] = "yes";
                            }
                            else
                            {
                                xlWorkSheet.Cells[i, 2] = "SW";
                                xlWorkSheet.Cells[i, 3] = "DEG";
                                xlWorkSheet.Cells[i, 4] = "TestCase";
                                xlWorkSheet.Cells[i, 5] = j++;
                                xlWorkSheet.Cells[i, 6] = i;
                                xlWorkSheet.Cells[i, 7] = "SW_DEG_TestCase_" + name;
                                xlWorkSheet.Cells[i, 13] = "DEG check";
                                xlWorkSheet.Cells[i, 14] = "Check Degradation after Failure set";
                                xlWorkSheet.Cells[i, 19] = "Degradation States are set to correct value";
                                {
                                    xlWorkSheet.Cells[i, 21] = name;
                                    xlWorkSheet.Cells[i, 24] = "SIL";
                                    xlWorkSheet.Cells[i, 36] = name;
                                }
                                xlWorkSheet.Cells[i, ColumnNumber] = "yes";
                                i++;
                            }
                        }
                    }
                }
            }
            finally
            {
                progressBar2.Visible = false;
                button8.Enabled = true;
                xlWorkBook.Save();
                xlWorkBook.Close();               
                xlapp.Quit();
            }
            MessageBox.Show("DataBase updated");
        }

        //button use for stop proccess
        private void Stop_process_Click(object sender, EventArgs e)
        {
            if (!(thread1 == null))
            thread1.Abort();
            if (!(thread2 == null))
            thread2.Abort();
            if (!(thread3 == null))
            thread3.Abort();
        }

//////////////////////////// Test Run /////////////////////////////////////////////////////
        //--------------------TestRun & .ts file & XML file create ------------
        // For Generate TestRun & .ts file & XML file
        private void Create_Click(object sender, EventArgs e)
        {
            progressBar3.Visible = true;
            CheckForIllegalCrossThreadCalls = false;

            thread1 = new Thread(() => FSF_TestRun(sender, e));
            thread1.Start();
        }

        //--------------------TestRun Generation ------------------------------
        private void FSF_TestRun(object sender, EventArgs e)
        {
            button2.Enabled = false;

            Numbers.Excel_details ExcelData = new Numbers.Excel_details();
            List<Numbers.Excel_details> Excel_DataList = new List<Numbers.Excel_details>();

            Numbers.XML_Failure_details Xml_List = new Numbers.XML_Failure_details();
            List<Numbers.XML_Failure_details> Xml_Data = new List<Numbers.XML_Failure_details>();

            try
            {
                if (checkBox8.Checked)
                {
                    Excel_DataList = TestRun.Read_FSFSpec(0);   //  Reading value from FSF spec for VC project
                }
                else
                {
                    Excel_DataList = TestRun.Read_FSFSpec(1);   //  Reading value from FSF spec for TB project
                }

                if (Excel_DataList.Count == 0)
                {
                    button2.Enabled = true;
                    return;
                }

                Dictionary<string, string> DynXmlData = new Dictionary<string, string>();
                if (checkBox8.Checked)
                {
                    DynXmlData = TestRun.Read_DynXml();    // Reading values from Dynamic XML file

                    if (DynXmlData.Count == 0)
                    {
                        button2.Enabled = true;
                        return;
                    }
                }
                
                List<string> Read_File = new List<string>();

                if (checkBox9.Checked)
                {
                    for (int i = 0; i < Excel_DataList.Count; i++)
                    {
                        ExcelData = Excel_DataList[i];

                        Xml_List.Failure_Name = ExcelData.Failure_Name;
                        Xml_List.DTC = ExcelData.DTC;

                        if (!checkBox8.Checked)
                        {
                            Xml_List.CCP_Value = ExcelData.Position;

                            int Dec_value = Int32.Parse(ExcelData.Position.Replace("0x", "").Replace("0X", ""), System.Globalization.NumberStyles.HexNumber);
                            string DEC_Value = Convert.ToString(Dec_value);

                            Xml_List.DEC_Value = DEC_Value;
                            Xml_List.FailBit = ExcelData.FailureBit;

                            var res = ExcelData.Position.Take(ExcelData.Position.Length - 4);
                            string result = string.Join("", res);

                            string substr = result.Substring(result.Length - 2);
                            int failram_number = Int32.Parse(substr, System.Globalization.NumberStyles.HexNumber);

                            if (result[2] == '0')
                            {
                                Xml_List.FailRam = "FAIL_RAM" + failram_number.ToString("00");
                                Xml_List.FailMEM = "FAIL_RAM_MEM_" + failram_number.ToString("00");
                            }
                            else if (result[2] == '1')
                            {
                                Xml_List.FailRam = "FAIL_RAM_" + "1" + failram_number.ToString("00");
                                Xml_List.FailMEM = "FAIL_RAM_MEM_" + "1" + failram_number.ToString("00");
                            }
                            else if (result[2] == '2')
                            {
                                Xml_List.FailRam = "BUSFAILRAM_" + failram_number.ToString("00");
                                Xml_List.FailMEM = "BUSFAILRAM_" + failram_number.ToString("00");
                            }
                            else if (result[2] == '8')
                            {
                                Xml_List.FailRam = "FAIL_RAM_" + "8" + failram_number.ToString("00");
                                Xml_List.FailMEM = "IPB_FAIL_RAM_MEM" + failram_number.ToString("00");
                            }
                            else if (result[2] == '9')
                            {
                                Xml_List.FailRam = "FAIL_RAM_" + "4" + failram_number.ToString("00");
                                Xml_List.FailMEM = "FAIL_RAM_MEM_" + "4" + failram_number.ToString("00");
                            }
                            else if (result[2] == 'C' || result[2] == 'c')
                            {
                                Xml_List.FailRam = "FAIL_RAM_" + "3" + failram_number.ToString("00");
                                Xml_List.FailMEM = "FAIL_RAM_MEM_" + "3" + failram_number.ToString("00");
                            }
                            else
                            {
                                Xml_List.FailRam = null;
                                Xml_List.FailMEM = null;
                            }
                        }
                        else
                        {
                            foreach (var key in DynXmlData.Keys)
                            {
                                if (DynXmlData.ContainsKey(ExcelData.Failure_Name))
                                {
                                    Xml_List.CCP_Value = DynXmlData[ExcelData.Failure_Name];

                                    int Dec_value = Int32.Parse(DynXmlData[ExcelData.Failure_Name].Replace("0x", "").Replace("0X", ""), System.Globalization.NumberStyles.HexNumber);
                                    string DEC_Value = Convert.ToString(Dec_value);

                                    Xml_List.DEC_Value = DEC_Value;

                                    ExcelData.Position = DynXmlData[ExcelData.Failure_Name];
                                    Excel_DataList[i] = ExcelData;
                                    break;
                                }
                                else
                                {
                                    ExcelData.Position = null;
                                    Read_File.Add(ExcelData.Failure_Name);
                                    break;
                                }
                            }
                            Xml_List.FailRam = "Fbd_cur_" + ExcelData.Failure_Name;
                            Xml_List.FailMEM = "Fbd_mem_" + ExcelData.Failure_Name;
                            Xml_List.FailBit = "1";
                        }
                        Xml_Data.Add(Xml_List);
                    }

                    Read_File.Add("--------------------");
                    Read_File.Add("Not able to genearte TestRun file as failure doesn't have FailureBitDynAddressBit value in XML file .");
                    if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\Debug\\"))
                        Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\Debug\\");
                    File.WriteAllLines(Directory.GetCurrentDirectory() + "\\Debug\\" + "TestRun_NotGenerated.txt", Read_File);

                    TestRun.Create_Xml(Xml_Data);  // Creating XML File
                }

                if (checkBox10.Checked)
                {
                    if (checkBox8.Checked)     // Dynamic Project selection
                    {
                        if (checkBox12.Checked)
                        {
                            if (checkBox16.Checked)
                            {
                                if (checkBox15.Checked)
                                    TestRun.STD_TestRun(Excel_DataList, 2, 1);
                                else
                                    TestRun.STD_TestRun(Excel_DataList, 0, 1);
                            }
                            else
                            {
                                if (checkBox15.Checked)
                                    TestRun.STD_TestRun(Excel_DataList, 2, 0);
                                else
                                    TestRun.STD_TestRun(Excel_DataList, 0, 0);
                            }
                        }
                        if (checkBox13.Checked)
                        {
                            if (checkBox16.Checked)
                            {
                                if (checkBox15.Checked)
                                    TestRun.REC_TestRun(Excel_DataList, 2, 1);
                                else
                                    TestRun.REC_TestRun(Excel_DataList, 0, 1);
                            }
                            else
                            {
                                if (checkBox15.Checked)
                                    TestRun.REC_TestRun(Excel_DataList, 2, 0);
                                else
                                    TestRun.REC_TestRun(Excel_DataList, 0, 0);
                            }
                        }
                        if (checkBox14.Checked)
                        {
                            TestRun.MEM_TestRun(Excel_DataList);
                        }
                    }
                    else                       // TB project
                    {
                        if (checkBox12.Checked)
                        {
                            if(checkBox16.Checked)
                                TestRun.STD_TestRun(Excel_DataList, 1, 1);
                            else
                                TestRun.STD_TestRun(Excel_DataList, 1, 0);
                        }
                        if (checkBox13.Checked)
                        {
                            if (checkBox16.Checked)
                                TestRun.REC_TestRun(Excel_DataList, 1, 1);
                            else
                                TestRun.REC_TestRun(Excel_DataList, 1, 0);
                        }
                        if (checkBox14.Checked)
                        {
                            TestRun.MEM_TestRun(Excel_DataList);
                        }
                    }
                }
            }
            finally
            {
                Xml_Data.Clear();
                Excel_DataList.Clear();
                button2.Enabled = true;
                progressBar3.Visible = false;
            }
            MessageBox.Show("XML File,TestRuns and .ts file are created ! ");
        }

        ////////////////////////// --> END <-- //////////////////////////////

        private void Form1_Load(object sender, EventArgs e)
        {
            // Set up the delays for the ToolTip.
            toolTip1.AutoPopDelay = 10000;
            toolTip1.InitialDelay = 500;
            toolTip1.ReshowDelay = 500;
            // Force the ToolTip text to be displayed whether or not the form is active.
            toolTip1.ShowAlways = true;

            // Set up the ToolTip text for the Button and Checkbox.
            toolTip1.SetToolTip(this.textBox1, "Use this textbox for two purpose:\n 1) Enter project name while Upadating DataBase \n 2) Enter ATO TASK number,MKS TestCase ID while creating PY File");
            toolTip1.SetToolTip(this.label1, "Use this textbox for two purpose:\n 1) Enter project name while Upadating DataBase \n 2) Enter ATO TASK number,MKS TestCase ID while creating PY File");
            toolTip1.SetToolTip(this.textBox2, "Select Expected DTC checkbox,\n If you want to generate PY file to check Negative DTC testing.");
            toolTip1.SetToolTip(this.checkBox11, "Select Expected DTC checkbox,\n If you want to generate PY file to check Negative DTC testing.");
            toolTip1.SetToolTip(this.button1, "click to update FSF spec with info of\n 1) Failure position\n 2) DTC\n 3) Test completeness group.");
            toolTip1.SetToolTip(this.button2, "Generate TestRun and XML file for FSF failure.");
            toolTip1.SetToolTip(this.pictureBox2, "Select box for which want to generate TestRun file");
            toolTip1.SetToolTip(this.checkBox8, "Select to generate TestRun and XML file based on dynamic bitmap(VC) project.");
            toolTip1.SetToolTip(this.checkBox15, "Select to generate TestRun for local PC run. which not contain \"Failures.tcl\" line.");
            toolTip1.SetToolTip(this.checkBox16, "Select when you generate TestRun for HBE MK100(HAD) project.");

        }

        private void Fsf_SpecUpdate_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();
            frm2.ShowDialog();
        }

    }
}
