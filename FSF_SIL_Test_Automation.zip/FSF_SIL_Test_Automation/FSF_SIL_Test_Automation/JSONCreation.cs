﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;
using System.Linq;

namespace FSF_SIL_Test_Automation
{
    public class JSONCreation
    {
        private JSONCreation() { }

        public static void JSON_Generation(string[] check)
        {
            string[] Bat_File = null;
            if (check[4] == "True")
            {
                if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\Bat_File\\"))
                    Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\Bat_File\\");
                Bat_File = Directory.GetFiles(Directory.GetCurrentDirectory() + "\\Bat_File\\");

                try
                {
                    if (File.Exists(Bat_File[0])) { }
                }
                catch (IndexOutOfRangeException)
                {
                    MessageBox.Show("keep templete for .bat file in \"Bat_File\" folder !!!");
                    return;
                }
                if (!(Bat_File.Count() == 1))
                {
                    MessageBox.Show("Keep only one .bat file in \"FSF_Spec\" folder !!!");
                    return;
                }
            }

            List<string> MainFile = new List<string>();
            List<string> BatFile = new List<string>();

            MainFile.Add("{");
            MainFile.Add("   \"CONSTANTS\" : {");
            if (string.IsNullOrEmpty(check[5]))
            {
                MainFile.Add("      \"TDB_PATH\" : \"#ENVVAR(TEST_DATA_PATH)#\\\\TestDatabases\\\\FSF\\\\SIL_FSF_AUTOMATION_TDB_CustomerID_ProjectID.xlsx\",");
            }
            else
            {
                MainFile.Add("      \"TDB_PATH\" : \"#ENVVAR(TEST_DATA_PATH)#\\\\TestDatabases\\\\FSF\\\\SIL_FSF_AUTOMATION_TDB_" + check[5] + ".xlsx\",");
            }
            MainFile.Add("      \"EVALUATION_PATH\" : \"#ENVVAR(WORKSPACE_ROOT)#\\\\CV\\\\SIL\\\\FSF_Eval_Scripts\",");
            MainFile.Add("      \"FSF_SPEC\" : \"#ENVVAR(WORKSPACE_ROOT)#\\\\CV\\\\SIL\\\\FSF_Eval_Scripts\\\\AD2_development_monitoring_description.xlsx\"");
            MainFile.Add("   },");
            MainFile.Add("   \"DATABASE\" : {");
            MainFile.Add("      \"SWFactoryEvaluator\" : {");
            MainFile.Add("         \"full\" : {");

            int testcase = 0;
            foreach (string Test in global::FSF_SIL_Test_Automation.Properties.Settings.AllTestRun)
            {
                int temp = 0;  
                MainFile.Add("            \"FSF_Testruns/STD/" + Test + "\" : {");

                if (check[0] == "True")
                {
                    if (global::FSF_SIL_Test_Automation.Properties.Settings.AlldatabaseValue.ContainsKey(Test))
                    {
                        MainFile.Add("               \"" + Test + "_DEG\" : {");
                        MainFile.Add("                  \"Group\" : \"DEG\",");
                        MainFile.Add("                  \"TestDatabasePath\" : \"#CONST_INSERT(TDB_PATH)#\",");
                        MainFile.Add("                  \"TestCaseId\" : [ \"SW_DEG_TestCase_" + Test + "\" ],");
                        MainFile.Add("                  \"Parameters\" : {");
                        MainFile.Add("                     \"--script_folder_path\" : \"#CONST_INSERT(EVALUATION_PATH)#\\\\DEG\"");

                        if (check[4] == "True")
                        {
                            string[] lines1 = System.IO.File.ReadAllLines(Bat_File[0]);
                            BatFile.Add("REM ######## TestCase_" + testcase++ + "#########");
                            foreach (string line in lines1)
                            {
                                if (line.Contains("SW_Failure_Name"))
                                    BatFile.Add(line.Replace("SW_Failure_Name", "SW_DEG_TestCase_" + Test));
                                else if (line.Contains(".dl3"))
                                    BatFile.Add(line.Replace("Failure_Name", Test));
                                else if (line.Contains(".txt"))
                                    BatFile.Add(line.Replace("Failure_Name", Test));
                                else
                                    BatFile.Add(line);
                            }
                        }
                        temp = 2;
                    }
                }

                if (check[1] == "True")
                {
                    if (global::FSF_SIL_Test_Automation.Properties.Settings.AlldatabaseValue.ContainsKey(Test) && check[0] == "True")
                    {
                        MainFile.Add("                  }");
                        MainFile.Add("               },");
                    }

                    MainFile.Add("               \"" + Test + "_DTC\" : {");
                    MainFile.Add("                  \"Group\" : \"DTC\",");
                    MainFile.Add("                  \"TestDatabasePath\" : \"#CONST_INSERT(TDB_PATH)#\",");
                    MainFile.Add("                  \"TestCaseId\" : [ \"SW_DTC_TestCase_" + Test + "\" ],");
                    MainFile.Add("                  \"Parameters\" : {");
                    MainFile.Add("                     \"--script_folder_path\" : \"#CONST_INSERT(EVALUATION_PATH)#\\\\DTC\",");
                    MainFile.Add("                     \"--dtc_log\" : \"#PATH(temp_path)#\\\\" + Test + "_SetDTCs.txt\",");
                    MainFile.Add("                     \"--dtc_file\" : \"#CONST_INSERT(FSF_SPEC)#\"");

                    if (check[4] == "True")
                    {
                        string[] lines1 = System.IO.File.ReadAllLines(Bat_File[0]);
                        BatFile.Add("REM ######## TestCase_" + testcase++ + "#########");
                        foreach (string line in lines1)
                        {
                            if (line.Contains("SW_Failure_Name"))
                                BatFile.Add(line.Replace("SW_Failure_Name", "SW_DTC_TestCase_" + Test));
                            else if (line.Contains(".dl3"))
                                BatFile.Add(line.Replace("Failure_Name", Test));
                            else if (line.Contains(".txt"))
                                BatFile.Add(line.Replace("Failure_Name", Test));
                            else
                                BatFile.Add(line);
                        }
                    }
                    temp = 1;
                }

                if (temp == 1 && temp != 2)
                {
                    MainFile.Add("                  }");
                    MainFile.Add("               }");
                }
                if (temp == 2)
                {
                    MainFile.Add("                  }");
                    MainFile.Add("               }");
                }
                MainFile.Add("            },");
                temp = 0;

                if (check[3] == "True")
                {
                    MainFile.Add("            \"FSF_Testruns/MEM/" + Test + "_Mem\" : {");
                    MainFile.Add("               \"" + Test + "_MEM\" : {");
                    MainFile.Add("                  \"Group\" : \"MEM\",");
                    MainFile.Add("                  \"TestDatabasePath\" : \"#CONST_INSERT(TDB_PATH)#\",");
                    MainFile.Add("                  \"TestCaseId\" : [ \"SW_MEM_TestCase_" + Test + "\" ],");
                    MainFile.Add("                  \"Parameters\" : {");
                    MainFile.Add("                     \"--script_folder_path\" : \"#CONST_INSERT(EVALUATION_PATH)#\\\\MEM\",");
                    MainFile.Add("                     \"--dtc_log\" : \"#PATH(temp_path)#\\\\" + Test + "_Mem_SetDTCs.txt\",");
                    MainFile.Add("                     \"--dtc_file\" : \"#CONST_INSERT(FSF_SPEC)#\"");
                    MainFile.Add("                  }");
                    MainFile.Add("               }");
                    MainFile.Add("            },");


                    if (check[4] == "True")
                    {
                        string[] lines1 = System.IO.File.ReadAllLines(Bat_File[0]);
                        BatFile.Add("REM ######## TestCase_" + testcase++ + "#########");
                        foreach (string line in lines1)
                        {
                            if (line.Contains("SW_Failure_Name"))
                                BatFile.Add(line.Replace("SW_Failure_Name", "SW_MEM_TestCase_" + Test));
                            else if (line.Contains(".dl3"))
                                BatFile.Add(line.Replace("Failure_Name", Test + "_Mem"));
                            else if (line.Contains(".txt"))
                                BatFile.Add(line.Replace("Failure_Name", Test + "_Mem"));
                            else
                                BatFile.Add(line);
                        }
                    }

                }

                if (check[2] == "True")
                {
                    MainFile.Add("            \"FSF_Testruns/REC/" + Test + "_Rec\" : {");
                    MainFile.Add("               \"" + Test + "_REC\" : {");
                    MainFile.Add("                  \"Group\" : \"REC\",");
                    MainFile.Add("                  \"TestDatabasePath\" : \"#CONST_INSERT(TDB_PATH)#\",");
                    MainFile.Add("                  \"TestCaseId\" : [ \"SW_REC_TestCase_" + Test + "\" ],");
                    MainFile.Add("                  \"Parameters\" : {");
                    MainFile.Add("                     \"--script_folder_path\" : \"#CONST_INSERT(EVALUATION_PATH)#\\\\REC\",");
                    MainFile.Add("                     \"--dtc_log\" : \"#PATH(temp_path)#\\\\" + Test + "_Rec_SetDTCs.txt\",");
                    MainFile.Add("                     \"--dtc_file\" : \"#CONST_INSERT(FSF_SPEC)#\"");
                    MainFile.Add("                  }");
                    MainFile.Add("               }");
                    MainFile.Add("            },");

                    if (check[4] == "True")
                    {
                        string[] lines1 = System.IO.File.ReadAllLines(Bat_File[0]);
                        BatFile.Add("REM ######## TestCase_" + testcase++ + "#########");
                        foreach (string line in lines1)
                        {
                            if (line.Contains("SW_Failure_Name"))
                                BatFile.Add(line.Replace("SW_Failure_Name", "SW_REC_TestCase_" + Test));
                            else if (line.Contains(".dl3"))
                                BatFile.Add(line.Replace("Failure_Name", Test + "_Rec"));
                            else if (line.Contains(".txt"))
                                BatFile.Add(line.Replace("Failure_Name", Test + "_Rec"));
                            else
                                BatFile.Add(line);
                        }
                    }
                }
            }

            MainFile.RemoveAt(MainFile.Count - 1);            // to Remove Last comma
            MainFile.Add("            }");
            MainFile.Add("         }");
            MainFile.Add("      }");
            MainFile.Add("   }");
            MainFile.Add("}");

            testcase = 0;
            if (string.IsNullOrEmpty(check[5]))
            {
                File.WriteAllLines(Directory.GetCurrentDirectory() + "\\ProjectID_TestConfig_FSF.json", MainFile);
            }
            else
            {
                String ProjectID = check[5].Substring(check[5].LastIndexOf("_") + 1);

                File.WriteAllLines(Directory.GetCurrentDirectory() + "\\" + ProjectID + "_TestConfig_FSF.json", MainFile);
            }

            if (check[4] == "True")
            {
                File.WriteAllLines(Directory.GetCurrentDirectory() + "\\CommonBatFile.bat", BatFile);
            }
        }
    }
}
