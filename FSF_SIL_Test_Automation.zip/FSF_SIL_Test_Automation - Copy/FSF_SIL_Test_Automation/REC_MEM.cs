﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using System.IO;
using System.Linq;

namespace FSF_SIL_Test_Automation
{
    class REC_MEM
    {
        public static void REC_MEM_Generation(int Dis, Dictionary<string, int> components)
        {
            Global.Functions.Numbers.XML_Failure_details currentlist = new Global.Functions.Numbers.XML_Failure_details();

            string Function = global::FSF_SIL_Test_Automation.Properties.Settings.AlldatabaseValue.First().Value;
            string[] value = Function.Split('\\');
            string[] check = new string[value.Count()];

            if (global::FSF_SIL_Test_Automation.Properties.Settings.AlldatabaseValue.ContainsKey("No_Failure"))
            {
                string CodegState = global::FSF_SIL_Test_Automation.Properties.Settings.AlldatabaseValue["No_Failure"];
                check = CodegState.Split('\\');
            }
            else if (global::FSF_SIL_Test_Automation.Properties.Settings.AlldatabaseValue.ContainsKey("No Failure"))
            {
                string CodegState = global::FSF_SIL_Test_Automation.Properties.Settings.AlldatabaseValue["No Failure"];
                check = CodegState.Split('\\');
            }
            else
            {
                for (int i = 0; i < value.Count(); i++)
                {
                    check[i] = "1";
                }
            }

            foreach (string Test in global::FSF_SIL_Test_Automation.Properties.Settings.AllTestRun)
            {
                List<string> REC_MEMFile = new List<string>();
                if (global::FSF_SIL_Test_Automation.Properties.Settings.AlldatabaseValue.ContainsKey(Test))
                {
                    currentlist = global::FSF_SIL_Test_Automation.Properties.Settings.Xml_List.Find(x => x.Failure_Name.Contains(Test));

                    REC_MEMFile.Add("from utils.utils import get_dtc_log_signals");
                    REC_MEMFile.Add("from pprint import pprint");
                    REC_MEMFile.Add("   ");
                    REC_MEMFile.Add("add_to_report = {");
                    REC_MEMFile.Add("    \"Test Script Owner\":  \"" + global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[6] + "\",");
                    REC_MEMFile.Add("    \"Project\"          :  \"" + global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[1] + "\",");
                    if (string.IsNullOrEmpty(global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[4]))
                    {
                        REC_MEMFile.Add("    \"MKS TestCase ID\"  :  \"\",");
                    }
                    else
                    {
                        REC_MEMFile.Add("    \"MKS TestCase ID\"  :  \"http://ffm-mks1:7002/im/issues?selection=" + global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[4] + "\",");
                    }
                    REC_MEMFile.Add("    \"TestCase Summary\" :  \"\",");
                    if (string.IsNullOrEmpty(global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[2]))
                    {
                        REC_MEMFile.Add("    \"ATO\"  :  \"\",");
                    }
                    else
                    {
                        REC_MEMFile.Add("    \"ATO\"              :  \"http://ffm-mks1:7002/im/issues?selection=" + global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[2] + "\",");
                    }
                    REC_MEMFile.Add("    \"ATO Summary\"      :  \"" + global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[3] + "\"}");
                    REC_MEMFile.Add("    ");

                    REC_MEMFile.Add("def run(meas, tdbparam):");
                    REC_MEMFile.Add("    import pandas as pd");
                    REC_MEMFile.Add("    from pandas import ExcelWriter");
                    REC_MEMFile.Add("    from pandas import ExcelFile");
                    REC_MEMFile.Add("    import evaluation_core.script_evaluation as se");
                    REC_MEMFile.Add("    import time as ti");
                    REC_MEMFile.Add("    import numpy as np");
                    REC_MEMFile.Add("    ");

                    REC_MEMFile.Add("    pd.set_option(\"max_columns\", 0)");
                    REC_MEMFile.Add("    pd.set_option(\"max_rows\", 0)");
                    REC_MEMFile.Add("    test_case = se.TestCase(meas.Data.index)");
                    REC_MEMFile.Add("    ");
                    REC_MEMFile.Add("    DTC_Status = {0xAF ,0x2F ,0xA3 ,0xA7 ,0x23 ,0x27};");
                    REC_MEMFile.Add("    #-----------------------Pre-condition ----------------");
                    REC_MEMFile.Add("    ");

                    REC_MEMFile.Add("    #---> Check of DTC Value and DTC Status");
                    REC_MEMFile.Add("    signals, errors = get_dtc_log_signals(meas.args, meas.signals)");
                    REC_MEMFile.Add("    ");
                    REC_MEMFile.Add("    #---> Checking Failure Ram");
                    if (currentlist.FailBit != null)
                    {
                        REC_MEMFile.Add("    test_case.add_relevant('Checking temporary failure bit recovered in EEPROM',meas.Data.Meas_" + currentlist.FailRam.ToUpper() + ".diff() == -1)");
                        REC_MEMFile.Add("    test_case.add_relevant('Checking failure MEM bit recovered in EEPROM',meas.Data.Meas_" + currentlist.FailMEM.ToUpper() + ".diff() == -1)");
                        REC_MEMFile.Add("    test_case.add_precondition('Checking System in init or running state',((meas.Data.MEAS_SYSTEM_STATE == 2) | (meas.Data.MEAS_SYSTEM_STATE == 3)))");
                        REC_MEMFile.Add("    test_case.add_precondition('Precondition to check Component States after Failure Recovery',((meas.Data.Meas_" + currentlist.FailMEM.ToUpper() + ".diff() == 0)&(meas.Data.Meas_" + currentlist.FailRam.ToUpper() + " == 0)))");
                    }
                    else
                    {
                        REC_MEMFile.Add("    #test_case.add_relevant('Checking temporary failure bit recovered in EEPROM',meas.Data.Meas_" + currentlist.FailRam.ToUpper() + ".diff() == -1)");
                        REC_MEMFile.Add("    #test_case.add_relevant('Checking failure MEM bit recovered in EEPROM',meas.Data.Meas_" + currentlist.FailMEM.ToUpper() + ".diff() == -1)");
                        REC_MEMFile.Add("    #test_case.add_precondition('Checking System in init or running state',((meas.Data.MEAS_SYSTEM_STATE == 2) | (meas.Data.MEAS_SYSTEM_STATE == 3)))");
                        REC_MEMFile.Add("    #test_case.add_precondition('Precondition to check Component States after Failure Recovery',((meas.Data.Meas_" + currentlist.FailMEM.ToUpper() + ".diff() == 0)&(meas.Data.Meas_" + currentlist.FailRam.ToUpper() + " == 0)))");
                    }
                    REC_MEMFile.Add("    ");
                    REC_MEMFile.Add("    #-------------------- Acception Creteria Checking DTC --------------");
                    REC_MEMFile.Add("    ");
                    if (currentlist.FailBit != null)
                    {
                        REC_MEMFile.Add("    if 'DTC_" + currentlist.Failure_Name + "' in signals:");
                        REC_MEMFile.Add("        test_case.add_accept_crit('DTC value = " + currentlist.DTC + "' , str(signals['DTC_" + currentlist.Failure_Name + "'].signal[0]).upper() == '" + currentlist.DTC + "'.upper())");
                        REC_MEMFile.Add("        test_case.add_accept_crit('DTCStatus value should not = 0xAF ,0x2F ,0xA3 ,0xA7 ,0x23 ,0x27 ' , ~(any(x == (signals['DTCStatus_" + currentlist.Failure_Name + "'].signal[0]) for x in DTC_Status)))");
                        REC_MEMFile.Add("    else:");
                        REC_MEMFile.Add("        test_case.add_accept_crit('DTC not getting set', 0 == 1)");
                    }
                    else
                    {
                        REC_MEMFile.Add("    if 'DTC_" + currentlist.Failure_Name + "' in signals:");
                        REC_MEMFile.Add("        #test_case.add_accept_crit('DTC value = " + currentlist.DTC + "' , str(signals['DTC_" + currentlist.Failure_Name + "'].signal[0]).upper() == '" + currentlist.DTC + "'.upper())");
                        REC_MEMFile.Add("        # test_case.add_accept_crit('DTCStatus value should not = 0xAF ,0x2F ,0xA3 ,0xA7 ,0x23 ,0x27 ' , ~(any(x == (signals['DTCStatus_" + currentlist.Failure_Name + "'].signal[0]) for x in DTC_Status)))");
                        REC_MEMFile.Add("    else:");
                        REC_MEMFile.Add("        #test_case.add_accept_crit('DTC not getting set', 0 == 1)");                        
                    }


                    REC_MEMFile.Add("    #-------------------- Acception Creteria Checking DEG--------------");
                    REC_MEMFile.Add("    ");
                    REC_MEMFile.Add("    #---> Checking Function Degradation");
                    REC_MEMFile.Add("    ");

                    for (int j = 0; j < check.Count() - 1; j++)
                    {
                        if (components.ContainsKey(value[j]))
                        {
                            int compo = components[value[j]];
                            if (check[j].Contains(','))
                            {
                                string val = null;
                                string[] temp = check[j].Split(',');
                                if (compo == 4)
                                {
                                    val = "    test_case.add_accept_crit('" + value[j] + " disable = " + temp[0] + "' ,(np.bitwise_and(meas.Data.MEAS_" + value[j].ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE.values.astype(int), 0x0004)) == " + temp[0];
                                    for (int i = 1; i < temp.Length; i++)
                                    {
                                        val = val + ")" + " | " + "(np.bitwise_and(meas.Data.MEAS_" + value[j].ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE.values.astype(int), 0x0004)) == " + temp[i];
                                    }
                                }
                                else
                                {
                                    val = "    test_case.add_accept_crit('" + value[j] + " disable = " + temp[0] + "' ,(np.bitwise_and(meas.Data.MEAS_" + value[j].ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE.values.astype(int), 0x0007)) == " + temp[0];
                                    for (int i = 1; i < temp.Length; i++)
                                    {
                                        val = val + ")" + " | " + "(np.bitwise_and(meas.Data.MEAS_" + value[j].ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE.values.astype(int), 0x0007)) == " + temp[i];
                                    }
                                }
                                val = val + ")" + ", 2.5)";
                                REC_MEMFile.Add(val);
                                continue;
                            }
                            else
                            {
                                if (compo == 4)
                                    REC_MEMFile.Add("    test_case.add_accept_crit('" + value[j] + "=" + check[j] + "',(np.bitwise_and(meas.Data.MEAS_" + value[j].ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE.values.astype(int), 0x0004)) ==" + check[j] + ", 2.5)");
                                else
                                    REC_MEMFile.Add("    test_case.add_accept_crit('" + value[j] + "=" + check[j] + "',(np.bitwise_and(meas.Data.MEAS_" + value[j].ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE.values.astype(int), 0x0007)) ==" + check[j] + ", 2.5)");
                                continue;
                            }
                        }

                        if (check[j].Contains(','))
                        {
                            string[] temp = check[j].Split(',');
                            string val = "    test_case.add_accept_crit('" + value[j] + " disable = " + temp[0] + "' ,(meas.Data.MEAS_" + value[j].ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE == " + temp[0];
                            for (int i = 1; i < temp.Length; i++)
                            {
                                val = val + ")" + " | " + "(meas.Data.MEAS_" + value[j].ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE == " + temp[i];
                            }

                            val = val + ")" + ", 2.5)";
                            REC_MEMFile.Add(val);
                        }
                        else
                        {
                            REC_MEMFile.Add("    test_case.add_accept_crit('" + value[j] + " disable = " + check[j] + "',meas.Data.MEAS_" + value[j].ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE == " + check[j] + ", 2.5)");
                        }
                    } 
                  
                    REC_MEMFile.Add("    ");
                    REC_MEMFile.Add("    return [test_case]");

                    string newfolder = global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[5];
                    if (Dis == 0 || Dis == 2)
                    {
                        if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\MEM"))
                            Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\MEM");
                        File.WriteAllLines(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\MEM" + "\\SW_MEM_TestCase_" + Test + ".py", REC_MEMFile);
                    }

                    if (Dis == 1 || Dis == 2)
                    {
                        REC_MEMFile = REC_MEMFile.Select(s => s.Replace("test_case.add_relevant('Checking temporary failure bit recovered in EEPROM',meas.Data.Meas_" + currentlist.FailRam.ToUpper() + ".diff() == -1)", "test_case.add_relevant('Checking temporary failure bit in EEPROM',meas.Data.Meas_" + currentlist.FailRam.ToUpper() + ".diff() == 1)")).ToList();
                        REC_MEMFile = REC_MEMFile.Select(s => s.Replace("test_case.add_relevant('Checking failure MEM bit recovered in EEPROM',meas.Data.Meas_" + currentlist.FailMEM.ToUpper() + ".diff() == -1)", "test_case.add_relevant('Checking temporary failure bit recovered in EEPROM',meas.Data.Meas_" + currentlist.FailRam.ToUpper() + ".diff() == -1)")).ToList();
                        REC_MEMFile = REC_MEMFile.Select(s => s.Replace("test_case.add_precondition('Precondition to check Component States after Failure Recovery',((meas.Data.Meas_" + currentlist.FailMEM.ToUpper() + ".diff() == 0)&(meas.Data.Meas_" + currentlist.FailRam.ToUpper() + " == 0)))", "test_case.add_precondition('Precondition to check Component States after Failure Recovery',((meas.Data.Meas_" + currentlist.FailRam.ToUpper() + ".diff() <= 0)&(meas.Data.Meas_" + currentlist.FailRam.ToUpper() + " == 0)))")).ToList();

                        if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\REC"))
                            Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\REC");
                        File.WriteAllLines(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\REC" + "\\SW_REC_TestCase_" + Test + ".py", REC_MEMFile);
                    }
                }
                else
                {
                    currentlist = global::FSF_SIL_Test_Automation.Properties.Settings.Xml_List.Find(x => x.Failure_Name.Contains(Test));

                    REC_MEMFile.Add("from utils.utils import get_dtc_log_signals");
                    REC_MEMFile.Add("from pprint import pprint");
                    REC_MEMFile.Add("   ");
                    REC_MEMFile.Add("add_to_report = {");
                    REC_MEMFile.Add("    \"Test Script Owner\":  \"" + global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[6] + "\",");
                    REC_MEMFile.Add("    \"Project\"          :  \"" + global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[1] + "\",");
                    if (string.IsNullOrEmpty(global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[4]))
                    {
                        REC_MEMFile.Add("    \"MKS TestCase ID\"  :  \"\",");
                    }
                    else
                    {
                        REC_MEMFile.Add("    \"MKS TestCase ID\"  :  \"http://ffm-mks1:7002/im/issues?selection=" + global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[4] + "\",");
                    }
                    REC_MEMFile.Add("    \"TestCase Summary\" :  \"\",");
                    if (string.IsNullOrEmpty(global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[2]))
                    {
                        REC_MEMFile.Add("    \"ATO\"  :  \"\",");
                    }
                    else
                    {
                        REC_MEMFile.Add("    \"ATO\"              :  \"http://ffm-mks1:7002/im/issues?selection=" + global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[2] + "\",");
                    }
                    REC_MEMFile.Add("    \"ATO Summary\"      :  \"" + global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[3] + "\"}");
                    REC_MEMFile.Add("    ");

                    REC_MEMFile.Add("def run(meas, tdbparam):");
                    REC_MEMFile.Add("    import pandas as pd");
                    REC_MEMFile.Add("    from pandas import ExcelWriter");
                    REC_MEMFile.Add("    from pandas import ExcelFile");
                    REC_MEMFile.Add("    import evaluation_core.script_evaluation as se");
                    REC_MEMFile.Add("    import time as ti");
                    REC_MEMFile.Add("    import numpy as np");
                    REC_MEMFile.Add("    ");

                    REC_MEMFile.Add("    pd.set_option(\"max_columns\", 0)");
                    REC_MEMFile.Add("    pd.set_option(\"max_rows\", 0)");
                    REC_MEMFile.Add("    test_case = se.TestCase(meas.Data.index)");
                    REC_MEMFile.Add("    ");
                    REC_MEMFile.Add("    DTC_Status = {0xAF ,0x2F ,0xA3 ,0xA7 ,0x23 ,0x27};");
                    REC_MEMFile.Add("    #-----------------------Pre-condition ----------------");
                    REC_MEMFile.Add("    ");

                    REC_MEMFile.Add("    #---> Check of DTC Value and DTC Status");
                    REC_MEMFile.Add("    signals, errors = get_dtc_log_signals(meas.args, meas.signals)");
                    REC_MEMFile.Add("    ");
                    REC_MEMFile.Add("    #---> Checking Failure Ram");
                    if (currentlist.FailBit != null)
                    {
                        REC_MEMFile.Add("    test_case.add_relevant('Checking temporary failure bit recovered in EEPROM',meas.Data.Meas_" + currentlist.FailRam.ToUpper() + ".diff() == -1)");
                        REC_MEMFile.Add("    test_case.add_relevant('Checking failure MEM bit recovered in EEPROM',meas.Data.Meas_" + currentlist.FailMEM.ToUpper() + ".diff() == -1)");
                        REC_MEMFile.Add("    test_case.add_precondition('Checking System in init or running state',((meas.Data.MEAS_SYSTEM_STATE == 2) | (meas.Data.MEAS_SYSTEM_STATE == 3)))");
                        REC_MEMFile.Add("    test_case.add_precondition('Precondition to check Component States after Failure Recovery',((meas.Data.Meas_" + currentlist.FailMEM.ToUpper() + ".diff() == 0)&(meas.Data.Meas_" + currentlist.FailRam.ToUpper() + " == 0)))");
                    }
                    else
                    {
                        REC_MEMFile.Add("    #test_case.add_relevant('Checking temporary failure bit recovered in EEPROM',meas.Data.Meas_" + currentlist.FailRam.ToUpper() + ".diff() == -1)");
                        REC_MEMFile.Add("    #test_case.add_relevant('Checking failure MEM bit recovered in EEPROM',meas.Data.Meas_" + currentlist.FailMEM.ToUpper() + ".diff() == -1)");
                        REC_MEMFile.Add("    #test_case.add_precondition('Checking System in init or running state',((meas.Data.MEAS_SYSTEM_STATE == 2) | (meas.Data.MEAS_SYSTEM_STATE == 3)))");
                        REC_MEMFile.Add("    #test_case.add_precondition('Precondition to check Component States after Failure Recovery',((meas.Data.Meas_" + currentlist.FailMEM.ToUpper() + ".diff() == 0)&(meas.Data.Meas_" + currentlist.FailRam.ToUpper() + " == 0)))");
                    }
                    REC_MEMFile.Add("    ");

                    REC_MEMFile.Add("    #-------------------- Acception Creteria Checking DTC --------------");
                    REC_MEMFile.Add("    ");
                    if (currentlist.FailBit != null)
                    {
                        REC_MEMFile.Add("    if 'DTC_" + currentlist.Failure_Name + "' in signals:");
                        REC_MEMFile.Add("        test_case.add_accept_crit('DTC value = " + currentlist.DTC + "' , str(signals['DTC_" + currentlist.Failure_Name + "'].signal[0]).upper() == '" + currentlist.DTC + "'.upper())");
                        REC_MEMFile.Add("        test_case.add_accept_crit('DTCStatus value should not = 0xAF ,0x2F ,0xA3 ,0xA7 ,0x23 ,0x27 ' , ~(any(x == (signals['DTCStatus_" + currentlist.Failure_Name + "'].signal[0]) for x in DTC_Status)))");
                        REC_MEMFile.Add("    else:");
                        REC_MEMFile.Add("        test_case.add_accept_crit('DTC not getting set', 0 == 1)");                        
                    }
                    else
                    {
                        REC_MEMFile.Add("    if 'DTC_" + currentlist.Failure_Name + "' in signals:");
                        REC_MEMFile.Add("        #test_case.add_accept_crit('DTC value = " + currentlist.DTC + "' , str(signals['DTC_" + currentlist.Failure_Name + "'].signal[0]).upper() == '" + currentlist.DTC + "'.upper())");
                        REC_MEMFile.Add("        # test_case.add_accept_crit('DTCStatus value should not = 0xAF ,0x2F ,0xA3 ,0xA7 ,0x23 ,0x27 ' , ~(any(x == (signals['DTCStatus_" + currentlist.Failure_Name + "'].signal[0]) for x in DTC_Status)))");
                        REC_MEMFile.Add("    else:");
                        REC_MEMFile.Add("        #test_case.add_accept_crit('DTC not getting set', 0 == 1)");
                    }
                    REC_MEMFile.Add("    ");
                    REC_MEMFile.Add("    return [test_case]");

                    string newfolder = global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[5];
                    if (Dis == 0 || Dis == 2)
                    {
                        if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\MEM"))
                            Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\MEM");
                        File.WriteAllLines(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\MEM" + "\\SW_MEM_TestCase_" + Test + ".py", REC_MEMFile);
                    }

                    if (Dis == 1 || Dis == 2)
                    {
                        REC_MEMFile = REC_MEMFile.Select(s => s.Replace("test_case.add_relevant('Checking temporary failure bit recovered in EEPROM',meas.Data.Meas_" + currentlist.FailRam.ToUpper() + ".diff() == -1)", "test_case.add_relevant('Checking temporary failure bit in EEPROM',meas.Data.Meas_" + currentlist.FailRam.ToUpper() + ".diff() == 1)")).ToList();
                        REC_MEMFile = REC_MEMFile.Select(s => s.Replace("test_case.add_relevant('Checking failure MEM bit recovered in EEPROM',meas.Data.Meas_" + currentlist.FailMEM.ToUpper() + ".diff() == -1)", "test_case.add_relevant('Checking temporary failure bit recovered in EEPROM',meas.Data.Meas_" + currentlist.FailRam.ToUpper() + ".diff() == -1)")).ToList();
                        REC_MEMFile = REC_MEMFile.Select(s => s.Replace("test_case.add_precondition('Precondition to check Component States after Failure Recovery',((meas.Data.Meas_" + currentlist.FailMEM.ToUpper() + ".diff() == 0)&(meas.Data.Meas_" + currentlist.FailRam.ToUpper() + " == 0)))", "test_case.add_precondition('Precondition to check Component States after Failure Recovery',((meas.Data.Meas_" + currentlist.FailRam.ToUpper() + ".diff() <= 0)&(meas.Data.Meas_" + currentlist.FailRam.ToUpper() + " == 0)))")).ToList();

                        if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\REC"))
                            Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\REC");
                        File.WriteAllLines(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\REC" + "\\SW_REC_TestCase_" + Test + ".py", REC_MEMFile);
                    }
                }
                REC_MEMFile.Clear();
            }
        }
    }
}
