﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Xml;

namespace FSF_SIL_Test_Automation
{
    public class PYCreation
    {
        private PYCreation() { }

        /// <summary>
        /// Reading All TestRun from TestRun Folder
        /// </summary>
        /// <returns></returns>
        public static List<string> TestRunFolder()
        {
            List<string> AllTestRun = new List<string>();

            // Create TestRun list from TestRun folder
            string[] files = null;
            try
            {
                files = Directory.GetFiles(Directory.GetCurrentDirectory() + "\\TestRun\\");
            }
            catch (DirectoryNotFoundException)
            {
                MessageBox.Show("TestRun folder is mandotaroy for Evaluation Files...!!!!");
                return AllTestRun;
            }

            foreach (string file in files)
            {
                string name = file.Substring(file.LastIndexOf("\\") + 1);
                AllTestRun.Add(name);
            }

            return AllTestRun;
        }

        /// <summary>
        /// Reading all function codeg state info from degrdation table
        /// </summary>
        /// <returns></returns>
        public static Dictionary<string, string> DataBaseValue()
        {
            Dictionary<string, string> AllDataBaseValue = new Dictionary<string,string>();

            if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\DegradationTable\\"))
                Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\DegradationTable\\");
            string[] Degradation_Table = Directory.GetFiles(Directory.GetCurrentDirectory() + "\\DegradationTable\\");

            try
            {
                if (File.Exists(Degradation_Table[0])) { }
            }
            catch (IndexOutOfRangeException)
            {
                MessageBox.Show("FSF function degradation document not present in \"DegradationTable\" folder !!!");
                return AllDataBaseValue;
            }
            if (!(Degradation_Table.Count() == 1))
            {
                if (Degradation_Table[1].Contains("~"))
                {
                }
                else
                {
                    MessageBox.Show("Keep only one Function degradation table document in \"FSF_Spec\" folder !!!");
                    return AllDataBaseValue;
                }
            }
         
            Excel.Application xlapp = new Excel.Application();
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;

            xlWorkBook = xlapp.Workbooks.Open(Degradation_Table[0]);
            xlWorkSheet = xlWorkBook.ActiveSheet;
            int iTotalRows = xlWorkSheet.UsedRange.Rows.Count;
            int itotalcols = xlWorkSheet.UsedRange.Columns.Count;

            try
            {
                // Create failure list from excle sheet
                for (int s = 1; s <= iTotalRows; s++)
                {
                    string CodegState = null;
                    string failureName = (string)(xlWorkSheet.Cells[s, 1] as Excel.Range).Value2;

                    if (string.IsNullOrEmpty(failureName))
                        continue;

                    for (int a = 2; a <= itotalcols; a++)
                    {
                        string check = (string)(xlWorkSheet.Cells[s, a].Text.ToString());
                        CodegState += check + "\\";
                    }
                    if (!AllDataBaseValue.ContainsKey(failureName))
                        AllDataBaseValue.Add(failureName, CodegState);
                }
            }
            finally
            {
                xlapp.Quit();
                Marshal.ReleaseComObject(xlWorkSheet);
                Marshal.ReleaseComObject(xlWorkBook);
                Marshal.ReleaseComObject(xlapp);
            }
            return AllDataBaseValue;
        }

        /// <summary>
        /// Reading all failure information from XML file
        /// </summary>
        /// <returns></returns>
        public static List<Global.Functions.Numbers.XML_Failure_details> ReadXmlFile()
        {
            List<Global.Functions.Numbers.XML_Failure_details> datalist = new List<Global.Functions.Numbers.XML_Failure_details>();

            if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\XML_File\\"))
                Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\XML_File\\");
            string[] XML_File = Directory.GetFiles(Directory.GetCurrentDirectory() + "\\XML_File\\");

            try
            {
                if (File.Exists(XML_File[0])) { }
            }
            catch (IndexOutOfRangeException)
            {
                MessageBox.Show("keep xml file in \"XML_File\" folder!!!!");
                return datalist;
            }
            if (!(XML_File.Count() == 1))
            {
                MessageBox.Show("Keep only one xml file in \"XML_File\" folder !!!");
                return datalist;
            }
         
            XmlDocument xmldoc = new XmlDocument();
            xmldoc.Load(XML_File[0]);

            XmlNodeList nodeList = xmldoc.DocumentElement.SelectNodes("/root/Failure_Bit");
            try
            {
                foreach (XmlNode nxmNode in nodeList)
                {
                    Global.Functions.Numbers.XML_Failure_details sample = new Global.Functions.Numbers.XML_Failure_details();
                    XmlElement element = (XmlElement)nxmNode;

                    sample.Failure_Name = element.ChildNodes.Item(0).InnerText.Trim();
                    sample.DTC = element.ChildNodes.Item(1).InnerText.Trim();
                    sample.CCP_Value = element.ChildNodes.Item(2).InnerText.Trim();
                    sample.DEC_Value = element.ChildNodes.Item(3).InnerText.Trim();
                    sample.FailRam = element.ChildNodes.Item(4).InnerText.Trim();
                    sample.FailMEM = element.ChildNodes.Item(5).InnerText.Trim();
                    sample.FailBit = element.ChildNodes.Item(6).InnerText.Trim();

                    datalist.Add(sample);
                }
            }
            finally
            {
                xmldoc = null;
                nodeList = null;
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
            return datalist;
        }
    }
}
