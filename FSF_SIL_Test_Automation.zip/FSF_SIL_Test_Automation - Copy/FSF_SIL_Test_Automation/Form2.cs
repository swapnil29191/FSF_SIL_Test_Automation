﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;

namespace FSF_SIL_Test_Automation
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        Thread thread1;

        // Create the ToolTip and associate with the Form container.
        ToolTip toolTip1 = new ToolTip();

        private void FSFDatabase_Click(object sender, EventArgs e)
        {
            OpenFileDialog fdlg = new OpenFileDialog();
            fdlg.Title = "Select a Excel file";
            fdlg.Filter = "Excel Files (*.xlsx*)|*.xlsx*|Excel Files (*.xlsm*)|*.xlsm*|Excel Files (*.xls*)|*.xls*";
            if (fdlg.ShowDialog() == DialogResult.OK)
            {
                textBox1.Text = fdlg.FileName;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false;

            thread1 = new Thread(() => UpdateFSF_Click(sender, e));
            thread1.Start();
        }

        public void UpdateFSF_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            button2.Enabled = false;
            Excel.Application xlapp = new Excel.Application();
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;

            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Please select FSF spec as Database");
                return;
            }

            string[] FSF_Spec = null;
            string path = Directory.GetCurrentDirectory() + "\\FSF_Spec\\";
            try
            {
                FSF_Spec = Directory.GetFiles(path);
            }
            catch (DirectoryNotFoundException)
            {
                MessageBox.Show("FSF_Spec folder should present with proper FSF spec.");
                return;
            }

            try
            {
                if (FSF_Spec[0] == null) {  }
            }
            catch (IndexOutOfRangeException)
            {
                MessageBox.Show("FSF spec. excel sheet doccument is not present");
                return;
            }

            xlWorkBook = xlapp.Workbooks.Open(textBox1.Text);
            xlWorkSheet = xlWorkBook.ActiveSheet;
            int iTotalRows_Data = xlWorkSheet.UsedRange.Rows.Count;
            int itotalcols_Data = xlWorkSheet.UsedRange.Columns.Count;

            try
            {
                Dictionary<string, string> AllFailurePosition = new Dictionary<string, string>();
                Dictionary<string, string> AllDTC = new Dictionary<string, string>();
                Dictionary<string, string> AllGroup = new Dictionary<string, string>();

                for (int s = 2; s <= iTotalRows_Data; s++)
                {
                    string FailureName = (string)(xlWorkSheet.Cells[s, textBox5.Text] as Excel.Range).Value2;
                    string FailurePosition = null;
                    string DTC = null;
                    string Group = null;

                    if (string.IsNullOrEmpty(FailureName))
                        continue;

                    if (checkBox1.Checked)
                    {
                        FailurePosition = (string)(xlWorkSheet.Cells[s, textBox2.Text] as Excel.Range).Value2;
                    }
                    if (checkBox2.Checked)
                    {
                        DTC = (string)(xlWorkSheet.Cells[s, textBox3.Text] as Excel.Range).Value2;
                    }
                    if (checkBox3.Checked)
                    {
                        Group = (string)(xlWorkSheet.Cells[s, textBox4.Text] as Excel.Range).Value2;
                    }

                    try
                    {
                        AllFailurePosition.Add(FailureName, FailurePosition);
                        AllDTC.Add(FailureName, DTC);
                        AllGroup.Add(FailureName, Group);
                    }
                    catch (System.ArgumentException)
                    {
                    }
                }

                xlWorkBook.Close();
                xlapp.Quit();

                xlWorkBook = xlapp.Workbooks.Open(FSF_Spec[0]);
                xlWorkSheet = xlWorkBook.ActiveSheet;
                int iTotalRows = xlWorkSheet.UsedRange.Rows.Count;

                for (int s = 2; s <= iTotalRows; s++)
                {
                    string failureName = (string)(xlWorkSheet.Cells[s, 1] as Excel.Range).Value2;

                    if (string.IsNullOrEmpty(failureName))
                        continue;

                    if (checkBox1.Checked)
                    {
                        foreach (string key in AllFailurePosition.Keys)
                        {
                            if (key == failureName)
                            {
                                xlWorkSheet.Cells[s, 2] = AllFailurePosition[key];
                            }
                        }
                    }

                    if (checkBox2.Checked)
                    {
                        foreach (string key in AllDTC.Keys)
                        {
                            if (key == failureName)
                            {
                                xlWorkSheet.Cells[s, 3] = AllDTC[key];
                            }
                        }
                    }

                    if (checkBox3.Checked)
                    {
                        foreach (string key in AllGroup.Keys)
                        {
                            if (key == failureName)
                            {
                                xlWorkSheet.Cells[s, 4] = AllGroup[key];
                            }
                        }
                    }
                }
            }
            finally
            {
                button1.Enabled = true;
                button2.Enabled = true;
                xlWorkBook.Save();
                xlWorkBook.Close();
                xlapp.Quit();
            }
            MessageBox.Show("FSF Spec updated with information!");
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // Set up the delays for the ToolTip.
            toolTip1.AutoPopDelay = 10000;
            toolTip1.InitialDelay = 500;
            toolTip1.ReshowDelay = 500;
            // Force the ToolTip text to be displayed whether or not the form is active.
            toolTip1.ShowAlways = true;

            // Set up the ToolTip text for the Button and Checkbox.
            toolTip1.SetToolTip(this.checkBox1, "Select column number(like C) of Failure position value from FSF spec database.");
            toolTip1.SetToolTip(this.checkBox2, "Select column number(like AE) of DTC value from FSF spec database.");
            toolTip1.SetToolTip(this.checkBox3, "Select column number(like DE) of Test completeness group from FSF spec database.");
            toolTip1.SetToolTip(this.label2,    "Select column number(like F) of Failure name from FSF spec database.");
        }
    }
}
