﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using System.IO;
using System.Linq;

namespace FSF_SIL_Test_Automation
{
    class DTC
    {
        public static void DTC_Generation(int temp, string ExpectedDtc)
        {           
            Global.Functions.Numbers.XML_Failure_details currentlist = new Global.Functions.Numbers.XML_Failure_details();
            string[] ExpectedDtcList = null;

            if (temp == 1)
            {
                ExpectedDtcList = ExpectedDtc.Split(',').Select(p => p.Trim()).ToArray();
            }

            foreach (string Test in global::FSF_SIL_Test_Automation.Properties.Settings.AllTestRun)
            {
                List<string> DTCFile = new List<string>();
                currentlist = global::FSF_SIL_Test_Automation.Properties.Settings.Xml_List.Find(x => x.Failure_Name.Contains(Test));

                DTCFile.Add("from utils.utils import get_dtc_log_signals");
                DTCFile.Add("from pprint import pprint");
                DTCFile.Add("   ");
                DTCFile.Add("add_to_report = {");
                DTCFile.Add("    \"Test Script Owner\":  \"" + global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[6] + "\",");
                DTCFile.Add("    \"Project\"          :  \"" + global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[1] + "\",");
                if (string.IsNullOrEmpty(global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[4]))
                {
                    DTCFile.Add("    \"MKS TestCase ID\"  :  \"\",");
                }
                else
                {
                    DTCFile.Add("    \"MKS TestCase ID\"  :  \"http://ffm-mks1:7002/im/issues?selection=" + global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[4] + "\",");
                }
                DTCFile.Add("    \"TestCase Summary\" :  \"\",");
                if (string.IsNullOrEmpty(global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[2]))
                {
                    DTCFile.Add("    \"ATO\"  :  \"\",");
                }
                else
                {
                    DTCFile.Add("    \"ATO\"              :  \"http://ffm-mks1:7002/im/issues?selection=" + global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[2] + "\",");
                }
                DTCFile.Add("    \"ATO Summary\"      :  \"" + global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[3] + "\"}");
                DTCFile.Add("    ");

                DTCFile.Add("def run(meas, tdbparam):");
                DTCFile.Add("    import pandas as pd");
                DTCFile.Add("    from pandas import ExcelWriter");
                DTCFile.Add("    from pandas import ExcelFile");
                DTCFile.Add("    import evaluation_core.script_evaluation as se");
                DTCFile.Add("    import time as ti");
                DTCFile.Add("    import numpy as np");
                DTCFile.Add("    ");
                DTCFile.Add("    pd.set_option(\"max_columns\", 0)");
                DTCFile.Add("    pd.set_option(\"max_rows\", 0)");
                DTCFile.Add("    test_case = se.TestCase(meas.Data.index)");
                DTCFile.Add("    ");
                DTCFile.Add("    DTC_Status = { 0xAF ,0x2F ,0xA3 ,0xA7 ,0x23 ,0x27 };");
                if (temp == 1)
                {
                    List<string> ExpectedDTCstatuslist = new List<string>();
                    string content = null;
                    for (var K = 0; K < ExpectedDtcList.Length; K++)
                    {
                        bool Isfind = false;
                        for (var j = 0; j < global::FSF_SIL_Test_Automation.Properties.Settings.AllTestRun.Count; j++)
                        {
                            Global.Functions.Numbers.XML_Failure_details failurenames = global::FSF_SIL_Test_Automation.Properties.Settings.Xml_List.Find(x => x.Failure_Name.Contains(global::FSF_SIL_Test_Automation.Properties.Settings.AllTestRun[j]));
                            if (ExpectedDtcList[K] == failurenames.DTC)
                            {
                                ExpectedDTCstatuslist.Add("'DTCStatus_" + failurenames.Failure_Name + "'");
                                Isfind = true;
                                break;
                            }
                        }
                        if (!Isfind)
                            ExpectedDTCstatuslist.Add("'DTCStatus_" + ExpectedDtcList[K] + "'");
                    }

                    foreach (string eachline in ExpectedDTCstatuslist)
                    {
                        if (content == null)
                            content = content + eachline;
                        else
                            content = content + ',' + eachline;
                    }
                    ExpectedDTCstatuslist.Clear();

                    DTCFile.Add("    EXPECTED_DTC = {" + content.Trim(',') + "};");
                }
                DTCFile.Add("    #-----------------------Pre-condition ----------------");
                DTCFile.Add("    ");

                DTCFile.Add("    #---> Check of DTC Value and DTC Status");
                DTCFile.Add("    signals, errors = get_dtc_log_signals(meas.args, meas.signals)");
                DTCFile.Add("    ");
                DTCFile.Add("    #---> Checking Failure Ram");
                if (currentlist.FailBit != null)
                    DTCFile.Add("    test_case.add_precondition('Checking Final Failure in EEPROM',meas.Data.Meas_" + currentlist.FailRam.ToUpper() + " == " + currentlist.FailBit + ")");
                else
                    DTCFile.Add("    #test_case.add_precondition('Checking Final Failure in EEPROM',meas.Data.Meas_" + currentlist.FailRam.ToUpper() + " == " + currentlist.FailBit + ")");
                
                DTCFile.Add("    ");
                DTCFile.Add("    #-------------------- Acception Creteria --------------");
                DTCFile.Add("    ");

                if (currentlist.FailBit != null)
                {
                    if (temp == 1)
                    {
                        DTCFile.Add("    for key, val in signals.items(): ");
                        DTCFile.Add("       ");
                        DTCFile.Add("       if ('DTCStatus')  in key: ");
                        DTCFile.Add("           if key in EXPECTED_DTC: ");
                        DTCFile.Add("               test_case.add_accept_crit((key + ' value = 0xAF ,0x2F ,0xA3 ,0xA7 ,0x23 ,0x27 '), any(x == (signals[key].signal[0]) for x in DTC_Status))  ");
                        DTCFile.Add("       else : ");
                        DTCFile.Add("           if (key == 'DTCStatus_" + currentlist.Failure_Name + "'):");
                        DTCFile.Add("               test_case.add_accept_crit((key + ' value = 0xAF ,0x2F ,0xA3 ,0xA7 ,0x23 ,0x27 '), any(x == (signals[key].signal[0]) for x in DTC_Status))  ");
                        DTCFile.Add("           else : ");
                        DTCFile.Add("               test_case.add_accept_crit((key + ' value = 0xAF ,0x2F ,0xA3 ,0xA7 ,0x23 ,0x27 '), not(any(x == (signals[key].signal[0]) for x in DTC_Status))) ");
                    }
                    DTCFile.Add("       ");
                    DTCFile.Add("    if 'DTC_" + currentlist.Failure_Name + "' in signals:");
                    DTCFile.Add("        test_case.add_accept_crit('Checking DTC value = " + currentlist.DTC + "' , str(signals['DTC_" + currentlist.Failure_Name + "'].signal[0]).upper() == '" + currentlist.DTC + "'.upper())");
                    DTCFile.Add("        test_case.add_accept_crit('Checking DTCStatus value = 0xAF ,0x2F ,0xA3 ,0xA7 ,0x23 ,0x27 ' , any(x == (signals['DTCStatus_" + currentlist.Failure_Name + "'].signal[0]) for x in DTC_Status))");
                    DTCFile.Add("    else:");
                    DTCFile.Add("        test_case.add_accept_crit('Failure related DTC not getting set', 0 == 1)");                     
                }
                else
                {
                    DTCFile.Add("    if 'DTC_" + currentlist.Failure_Name + "' in signals:");
                    DTCFile.Add("        #test_case.add_accept_crit('Checking DTC value = " + currentlist.DTC + "' , str(signals['DTC_" + currentlist.Failure_Name + "'].signal[0]).upper() == '" + currentlist.DTC + "'.upper())");
                    DTCFile.Add("        # test_case.add_accept_crit('Checking DTCStatus value = 0xAF ,0x2F ,0xA3 ,0xA7 ,0x23 ,0x27 ' , any(x == (signals['DTCStatus_" + currentlist.Failure_Name + "'].signal[0]) for x in DTC_Status))");
                    if (temp == 1)
                    {
                        for (var j = 0; j < global::FSF_SIL_Test_Automation.Properties.Settings.AllTestRun.Count; j++)
                        {
                            Global.Functions.Numbers.XML_Failure_details failurenames = global::FSF_SIL_Test_Automation.Properties.Settings.Xml_List.Find(x => x.Failure_Name.Contains(global::FSF_SIL_Test_Automation.Properties.Settings.AllTestRun[j]));
                            if (ExpectedDtcList.Contains(failurenames.DTC))
                            {
                                DTCFile.Add("        test_case.add_accept_crit('DTC value = " + failurenames.DTC + "' , str(signals['DTC_" + failurenames.Failure_Name + "'].signal[0]).upper() == '" + failurenames.DTC + "'.upper())");
                                DTCFile.Add("        test_case.add_accept_crit('DTCStatus value = 0xAF ,0x2F ,0xA3 ,0xA7 ,0x23 ,0x27 ' , any(x == (signals['DTCStatus_" + failurenames.Failure_Name + "'].signal[0]) for x in DTC_Status))");
                            }
                            else
                            {
                                if (currentlist.DTC == failurenames.DTC)
                                {
                                }
                                else
                                {
                                    DTCFile.Add("        test_case.add_accept_crit('DTC value = " + failurenames.DTC + "' , str(signals['DTC_" + failurenames.Failure_Name + "'].signal[0]).upper() == '" + failurenames.DTC + "'.upper())");
                                    DTCFile.Add("        test_case.add_accept_crit('DTCStatus value = 0xAF ,0x2F ,0xA3 ,0xA7 ,0x23 ,0x27 ' , not(any(x == (signals['DTCStatus_" + failurenames.Failure_Name + "'].signal[0]) for x in DTC_Status)))");
                                }
                            }
                        }
                    }
                    DTCFile.Add("    ");
                    DTCFile.Add("    else:");
                    DTCFile.Add("        #test_case.add_accept_crit('Failure related DTC not getting set', 0 == 1)");
                }
                DTCFile.Add("    "); 
                DTCFile.Add("    return [test_case]");

                string newfolder = global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[5];
                if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\DTC"))
                    Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\DTC");
                File.WriteAllLines(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\DTC\\SW_DTC_TestCase_" + Test + ".py", DTCFile);
                DTCFile.Clear();
            }
        }
    }
}
