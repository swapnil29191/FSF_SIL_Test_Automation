﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using System.IO;
using System.Linq;

namespace FSF_SIL_Test_Automation
{
    public class DEG
    {
        public static void DEG_Generation(Dictionary<string, int> components)
        {
            List<string> Read_File = new List<string>();            
            Global.Functions.Numbers.XML_Failure_details currentlist = new Global.Functions.Numbers.XML_Failure_details();

            string Function = global::FSF_SIL_Test_Automation.Properties.Settings.AlldatabaseValue.First().Value;
            string[] value = Function.Split('\\');

            foreach (string Test in global::FSF_SIL_Test_Automation.Properties.Settings.AllTestRun)
            {
                List<string> DEGFile = new List<string>();
                if (global::FSF_SIL_Test_Automation.Properties.Settings.AlldatabaseValue.ContainsKey(Test))
                {
                    currentlist = global::FSF_SIL_Test_Automation.Properties.Settings.Xml_List.Find(x => x.Failure_Name.Contains(Test));

                    DEGFile.Add("from utils.utils import get_dtc_log_signals");
                    DEGFile.Add("from pprint import pprint");
                    DEGFile.Add("    ");
                    DEGFile.Add("add_to_report = {");
                    DEGFile.Add("    \"Test Script Owner\":  \"" + global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[6] + "\",");
                    DEGFile.Add("    \"Project\"          :  \"" + global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[1] + "\",");

                    if (string.IsNullOrEmpty(global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[4]))
                    {
                        DEGFile.Add("    \"MKS TestCase ID\"  :  \"\",");
                    }
                    else
                    {
                        DEGFile.Add("    \"MKS TestCase ID\"  :  \"http://ffm-mks1:7002/im/issues?selection=" + global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[4] + "\",");
                    }
                    DEGFile.Add("    \"TestCase Summary\" :  \"\",");
                    if (string.IsNullOrEmpty(global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[2]))
                    {
                        DEGFile.Add("    \"ATO\"  :  \"\",");
                    }
                    else
                    {
                        DEGFile.Add("    \"ATO\"              :  \"http://ffm-mks1:7002/im/issues?selection=" + global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[2] + "\",");
                    }
                    DEGFile.Add("    \"ATO Summary\"      :  \"" + global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[3] + "\"}");
                    DEGFile.Add("    ");

                    DEGFile.Add("def run(meas, tdbparam):");
                    DEGFile.Add("    import pandas as pd");
                    DEGFile.Add("    from pandas import ExcelWriter");
                    DEGFile.Add("    from pandas import ExcelFile");
                    DEGFile.Add("    import evaluation_core.script_evaluation as se");
                    DEGFile.Add("    import time as ti");
                    DEGFile.Add("    import numpy as np");
                    DEGFile.Add("    ");
                    DEGFile.Add("    pd.set_option(\"max_columns\", 0)");
                    DEGFile.Add("    pd.set_option(\"max_rows\", 0)");
                    DEGFile.Add("    test_case = se.TestCase(meas.Data.index)");
                    DEGFile.Add("    ");
                    DEGFile.Add("    #-----------------------Pre-condition ----------------");
                    DEGFile.Add("    ");

                    DEGFile.Add("    #---> Checking Failure Ram");
                    if (currentlist.FailBit != null)
                        DEGFile.Add("    test_case.add_precondition('Checking Final Failure in EEPROM',meas.Data.Meas_" + currentlist.FailRam.ToUpper() + " == " + currentlist.FailBit + ")");
                    else
                        DEGFile.Add("    #test_case.add_precondition('Checking Final Failure in EEPROM',meas.Data.Meas_" + currentlist.FailRam.ToUpper() + " == " + currentlist.FailBit + ")");
                    DEGFile.Add("    ");

                    DEGFile.Add("    #-------------------- Acception Creteria --------------");
                    DEGFile.Add("    ");
                    DEGFile.Add("    #---> Checking Function Degradation");
                    DEGFile.Add("    ");

                    string CodegState = global::FSF_SIL_Test_Automation.Properties.Settings.AlldatabaseValue[Test];
                    string[] check = CodegState.Split('\\');

                    for (int j = 0; j < check.Count()-1; j++)
                    {
                        if (components.ContainsKey(value[j]))
                        {
                            int compo = components[value[j]];
                            if (check[j].Contains(','))
                            {
                                string val = null;
                                string[] temp = check[j].Split(',');
                                if (compo == 4)
                                {
                                    val = "    test_case.add_accept_crit('" + value[j] + " disable = " + temp[0] + "' ,(np.bitwise_and(meas.Data.MEAS_" + value[j].ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE.values.astype(int), 0x0004)) == " + temp[0];
                                    for (int i = 1; i < temp.Length; i++)
                                    {
                                        val = val + ")" + " | " + "(np.bitwise_and(meas.Data.MEAS_" + value[j].ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE.values.astype(int), 0x0004)) == " + temp[i];
                                    }
                                }
                                else
                                {
                                    val = "    test_case.add_accept_crit('" + value[j] + " disable = " + temp[0] + "' ,(np.bitwise_and(meas.Data.MEAS_" + value[j].ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE.values.astype(int), 0x0007)) == " + temp[0];
                                    for (int i = 1; i < temp.Length; i++)
                                    {
                                        val = val + ")" + " | " + "(np.bitwise_and(meas.Data.MEAS_" + value[j].ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE.values.astype(int), 0x0007)) == " + temp[i];
                                    }
                                }
                                val = val + ")" + ", 0.03)";
                                DEGFile.Add(val);
                                continue;
                            }
                            else
                            {
                                if(compo == 4)
                                    DEGFile.Add("    test_case.add_accept_crit('" + value[j] + "=" + check[j] + "',(np.bitwise_and(meas.Data.MEAS_" + value[j].ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE.values.astype(int), 0x0004)) ==" + check[j] + ", 0.03)");
                                else
                                    DEGFile.Add("    test_case.add_accept_crit('" + value[j] + "=" + check[j] + "',(np.bitwise_and(meas.Data.MEAS_" + value[j].ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE.values.astype(int), 0x0007)) ==" + check[j] + ", 0.03)");                               
                                continue;
                            }
                        }

                        if (check[j].Contains(','))
                        {
                            string[] temp = check[j].Split(',');
                            string val = "    test_case.add_accept_crit('" + value[j] + " disable = " + temp[0] + "' ,(meas.Data.MEAS_" + value[j].ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE == " + temp[0];
                            for (int i = 1; i < temp.Length; i++)
                            {
                                val = val + ")" + " | " + "(meas.Data.MEAS_" + value[j].ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE == " + temp[i];
                            }

                            val = val + ")" + ", 0.03)";
                            DEGFile.Add(val);
                        }
                        else
                        {
                            DEGFile.Add("    test_case.add_accept_crit('" + value[j] + " disable = " + check[j] + "',meas.Data.MEAS_" + value[j].ToUpper().Replace("(", "").Replace(")", "") + "_IS_AVAILABLE == " + check[j] + ", 0.03)");
                        }
                    }

                    DEGFile.Add("    return [test_case]");

                    string newfolder = global::FSF_SIL_Test_Automation.Properties.Settings.ProjectSpecific[5];
                    if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\DEG"))
                        Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\DEG");
                    File.WriteAllLines(Directory.GetCurrentDirectory() + "\\EvaluationFile\\" + newfolder + "\\DEG\\SW_DEG_TestCase_" + Test + ".py", DEGFile);                      
                }
                else{
                    Read_File.Add(Test);
                }
                DEGFile.Clear();
            }
            Read_File.Add("--------------------");
            Read_File.Add("Mention failure bit doesn't have degradation state.We are checking only DTC for these type of failure bit");
            if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\Debug\\"))
                Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\Debug\\");
            File.WriteAllLines(Directory.GetCurrentDirectory() + "\\Debug\\" + "Failure_Nothave_DegradationState.txt", Read_File);
            Read_File.Clear();
        }
    }
}
