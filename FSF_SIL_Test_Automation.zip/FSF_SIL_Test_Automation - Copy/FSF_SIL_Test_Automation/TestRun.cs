﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Xml;
using Global.Functions;

namespace FSF_SIL_Test_Automation
{
    public class TestRun
    {
        private TestRun() { }   // Constructor
        
        /// <summary>
        /// Featch all info from FSF spec. and return as list structure.
        /// </summary>
        /// <param name="ExcelSheet"></param>
        /// <returns></returns>
        public static List<Numbers.Excel_details> Read_FSFSpec(int project)
        {
            List<Numbers.Excel_details> datalist = new List<Numbers.Excel_details>();
            Numbers.Excel_details sample = new Numbers.Excel_details();

            Excel.Application xlapp = new Excel.Application();
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;

            if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\FSF_Spec\\"))
                Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\FSF_Spec\\");
            string[] FSF_Spec = Directory.GetFiles(Directory.GetCurrentDirectory() + "\\FSF_Spec\\");

            try
            {
                if (File.Exists(FSF_Spec[0])) { }
            }
            catch (IndexOutOfRangeException)
            {
                MessageBox.Show("FSF spec. document not present in \"FSF_Spec\" folder !!!");
                return datalist;
            }

            if (!(FSF_Spec.Count() == 1))
            {
                if (FSF_Spec[1].Contains("~"))
                {
                }
                else
                {
                    MessageBox.Show("Keep only one FSF spec. document in \"FSF_Spec\" folder !!!");
                    return datalist;
                }
            }

            xlWorkBook = xlapp.Workbooks.Open(FSF_Spec[0]);
            xlWorkSheet = xlWorkBook.ActiveSheet;
            int iTotalRows = xlWorkSheet.UsedRange.Rows.Count;

            try
            {
                for (int s = 2; s <= iTotalRows; s++)
                {
                    string FailureBit = null;
                    string FailureBit1 = null;
                    string Hex_Num = null;

                    string FailureName = (string)(xlWorkSheet.Cells[s, 1] as Excel.Range).Value2;
                    string position = (string)(xlWorkSheet.Cells[s, 2] as Excel.Range).Value2;

                    if (string.IsNullOrEmpty(FailureName))
                        continue;
                    if (project == 1)
                    {
                        if (string.IsNullOrEmpty(position))
                            continue;

                        var chars = position.ToCharArray();

                        if (chars[5] == '0')
                            FailureBit = "0001";
                        else if (chars[5] == '1')
                            FailureBit = "0002";
                        else if (chars[5] == '2')
                            FailureBit = "0004";
                        else if (chars[5] == '3')
                            FailureBit = "0008";
                        else if (chars[5] == '4')
                            FailureBit = "0010";
                        else if (chars[5] == '5')
                            FailureBit = "0020";
                        else if (chars[5] == '6')
                            FailureBit = "0040";
                        else if (chars[5] == '7')
                            FailureBit = "0080";
                        else if (chars[5] == '8')
                            FailureBit = "0100";
                        else if (chars[5] == '9')
                            FailureBit = "0200";
                        else if (chars[5] == 'A' || chars[5] == 'a')
                            FailureBit = "0400";
                        else if (chars[5] == 'B' || chars[5] == 'b')
                            FailureBit = "0800";
                        else if (chars[5] == 'C' || chars[5] == 'c')
                            FailureBit = "1000";
                        else if (chars[5] == 'D' || chars[5] == 'd')
                            FailureBit = "2000";
                        else if (chars[5] == 'E' || chars[5] == 'e')
                            FailureBit = "4000";
                        else if (chars[5] == 'F' || chars[5] == 'f')
                            FailureBit = "8000";
                        else
                        {
                            MessageBox.Show("Check FSF_Spec failure position format !!!");
                            return datalist;
                        }

                        FailureBit1 = string.Concat("0x", FailureBit);
                        var res = chars.Take(chars.Length - 1);
                        string result = string.Join("", res);
                        Hex_Num = string.Concat(result, FailureBit);
                    }

                    sample.Failure_Name = FailureName;
                    sample.Position = Hex_Num;
                    sample.DTC = (string)(xlWorkSheet.Cells[s, 3] as Excel.Range).Value2;
                    sample.Completeness_Gruop = (string)(xlWorkSheet.Cells[s, 4] as Excel.Range).Value2;
                    sample.FailureBit = FailureBit1;

                    datalist.Add(sample);
                }
            }
            finally
            {
                xlapp.Quit();
                Marshal.ReleaseComObject(xlWorkSheet);
                Marshal.ReleaseComObject(xlWorkBook);
                Marshal.ReleaseComObject(xlapp);
            }
            if (datalist.Count == 0)
            {
                MessageBox.Show("check selection of project VC or TB !!!");
                return datalist;
            }
            else
                return datalist;
        }

        /// <summary>
        /// Taking info as list sturct which require to update in XML file
        /// </summary>
        /// <param name="Xml_data"></param>
        public static void Create_Xml( List<Numbers.XML_Failure_details> Xml_data)
        {
            if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\XML_File\\"))
                Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\XML_File\\");

            XmlTextWriter writer = new XmlTextWriter(Directory.GetCurrentDirectory() + "\\XML_File\\" + "FSF_SW_FACTORY_TESTs.xml", System.Text.Encoding.UTF8);
            writer.WriteStartDocument(true);
            writer.Formatting = Formatting.Indented;
            writer.Indentation = 2;
            writer.WriteStartElement("root");

            try
            {
                for (var i = 0; i < Xml_data.Count; i++)
                {
                    Numbers.XML_Failure_details currentlist = Xml_data[i];

                    writer.WriteStartElement("Failure_Bit");

                    writer.WriteStartElement("Failure_name");
                    writer.WriteString(currentlist.Failure_Name);
                    writer.WriteEndElement();

                    writer.WriteStartElement("DTC_value");
                    writer.WriteString(currentlist.DTC);
                    writer.WriteEndElement();

                    writer.WriteStartElement("HEX_value");
                    writer.WriteString(currentlist.CCP_Value);
                    writer.WriteEndElement();

                    writer.WriteStartElement("DEC_value");
                    writer.WriteString(currentlist.DEC_Value);
                    writer.WriteEndElement();

                    writer.WriteStartElement("Failram_value");
                    writer.WriteString(currentlist.FailRam);
                    writer.WriteEndElement();

                    writer.WriteStartElement("Failram_Mem_value");
                    writer.WriteString(currentlist.FailMEM);
                    writer.WriteEndElement();

                    writer.WriteStartElement("Failure_Bit_value");
                    writer.WriteString(currentlist.FailBit);
                    writer.WriteEndElement();

                    writer.WriteStartElement("Mem_Rec_Relevant_value");
                    writer.WriteString("1");
                    writer.WriteEndElement();

                    writer.WriteEndElement();
                }
            }
            finally
            {
                writer.WriteEndElement();
                writer.WriteEndDocument();
                writer.Close();
            }
        }

        /// <summary>
        /// Read data from Dynamic project xml file.
        /// </summary>
        /// <returns></returns>
        public static Dictionary<string, string> Read_DynXml()
        {
            Dictionary<string, string> DynXml_Data = new Dictionary<string, string>();

            if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\Dyn_xml\\"))
                Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\Dyn_xml\\");           
            string[] Dyn_xml = Directory.GetFiles(Directory.GetCurrentDirectory() + "\\Dyn_xml\\");

            try
            {
                if (File.Exists(Dyn_xml[0])) { }
            }
            catch (IndexOutOfRangeException)
            {
                MessageBox.Show("Dynamic XML file not present in \"Dyn_xml\" folder !!!");
                return DynXml_Data;
            }

            if (!(Dyn_xml.Count() == 1))
            {
                MessageBox.Show("Keep only one Dynamic failure bitmap XML file in \"Dyn_xml\" folder !!!");
                return DynXml_Data;
            }

            ////////////////READ Dynamic XML file////////////////////////////////////////////////
            XmlDocument xmldoc = new XmlDocument();
            xmldoc.Load(Dyn_xml[0]);

            List<string> AllFSF_failure = new List<string>();
            XmlNodeList nodeList = xmldoc.DocumentElement.SelectNodes("/FailureBits/FailureBit");
            try
            {
                foreach (XmlNode nxmNode in nodeList)
                {
                    XmlElement element = (XmlElement)nxmNode;
                    string Failure_Name = element.ChildNodes.Item(0).InnerText.Trim();

                    string temp1 = element.ChildNodes.Item(1).ChildNodes.Item(0).InnerText.Trim();
                    string temp = Convert.ToString(int.Parse(temp1), 16);       // Convert Decimal to Hex decimal

                    string temp2 = element.ChildNodes.Item(1).ChildNodes.Item(1).InnerText.Trim();

                    if (temp2 == "0")
                        temp2 = "0001";
                    else if (temp2 == "1")
                        temp2 = "0002";
                    else if (temp2 == "2")
                        temp2 = "0004";
                    else if (temp2 == "3")
                        temp2 = "0008";
                    else if (temp2 == "4")
                        temp2 = "0010";
                    else if (temp2 == "5")
                        temp2 = "0020";
                    else if (temp2 == "6")
                        temp2 = "0040";
                    else if (temp2 == "7")
                        temp2 = "0080";
                    else if (temp2 == "8")
                        temp2 = "0100";
                    else if (temp2 == "9")
                        temp2 = "0200";
                    else if (temp2 == "A" || temp2 == "a" || temp2 == "10")
                        temp2 = "0400";
                    else if (temp2 == "B" || temp2 == "b" || temp2 == "11")
                        temp2 = "0800";
                    else if (temp2 == "C" || temp2 == "c" || temp2 == "12")
                        temp2 = "1000";
                    else if (temp2 == "D" || temp2 == "d" || temp2 == "13")
                        temp2 = "2000";
                    else if (temp2 == "E" || temp2 == "e" || temp2 == "14")
                        temp2 = "4000";
                    else if (temp2 == "F" || temp2 == "f" || temp2 == "15")
                        temp2 = "8000";

                    string Hex_Num = string.Concat(temp.ToUpper(), temp2);

                    for (int i = 0; i <= DynXml_Data.Count; i++)
                    {
                        if (DynXml_Data.ContainsKey(Failure_Name))
                        {
                            break;
                        }
                        else
                            DynXml_Data.Add(Failure_Name, Hex_Num);
                    }
                }
            }
            finally
            {
                xmldoc = null;
                nodeList = null;
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
            return DynXml_Data;
        }

        /// <summary>
        /// Create STD TestRun file for CarMaker SIL
        /// </summary>
        /// <param name="ExcelData"></param>
        public static void STD_TestRun(List<Numbers.Excel_details> ExcelData, int project)
        {
            List<string> TestRun = new List<string>();
            List<string> AllTestRun = new List<string>();

            for (var i = 0; i < ExcelData.Count; i++)
            {
                Numbers.Excel_details currentlist = ExcelData[i];

                if (string.IsNullOrEmpty(currentlist.Failure_Name) || string.IsNullOrEmpty(currentlist.Position))
                    continue;

                if (project == 1 || project == 2)
                {
                    TestRun = Numbers.MyStandard();   // TB project
                }
                else{
                    TestRun = Numbers.MyStandard_Dyn();    // VC project
                }

                int Dec_value = Int32.Parse(currentlist.Position.Replace("0x", "").Replace("0X", ""), System.Globalization.NumberStyles.HexNumber);
                string DEC_Value = Convert.ToString(Dec_value);

                for (var j = 0; j < TestRun.Count; j++)
                {
                    if (TestRun[j].Contains("DVAwr CCP.SetFailureData Abs -1 0"))
                    {
                        TestRun[j] = TestRun[j].Replace("DVAwr CCP.SetFailureData Abs -1 0", "DVAwr CCP.SetFailureData Abs -1 " + DEC_Value);
                    }
                    else if (TestRun[j].Contains("Failure_name"))
                    {
                        TestRun[j] = TestRun[j].Replace("Failure_name", currentlist.Failure_Name);
                    }
                    else { }
                }

                if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\TestRun\\"))
                    Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\TestRun\\");
                File.WriteAllLines(Directory.GetCurrentDirectory() + "\\TestRun\\" + "\\" + currentlist.Failure_Name, TestRun);

                if (!AllTestRun.Contains(currentlist.Failure_Name))
                {
                AllTestRun.Add(currentlist.Failure_Name);
                }
            }
            TestManegar_STD(AllTestRun);
        }
      
        /// <summary>
        /// Cretae TestManager File which contain all STD TestRun which need to execute
        /// </summary>
        /// <param name="TestRun"></param>
        static void TestManegar_STD(List<string> TestRun)
        {
            // To generate Test Manager .ts file 
            List<string> TestManagerFile = new List<string>();

            List<string> TestManager = new List<string>();
            TestManager = Global.Functions.Numbers.TestManager();

            for (int j = 0; j < TestManager.Count; j++)
            {
                TestManagerFile.Add(TestManager[j]);
            }

            TestManagerFile.Add("Step.1 = Group");
            TestManagerFile.Add("Step.1.Name = FSF_STD");

            int i = 0;
            foreach (string name in TestRun)
            {
                TestManagerFile.Add("Step.1." + i + " = TestRun");
                TestManagerFile.Add("Step.1." + i + ".Name = FSF_Testruns/STD/" + name);
                i++;
            }

            File.WriteAllLines(Directory.GetCurrentDirectory() + "\\FSF_TESTS_SW_FACTORY_STD.ts", TestManagerFile);
        }

        /// <summary>
        /// Create REC TestRun files for CarMaker SIL
        /// </summary>
        /// <param name="ExcelData"></param>
        /// <param name="project"></param>
        public static void REC_TestRun(List<Numbers.Excel_details> ExcelData, int project)
        {
            List<string> TestRun = new List<string>();
            List<string> AllTestRun = new List<string>();

            for (var i = 0; i < ExcelData.Count; i++)
            {
                Numbers.Excel_details currentlist = ExcelData[i];

                if (string.IsNullOrEmpty(currentlist.Failure_Name) || string.IsNullOrEmpty(currentlist.Position))
                    continue;

                if (currentlist.Completeness_Gruop == "A" || currentlist.Completeness_Gruop == "a")
                {
                    TestRun = Numbers.MyRecoveryA();
                }
                else if (currentlist.Completeness_Gruop == "B" || currentlist.Completeness_Gruop == "b")
                {
                    TestRun = Numbers.MyRecoveryB();
                }
                else if (currentlist.Completeness_Gruop == "C" || currentlist.Completeness_Gruop == "c")
                {
                    TestRun = Numbers.MyRecoveryC();
                }
                else if (currentlist.Completeness_Gruop == "D" || currentlist.Completeness_Gruop == "d")
                {
                    TestRun = Numbers.MyRecoveryD();
                }
                else if (currentlist.Completeness_Gruop == "E" || currentlist.Completeness_Gruop == "e")
                {
                    TestRun = Numbers.MyRecoveryE();
                }
                else
                    TestRun = Numbers.MyRecovery();

                int Dec_value = Int32.Parse(currentlist.Position.Replace("0x", "").Replace("0X", ""), System.Globalization.NumberStyles.HexNumber);
                string DEC_Value = Convert.ToString(Dec_value);

                for (var j = 0; j < TestRun.Count; j++)
                {
                    if (project == 1 || project == 2)
                    {
                        if (TestRun[j].Contains("Eval Time >= 0.5 ? signal(\"TriggerError\", \"Failure_name\")"))
                            TestRun[j] = TestRun[j].Replace("Eval Time >= 0.5 ? signal(\"TriggerError\", \"Failure_name\")", "DVAwr CCP.SetFailureData Abs 50 " + DEC_Value);
                        else if (TestRun[j].Contains("Failure_name"))
                            TestRun[j] = TestRun[j].Replace("Failure_name", currentlist.Failure_Name);
                        else if (TestRun[j].Contains("Eval DM.ManTime >= 1 ? CCP.SetFailureData= 0"))
                            TestRun[j] = TestRun[j].Replace("Eval DM.ManTime >= 1 ? CCP.SetFailureData= 0", "[DM.ManTime >= 1] DVAwr CCP.SetFailureData Abs -1 0");
                        else if (TestRun[j].Contains("Failures.tcl"))
                            TestRun.Remove(TestRun[j]);
                    }
                    else
                    {
                        if (TestRun[j].Contains("Failure_name"))
                            TestRun[j] = TestRun[j].Replace("Failure_name", currentlist.Failure_Name);
                    }
                }

                if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\TestRun\\REC_Test\\"))
                    Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\TestRun\\REC_Test\\");
                File.WriteAllLines(Directory.GetCurrentDirectory() + "\\TestRun\\REC_Test\\" + "\\" + currentlist.Failure_Name + "_Rec", TestRun);

                if(!AllTestRun.Contains(currentlist.Failure_Name))
                {
                    AllTestRun.Add(currentlist.Failure_Name);
                }
            }
            TestManegar_REC(AllTestRun);
        }

        /// <summary>
        /// Cretae TestManager File which contain all REC TestRun which need to execute
        /// </summary>
        /// <param name="TestRun"></param>
        static void TestManegar_REC(List<string> TestRun)
        {
            // To generate Test Manager .ts file 
            List<string> TestManagerFile = new List<string>();

            List<string> TestManager = new List<string>();
            TestManager = Global.Functions.Numbers.TestManager();

            for (int j = 0; j < TestManager.Count; j++)
            {
                TestManagerFile.Add(TestManager[j]);
            }

            TestManagerFile.Add("Step.1 = Group");
            TestManagerFile.Add("Step.1.Name = FSF_REC");

            int i = 0;
            foreach (string name in TestRun)
            {
                TestManagerFile.Add("Step.1." + i + " = TestRun");
                TestManagerFile.Add("Step.1." + i + ".Name = FSF_Testruns/REC/" + name + "_Rec");
                i++;
            }

            File.WriteAllLines(Directory.GetCurrentDirectory() + "\\FSF_TESTS_SW_FACTORY_REC.ts", TestManagerFile);
        }

        /// <summary>
        /// Create MEM TestRun files for CarMaker SIL
        /// </summary>
        /// <param name="ExcelData"></param>
        /// <param name="project"></param>
        public static void MEM_TestRun(List<Numbers.Excel_details> ExcelData)
        {
            List<string> TestRun = new List<string>();
            List<string> AllTestRun = new List<string>();

            for (var i = 0; i < ExcelData.Count; i++)
            {
                Numbers.Excel_details currentlist = ExcelData[i];

                if (string.IsNullOrEmpty(currentlist.Failure_Name) || string.IsNullOrEmpty(currentlist.Position))
                    continue;

                if (currentlist.Completeness_Gruop == "A" || currentlist.Completeness_Gruop == "a")
                {
                    TestRun = Numbers.MyMemory_A();
                }
                else if (currentlist.Completeness_Gruop == "B" || currentlist.Completeness_Gruop == "b")
                {
                    TestRun = Numbers.MyMemory_B();
                }
                else if (currentlist.Completeness_Gruop == "C" || currentlist.Completeness_Gruop == "c")
                {
                    TestRun = Numbers.MyMemory_C();
                }
                else if (currentlist.Completeness_Gruop == "D" || currentlist.Completeness_Gruop == "d")
                {
                    TestRun = Numbers.MyMemory_D();
                }
                else if (currentlist.Completeness_Gruop == "E" || currentlist.Completeness_Gruop == "e")
                {
                    TestRun = Numbers.MyMemory_E();
                }
                else
                    TestRun = Numbers.MyMemory();

                if (!Directory.Exists(Directory.GetCurrentDirectory() + "\\TestRun\\MEM_Test\\"))
                    Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\TestRun\\MEM_Test\\");
                File.WriteAllLines(Directory.GetCurrentDirectory() + "\\TestRun\\MEM_Test\\" + "\\" + currentlist.Failure_Name + "_Mem", TestRun);

                if (!AllTestRun.Contains(currentlist.Failure_Name))
                {
                    AllTestRun.Add(currentlist.Failure_Name);
                }
            }
            TestManegar_MEM(AllTestRun);
        }

        /// <summary>
        /// Cretae TestManager File which contain all MEM TestRun which need to execute
        /// </summary>
        /// <param name="TestRun"></param>
        static void TestManegar_MEM(List<string> TestRun)
        {
            // To generate Test Manager .ts file 
            List<string> TestManagerFile = new List<string>();

            List<string> TestManager = new List<string>();
            TestManager = Global.Functions.Numbers.TestManager();

            for (int j = 0; j < TestManager.Count; j++)
            {
                TestManagerFile.Add(TestManager[j]);
            }

            TestManagerFile.Add("Step.1 = Group");
            TestManagerFile.Add("Step.1.Name = FSF_MEM");

            int i = 0;
            foreach (string name in TestRun)
            {
                TestManagerFile.Add("Step.1." + i + " = TestRun");
                TestManagerFile.Add("Step.1." + i++ + ".Name = FSF_Testruns/STD/" + name);
                TestManagerFile.Add("Step.1." + i + " = TestRun");
                TestManagerFile.Add("Step.1." + i + ".Name = FSF_Testruns/MEM/" + name + "_Mem");
                i++;
            }

            File.WriteAllLines(Directory.GetCurrentDirectory() + "\\FSF_TESTS_SW_FACTORY_MEM.ts", TestManagerFile);
        }

    }
}
